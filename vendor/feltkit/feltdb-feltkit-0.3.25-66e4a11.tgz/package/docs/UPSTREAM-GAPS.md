# FeltKit: upstream gaps to close

As of 2026-11-03 (reviewed against @feltdb/core 0.18.0 and 0.20.0, @appport/services 0.14.0, `@appport/core` 1.5.0 and `@appport/sdk` 1.4.1; see "Review 2026-11-03" at the end); first written 2026-10-27.

## Summary

On 2026-10-27 FeltKit worked around 17 gaps that belong upstream: 6 in FeltDB, 4 in AppPort and 7 in AppPort Services. Each one was FeltKit reading private storage, depending on internal behavior, or keeping a copy of logic its owner should hold. The 2026-10-28 releases close most of them; the sections below record what was removed and what remains, plus the new gaps adoption exposed (F7–F11, A5, S3a, S3b, S8). None blocks a release.

Here an upstream gap means FeltKit had to do one of three things:

- read a package's private collections or internal fields;
- rely on behavior the package doesn't document or export;
- reimplement something generic that belongs in the owning package.

Gaps that are FeltKit's own work are listed separately and are not upstream asks.

**Adopted releases (2026-10-28).** FeltKit pins `@feltdb/core` 0.15.0, AppPort 1.4.0 (protocol
1.3.0) and `@appport/services` 0.8.0 (which pins the same `@feltdb/core`, so one FeltDB copy
installs with no override). The FeltDB, AppPort and AppPort Services sections below record,
gap by gap, which workaround was deleted, which released capability replaced it, and what
remains with its reason. Still open upstream: FeltDB F7–F11 (no database-level change
listener, no content deletion, no embedded Durable Work and no released approval state),
AppPort A5 (a handler cannot keep its idempotency claim), and AppPort Services S3a/S3b/S8
(cross-application delivery counts, no trusted read of credential references, replay
ownership). FeltKit's own integration call records (`_feltkit_integration_calls`, written
before the request is sent) remain: they are the evidence of the external request, and
they refuse a same-key replay after an `OUTCOME_UNKNOWN` answer, which AppPort's claim does
not cover (A5).

Not upstream asks, recorded for the platform work: AppPort Services has no outbound HTTP
connector with evidence and hosts cannot add gateway capabilities, so FeltKit's
integrations record their own call evidence on the shared instance; FeltDB's TypeScript
workflow executor is not durable, so FeltKit composes workflows from application state,
jobs, and the agent action lifecycle.

Priority order:

1. **Correctness:** the FeltDB subscription defect, and the AppPort and AppPort Services windows where an action's outcome can't be known.
2. **Removing private reads:** FeltDB agent-state lookups, and AppPort Services' instance identity, health and delivery reads.
3. **Exports and conveniences:** types, versions and stores.

Sources: `docs/PRODUCT-AND-ARCHITECTURE-REVIEW.md` §4 and §9, `docs/INTEGRATION-AUDIT.md`, and the FeltKit source on `claude/concave-platform-mvp-d7lcwi` (commit `3d6b072`). Upstream revisions read: `rkendel1/flow_db` `344008a` (FeltDB 0.13.0), `rkendel1/appport` `9b1091e`, `rkendel1/appport-services` `2496ea9` (0.5.0).

## FeltDB (`rkendel1/flow_db`)

Six gaps. **FeltDB 0.15.0 (published 2026-10-28, carrying 0.14.0) closes F2–F5 and fixes
the F1 defect; FeltKit pins it and has removed those workarounds.** F1's polling stays,
for a narrower reason recorded below. F6's content store is released but not adopted: it
has no deletion and no memory runtime (F8, F9). The release also exposed five smaller gaps (F7–F11).
Per-candidate mapping, removed code and verification: `packages/sdk/test/feltdb-release.test.ts`.

| # | Gap | Status with 0.15.0 | What FeltKit does now |
| --- | --- | --- | --- |
| F1 | Collection subscriptions on the local runtime miss writes made through `db.transaction` (a defect) | **Defect fixed** (0.14.0). Workaround **kept**: see F7 | `runtime/changes.ts` still reads the journal (`getSequence()` + `exportOperations(since)`). Subscriptions are per named collection, re-read the whole collection on every notification, and are keyed process-wide by collection name, so they cannot name every collection of one instance. Local state has one writing process (F5), so there are no cross-process writes to miss: CLI commands go through the running server's admin API. |
| F2 | No API to list agent tasks or open handoffs | **Closed**: `AgentStateStore.listTasks` / `listHandoffs` (bounded, cursor) | `runtime/agent.ts` pages them; the 500 and 200 caps and the `_feltdb.AgentTask` / `_feltdb.AgentHandoff` reads are gone. Tasks are listed unfiltered or by status and filtered to the project in FeltKit, because a task last written before 0.14.0 lacks the project index key until its next write. |
| F3 | No lookup from a task to its execution record | **Closed**: `db.findAgentExecution({ taskId })`, `createAgentExecution(..., { taskId })` | New executions carry `taskId`; the 1,000-record scan is gone. Executions created before 0.14.0 (no `taskId`) are found by a one-time read of `_flow_agent_executions` per process, only when a task has no linked execution, and are linked by the next change FeltDB commits. |
| F4 | Executions have no Cancelled state, and `getAgentRuntime().resume()` changes state only in memory | **Closed**: `AgentExecutionStatus.Cancelled`, `db.cancelAgentExecution`, `db.resumeAgentExecution` commits | A cancelled task's execution is `Cancelled` with `cancelReason` (was `Failed`). After a restart FeltDB's resume commits `Observing`; FeltKit's own Waiting→Observing writes are gone. |
| F5 | Nothing stops a second process opening the same local state | **Closed**: `createFeltDB({ path })` takes `owner.lock` (`LocalStateLockedError`, `STATE_LOCKED`) | `runtime/instance.ts` maps `STATE_LOCKED` to `DUPLICATE_INSTANCE`, naming the running server from `.feltkit/<env>/runtime.json` or FeltDB's lock owner. FeltKit never passes `access: 'shared'`. `runtime.json` remains as discovery: the CLI's route to a running server, and `feltkit dev`'s early answer naming that server even when the sources fail to load. For FeltDB-server storage, where FeltDB has no client lock, it stays `feltkit start`'s same-host guard. The in-process check stays: handles in one process share FeltDB's lock. |
| F6 | No local content store: `storeContent` needs a FeltDB server | **Released, not adopted**: `db.storeContent` / `acquireContent` on the file and server runtimes, `capabilities().content` | Adopting it would lose two guarantees FeltKit's files have: deleting a file removes its bytes (F8) and files work on the memory runtime (F9). Bytes stay in `_feltkit_file_content` (`runtime/content.ts`), now stored before the metadata commit and removed if it fails, verified on every read, removed with their file. Tests: "F6 not adopted: …" in `test/feltdb-release.test.ts`. |
| F7 | No database-level change listener | Open (re-checked 2026-11-02: none on 0.17.1 or main) | Ask: an instance-scoped `db.onCommit((collections, sequence) => …)` (or `subscribeChanges`) on every runtime that names the collections a commit wrote without reading them. It would replace `runtime/changes.ts`. On a FeltDB server (every Vercel and Cloudflare deployment) FeltKit polls its own `_feltkit_collections` markers each second, so writes made by AppPort Services' own stores reach live queries only when a FeltKit write follows; the remote client already consumes the server's `/v1/events` internally, so exposing that stream per instance would close it there. |
| F8 | The content store has no deletion | Open (blocks F6) | Content-addressed bytes would outlive their file. Ask: `releaseContent(hash)` with reference counting, or a documented collection policy. |
| F9 | Memory and browser runtimes have no content store | Open (by design upstream: `CONTRACT_UNSUPPORTED`; blocks F6) | FeltKit's memory storage keeps files, so adopting the content store would break them there. Ask: an in-memory content store with the same contract. |
| F10 | Durable Work is server-only and has no approval state | **Partly closed (0.16.0)**: `AWAITING_APPROVAL`/`REJECTED` states, `WorkloadClient.approve/reject` with a decision record, and `db.workloads` bound to the server it was created for. Still server-only (an embedded runtime is declined upstream). Not adopted: FeltKit does not use `db.workloads` | `db.workloads` is an HTTP client for a FeltDB server (on an embedded runtime every call fails: `SERVICE_UNAVAILABLE`, relative URL), not bound to the database's own server URL or credentials, authorized by FeltDB `SignedGrant`s, and its states (`CREATED`…`DEAD_LETTER`) have no waiting-for-approval state. FeltKit's durable work stays composed from application state, AppPort Services jobs and the agent action lifecycle. Ask: an embedded Durable Work runtime, an approval state (`AWAITING_APPROVAL` with a decision record), and `db.workloads` bound to the database's authority. |
| F11 | `policies.requireApproval` on an agent definition is not enforced | Open | FeltDB's agent runtime never reads it; FeltKit enforces approval in its action lifecycle (agent memory records with compare-and-swap transitions), which has no FeltDB counterpart. |
| F12 | On an application-scoped authority (Managed FeltDB), a write without `requireAbsent` was an `update`: refused for an absent record, merged into an existing one | **Closed**: fixed in FeltDB 0.16.0 (`put` operation kind) and deployed (the managed service reports release 0.17.1 on 2026-11-02) | Kept: the runtime creates its collection markers with `requireAbsent` at start and reload (`ensureCollectionMarkers`, `runtime/data.ts`), which is correct on every authority, the old one included. Tests: `data.test.ts` (an authority without upsert), `npm run test:managed` |
| F13 | An application-scoped authority stores only what its contract declares, and FeltDB's agent-state field lists were FeltDB-internal | **Closed** (FeltDB 0.16.0): `FELTDB_AGENT_STATE_CONTRACT` (collections and indexes) | `feltkit contract` composes it unchanged with the application's collections and FeltKit's `_feltkit_*` records. Publishing is FeltDB's CLI (`feltdb publish --contract`). FeltKit has no publish code |
| F14 | A remote client kept the revision it discovered for its whole life, and the authority answered any revision a request named (superseded or never promoted) | **Fixed in FeltDB** (with F12): state requests run only under the environment's active revision (`409 REVISION_NOT_ACTIVE`, nothing applied). The client forgets the revision on that refusal, so its next request runs under the active one | FeltKit maps `REVISION_NOT_ACTIVE`, in a read or a commit, to `CONFLICT` with `details.feltdbCode` (it was `INTERNAL` outside a commit), not marked retryable and never resent: whether a request built for the previous contract still makes sense is the caller's decision (`runtime.ts`, `data.ts`, `feltdb-refusals.test.ts`). No restart after a promotion; `npm run test:managed` promotes a contract while the starter runs |
| F15 | A self-run `feltdb-server` (namespace API) refused identifiers outside `[A-Za-z0-9_-]`, including FeltDB's own agent-state collections (`_feltdb.AgentTask`, …) and checkpoint ids (`<task>.v<n>`); it also refused a bounded query without `orderBy`, which the embedded runtimes and AppPort Services' stores use, and `find()` returned the server's `recordId` inside documents | **Closed**: released in FeltDB 0.16.1 (rkendel1/flow_db#423, #427); the artifact's server is built from that release | The namespace API accepts exactly `_feltdb.Agent<Letters>` beside plain names, FeltDB's agent ids in those collections (never `:`), and orders a query without `orderBy` by record id, as the embedded runtimes do. `collection.find()` also stopped returning the server's `recordId` as a document field (AppPort Services' stores wrote it back). `feltkit deploy --target self-hosted` needs a server with that fix; `tests/e2e/deploy-targets.test.mjs` runs the full lifecycle on one |
| F16 | The live Managed FeltDB service (`api.feltdb.com`) runs FeltDB 0.11.9; `@feltdb/core` 0.16 sends unguarded writes as the `put` operation kind, which it refuses (`unknown variant put`, HTTP 422) | **Closed (2026-11-02)**: `https://api.feltdb.com/health` reports release 0.17.1 (server 0.4.3), which accepts `put`. Confirm with `npm run test:managed` and `tools/check-managed-release-identity.mjs` before relying on it; FeltKit keeps the startup check (`storage-check.ts`), which names a server older than the client in any future mismatch | Every FeltKit app from 0.3.2 on fails its first write on Managed FeltDB; startup now says so (`storage-check.ts`). Use your own server meanwhile (`--target self-hosted`, or `--target vercel --data self-hosted`; the artifact builds it). Ask: deploy FeltDB 0.16.1 to the managed service, and confirm with `tools/check-managed-release-identity.mjs` |

| F17 | A state-contract check reads a record's in-memory value: a key holding `undefined` is refused as a type violation (`invalid value for expiresAt`), although the stored JSON omits it. AppPort Services writes `expiresAt: undefined` for an API key with no expiry, so creating such a key failed under a contract | Open (found 2026-11-02, @feltdb/core 0.18.0; re-measured 2026-11-03 on 0.18.0 and 0.20.0: still refused) | FeltKit's component handles (`runtime/instance.ts`) remove `undefined`-valued keys from transaction writes, which is exactly what is stored. Ask: validate the record as it will be stored (drop `undefined` keys first), or refuse `undefined` before any check with a clear message |
| F18 | `stateContract.evolve` accepts a contract that no longer declares a collection still holding records, reporting the removal as `additive`; the records stay, unreachable through the contract and unchecked | Open (found 2026-11-02, 0.18.0; re-measured 2026-11-03 on 0.18.0 and 0.20.0: still accepted, still `additive`) | FeltKit's plan refuses it (`stranded`) until a migration moves or deletes them; records written to a collection the same evolution drops are refused by FeltDB (`UNKNOWN_COLLECTION`), so FeltKit evolves through an intermediate version that still declares it. Ask: refuse dropping a non-empty collection, or report it as `revalidates` with the record count |

| F19 | No collection listing. FeltKit's backup finds an application's collections from `exportOperations(0)`, which returns the whole operation journal (6,001 operations in a 6,001-write store, measured on 0.18.0 and 0.20.0; the journal kept every operation, so no collection was missed) | Open (found 2026-11-03) | Backup reads the journal once for names and pages every record (`runtime/backup.ts`). The journal is held in memory while it is read. Ask: a paged collection listing (names and counts) on every runtime |
| F20 | `collection.find(query, options)` with options and no `limit` returned FeltDB's default page of 100 on the local runtimes (0.18.0), with no sign that more matched. FeltKit always passed options, so `ctx.db.find` returned at most 100 records and `ctx.db.count` never exceeded 100 | **Closed upstream in 0.20.0**, differently: an unlimited `find()` matching more than 1,000 records is refused (`QUERY_LIMIT_EXCEEDED`, `FIND_RESULT_LIMIT`). That is a breaking change for any caller reading whole results with `find()` | **Fixed in FeltKit** (2026-11-03): every multi-record read pages `db.query` by cursor (`runtime/data.ts` `queryPages`/`readAll`/`countAll`), and a page that reports more records without a cursor is refused, not returned. FeltKit now requires `@feltdb/core` 0.20 (`>=0.20.0 <1.0.0`, rkendel1/feltkit#45), on which this fix is verified. Tests: `test/large-collections.test.ts`, `test/platform-large-state.test.ts` |
| F21 | `AgentStateStore.recallForTask` returns at most the 100 newest active memories per scope and has no cursor | Open (found 2026-11-03) | FeltKit read a task's actions and decision request through it, so a task with more than 100 active memories lost its oldest actions: proposed actions awaiting approval disappeared from the task (measured: 105 proposed, 100 listed). FeltKit now pages `recall({ scope: task })` (`runtime/agent.ts` `#taskMemories`). Test: "a task with more than 100 active memories…" in `test/agent-lifecycle.test.ts`. Ask: a cursor on `recallForTask`, or a documented cap |
| F22 | On the local runtimes, `collection.find()` and `db.query()` return the stored objects, not copies (`collection.get()` copies). A caller that changes a returned record changes what every later read in the process sees, with no write, version or commit | Open (found 2026-11-03, FeltDB 0.20.0) | Found by the SupplyDesk evaluation as a false `CONFLICT`: the change also altered the read basis FeltKit fences at commit. FeltKit's `ctx.db` now returns its own copies and copies values written (`runtime/data.ts` `owned`); `packages/sdk/test/data-isolation.test.ts` shows a query's change no longer leaks. Ask: copy in `find`/`query` (or freeze). |

| F23 | No text search: `db.query` takes only `eq`/`neq`/`lt`/`lte`/`gt`/`gte` (the query planner's `contains`/`startsWith` are internal, not part of `AuthorityQueryRequest`), and there is no text index | Open (found 2026-11-05, @feltdb/core 0.21.0) | `ctx.db.search` (FK-GAP-006, `runtime/search.ts`) pushes the equality `where` down and scans its matches page by page in FeltKit, testing normalized substrings, until `limit` match; at most 50,000 records are examined. Cost is linear in the `where` matches. Ask: a declared text index (normalized tokens, per collection and field) and a `contains`/`matches` clause on `db.query` that uses it, with the same cursor paging |

## AppPort (`rkendel1/appport`)

A1–A4 are closed by the released `@appport/core` 1.4.0 / `@appport/sdk` 1.4.0 / `@appport/testing` 1.2.0, which FeltKit pins. Two gaps remain: A5, found while adopting them, and A6 (rkendel1/feltkit#27). Per-candidate evidence: the AppPort rows of the migration audit and `packages/sdk/test/appport-idempotency.test.ts`.

| # | Gap | Released fix | What FeltKit did | Status |
| --- | --- | --- | --- | --- |
| A1 | The record was written only after the handler succeeded, so a crash between the effect and the record let a same-key replay run the handler again | A durable in-progress claim (`IdempotencyStore.claim` / `release`) before the handler; a replay that finds it is `CONFLICT` / `IDEMPOTENCY_OUTCOME_UNKNOWN` and is not run | `runtime/idempotency.ts` implements `claim` as a FeltDB transaction with `requireAbsent` (or `ifVersion` over an expired entry), `release` as a version-guarded delete. The agent treats `IDEMPOTENCY_OUTCOME_UNKNOWN` as an unknown outcome (`interrupted`) and a claim as no evidence. Verified by a killed process in `examples/invoices/tests` | Closed |
| A2 | A key sent to a capability without `idempotency: "supported"` was silently dropped | Refused in development (`IDEMPOTENCY_KEY_UNSUPPORTED`), logged in production (`unsupportedIdempotencyKey`) | The agent sends its attempt key only to capabilities that declare support (it used to send one to every consequential application capability, which development now refuses). Mutations keep declaring `"supported"`: that is the feature, not a workaround | Closed |
| A3 | Idempotency types not re-exported by `@appport/sdk`; no lookup by request id | Types, helpers, errors and `SessionStore` exported from `@appport/sdk`; optional `findByRequestId` | The structural `IdempotencyRecord` and `SessionStore` / `CreateSessionInput` copies are deleted; the stores implement the published interfaces | Closed |
| A4 | Only memory stores ship | By design no database-backed stores; `runIdempotencyStoreConformance` / `runSessionStoreConformance` | FeltKit keeps its FeltDB stores and runs both suites against them on local and memory FeltDB storage, with `requireClaims` and `requireFindByRequestId` (`npm run test:conformance -w @feltdb/feltkit`) | Closed |
| A5 | A handler cannot report "outcome unknown" itself. Any error it throws releases the claim, so when an integration handler throws `OUTCOME_UNKNOWN` (the API gave no definite answer), or a mutation's FeltDB commit is unconfirmed (`COMMIT_OUTCOME_UNKNOWN`), a same-key replay reaches the handler again | — | Integrations: `runtime/integrations.ts` refuses that replay from its own call record (`_feltkit_integration_calls`) with AppPort's `IdempotencyOutcomeUnknownError`; the call record stays, it is also the evidence of the external request. Mutations: the FeltDB transaction id is derived from AppPort's replay key (`idempotencyStorageKey`), so FeltDB's transaction-id binding refuses the replay (`IDEMPOTENCY_CONFLICT` → FeltKit `OUTCOME_UNKNOWN`, `committed: true`) instead of writing again; tests "A5: …" in `test/appport-adoption.test.ts` | Open. Ask: a way for a handler to end a request with its claim kept, e.g. an error flag (`keepIdempotencyClaim`) or a documented error reason the runtime treats as unknown |
| A6 | `handleRequest` validates a request's input before it asks the authorizer, so a caller without the capability's permission and with invalid input gets `INVALID_INPUT` (learning the input contract) instead of `FORBIDDEN`, and the refusal is not a denial | — | The capability's input schema, which FeltKit supplies (`runtime/capabilities.ts`), runs FeltKit's policy check first: `handleRequest` / `handleStreamRequest` are wrapped to carry the caller (AsyncLocalStorage), and the gate throws AppPort's `FORBIDDEN` / `UNAUTHORIZED` from `validate()`, which AppPort answers and reports as a denial. FeltKit's own call path authorizes again. Test: "authority before arguments on AppPort too" in `test/auth.test.ts` | Open. Ask: authorize before validating input when `authorization` does not depend on the input (or an authorizer flag to be consulted first) |
| A7 | `HttpBinding` (mapped mode) answers 500 for any code outside AppPort's standard set, including namespaced extension codes and codes a capability's integration contract declares (`failures[].code`), with no way for the application to give them a status | — | FeltKit wraps the binding and sets the status for the codes it returns itself (`FELTKIT_APPPORT_STATUS`: `feltkit.FAILED_PRECONDITION` 409, `UPSTREAM_REJECTED`/`OUTCOME_UNKNOWN` 502, `UNAVAILABLE`/`NOT_CONFIGURED` 503), from the same table as its own HTTP API; `packages/sdk/test/error-contract.test.ts` | Open (found 2026-11-03). Ask: an option mapping extension codes to statuses, or using a declared failure's class |
| A8 | Subscriptions are not authorized by the application's `Authorizer`. `server/src/connection.ts#subscribe` checks the event's declared permissions against `session.permissions` only: a connection identified by a principal (FeltKit's are; FeltKit grants from its policy, never from `session.permissions`) cannot subscribe to any permissioned event, and **a subscription to `*` requires nothing and receives every event, including events the session may not observe** (spec §21.7 says it must not be delivered). Events also have no scope, so a per-tenant event (presence in one workspace) reaches every subscriber | — | FeltKit does not use AppPort events yet (FK-GAP-004 is blocked on this). Reproduction: `packages/server/test/subscriptions.test.ts` on `rkendel1/appport` branch `claude/scoped-event-authorization` | Open (found 2026-11-05). Ask: authorize subscribe *and each delivery* through the application's `Authorizer` (event ref as the capability, `{ scope }` as input), and an optional `scope` on events and subscriptions |
| A9 | `AuthorizationDecision` can deny only with `UNAUTHORIZED` or `FORBIDDEN`. A policy that hides what exists (an unknown id and a forbidden one answered alike, as `NOT_FOUND`) cannot say so in a decision | — | `feltkit({ authorize })` lets the hook throw `fail("NOT_FOUND", …)`, recorded as a denial (`authority.resource`) | Open (found 2026-11-05). Ask: an optional `NOT_FOUND` denial code (or a `conceal: true` flag) on the decision |
| A10 | The HTTP event stream (`GET /appport/events`) names every subscription `sub_sse_<index>` (`@appport/server` 1.2.0 and 1.3.0, `http.ts#events`), and the application's event bus keys subscriptions by that id across connections. A second client's subscription replaces the first's, which silently stops receiving events | — | FeltKit gives each subscription its own bus id (`runtime.ts`, wrapping `application.subscribe`); the connection still echoes the client's id. `test/events.test.ts` (two clients, one scope) | **Closed upstream; workaround removed.** `@appport/server` registers each subscription under a connection-scoped id (`connection.js`: `${connection}:${subscriptionId}`). FeltKit's wrapper is deleted; `test/events.test.ts` (several clients, one scope) passes on 1.3.2 without it |

## AppPort Services (`rkendel1/appport-services`)

Seven gaps, S1–S6 closed by the APIs released in 0.6.0, and S9 (the credential write path) closed in 0.8.0, which FeltKit pins. Each closed row names the released API, the FeltKit code that now uses it, and the test that exercises the real package. Four narrower gaps remain (S3a, S3b, S8, S9a) and one optional item (S7) is deliberately not adopted.

| # | Gap | Status in FeltKit | Released capability → FeltKit integration | Verified by |
| --- | --- | --- | --- | --- |
| S1 | No public way to check which FeltDB instance `createServices({ db })` used | **Closed.** The `_getDb` check is deleted | `services.usesInstance(db)` and `services.ownsDb`: `runtime/services.ts` refuses to start unless the services use the shared `appport-services` handle and do not own it; `ServicesHost.db` is `services.db` | `services-released.test.ts` S1, `services.test.ts`, `shared-instance.test.ts` |
| S2 | No evidence lookup; `runId` not documented; started-to-completed window undocumented | **Closed.** The direct `service_effect_evidence` read is deleted | `services.evidence.findByRunId(runId, { tenantId, limit })` behind `ServicesHost.evidence()`; `ActivityLog.serviceEvidence*` uses it, Studio's activity drawer shows its aggregate `state` and `truncated`. A `started` record (no completion) is reported as outcome unknown; a truncated lookup proves nothing, so reconciliation treats it as unknown | `services-released.test.ts` S2 (completed, denied → failed, an in-flight effect → `started`), `shared-instance.test.ts`, `services.test.ts` |
| S3 | No health or status API | **Closed** for service state. The private-collection status logic is deleted from `runtime/services.ts`; `server/admin.ts` no longer probes collections | `services.health({ tenantId })` drives `ServicesHost.status()` (`degraded` → unhealthy, `unconfigured`/`disabled` → unconfigured, counts as the summary, `cappedCounts` named), `check()` and readiness's `background.health`, which now covers every enabled service. FeltKit adds only its own knowledge: endpoint signing references that do not resolve in its custody, and job types without a handler | `services-released.test.ts` S3/S5, `console.test.ts`, `services.test.ts` |
| S3a | `health()` counts webhook deliveries for every application in the namespace (deliveries carry no application) | Open, documented | FeltKit passes `tenantId` (= the application) and says in the Webhooks detail that delivery counts cover every application using that tenant id | — |
| S3b | No trusted host read of credential bindings: `health()` gives counts, not references; `configuration.list()`/`export()` are authorized effects that write evidence | **Mostly closed upstream (0.8.0), not adopted**: `health({ tenantId }).services.configuration.bindings[]` lists every binding (name, environment, state set/missing/revoked, version, location) without evidence, but not its reference. **Retained workaround**: `ServicesHost.credentialReferences()` still reads `ConfigurationSecrets` (name and reference only) to report whether each reference resolves in FeltKit's custody | Using the authorized read would write evidence on every Studio refresh, and evidence writes trigger the next refresh. Ask: an unauthorized, counts-free host read of binding names and references (or a `health()` option listing unresolved references against the host's custody) | — |
| S4 | Webhook deliveries had no read capability | **Closed.** The `getWebhookDelivery` wrapper under `webhooks.read` is deleted (`ServicesHost.observe` removed) | The agent's delivery diagnosis invokes `webhooks.deliveries.read` (and `webhooks.read` for the endpoint) through `services.invoke()` as the task owner; roles need `webhooks.deliveries.read` (granted by `webhooks.*`) | `services-released.test.ts` S4: an owner with `webhooks.*` reads it; an agent with only `webhooks.read` is refused and the refusal is recorded |
| S5 | Version not exported | **Closed.** The `package.json` path lookup and the version gating (`SHARED_INSTANCE_SERVICES`, `supportsSharedInstance`, the 0.4.x "composed" path) are deleted | `VERSION` in service status; `@appport/services/package.json` (now exported) in `scripts/release-check.mjs` and tests | `services.test.ts`, `services-released.test.ts` S3/S5, `npm run test:release` |
| S6 | No export/import of non-secret configuration (finding L6) | **Closed** | `feltkit config export [--out]` and `feltkit config import <file> [--dry-run] [--overwrite] --env production` call `services.configuration.export/import` as a host-only FeltKit principal holding exactly `configuration.read/write`, `webhooks.read/register/remove`, `schedules.read`. Credential bindings are reported for a person to attach; schedules are reported as skipped (their jobs would run as the transfer principal, which FeltKit cannot resolve) | `services-released.test.ts` S6: development → production through the CLI; no secret value in the document, output, or production records; a tampered document with a value is refused |
| S7 | Management pages fetched absolute paths | **Released, not adopted** | `createManagementRouter({ basePath })` fixes path shadowing only. Sharing the application's origin would put the packaged pages' inline scripts (they need `script-src 'unsafe-inline'`) and the console's session cookie on the application's origin, so an XSS in either could drive the other. The console stays on its separate loopback origin, development only | `console.test.ts` |
| S8 | Webhook replay makes the replayer the delivery's owner and accepts a delivery that already succeeded (re-checked in 0.7.0: `replayWebhookDelivery` still resets status and sets `principal` to the caller) | Open. Production replay stays disabled | Ask: replay that keeps the original durable principal and refuses `delivered` deliveries | `production-ops.test.ts` |

| S9 | No credential write path: Services took a read-only custody (`ScopedSecretsResolver`), so no screen could accept a key and users pasted keys into reference fields | **Closed (0.8.0)** | `createServices({ credentials })` takes FeltKit's `SecretCustody` (`runtime/credentials.ts`: environment variable, else the encrypted development vault; production read-only unless opted in). Studio (Models, Integrations, Services → Credentials) and `feltkit credential set` / `model set --api-key-stdin` store through `credential.store` as the caller; Studio reads state through FeltKit's own custody (`describe`), not `credential.status`, for the same refresh-loop reason as S3b | `credential-custody.test.ts`, `credentials.test.ts` |
| S9a | No capability to remove stored material: `SecretCustody.remove` exists, but there is no `credential.remove` (or similar) effect, so a removal is not audited by Services | Open | FeltKit authorizes a removal with the application's policy (the `credential.store` permission) and records it in its activity log; Services' `SecretVersions` metadata keeps the last stored version. Ask: a `credential.remove` consequential capability calling `custody.remove` with audit | `credential-custody.test.ts` |
| S10 | Services' collections and fields were internal to `@appport/services`, so an application-scoped FeltDB contract (Managed FeltDB) could not declare them | Fixed in `@appport/services` 0.9.0 (`servicesContract`, rkendel1/appport-services#35) and 0.9.1 (its tenant equality indexes, without which Managed FeltDB refuses every tenant-scoped read; rkendel1/appport-services#36) | `feltkit contract` and `feltkit deploy --target hosted` compose `servicesContract(enabled + configuration)` unchanged; the services' own tests keep it true to every write path | `contract.test.ts`, `tests/e2e/deploy-targets.test.mjs` |
| S11 | The transaction context (`services.transaction(tx => tx.queueJob / tx.queueWebhookDeliveries)`) wrote audit records its own `servicesContract` did not declare: `job_audit_events.jobType` and `webhook_audit_events.eventType` (0.13.0, `runtime/transaction-services.js`; each audit record's key and its `id` field were also two different UUIDs). Under an enforced state contract (FeltDB 0.18) such a transaction was refused (`VALIDATION_FAILED: record contains an unknown field jobType`) | **Closed and adopted.** Fixed in rkendel1/appport-services#42, published on npm as `@appport/services` **0.14.0** (the changelog's "0.13.1" entry; 0.13.1 itself was never published, and 0.14.0's dist differs from 0.13.0 only in these files). FeltKit's range `>=0.13.1 <1.0.0` resolves to 0.14.0. FeltKit creates after-commit jobs and webhook deliveries in the transaction that marks the outbox record done (`ServicesHost.performInTransaction`), once per committed effect. Still open, separately: `jobs.enqueue` / `emitWebhookEvent` take no idempotency key (low priority now that creation is transactional) | Found while implementing docs/TRANSACTIONS.md decision C | `test/transactions.test.ts` (creation with the done mark, a refused creation, recovery after a restart), `tests/e2e/outbox-lifecycle.test.mjs` (FeltKit, AppBoundry source and package) |
| S12 | The gateway reports any refused job run as `DENIED: AuthBoundry denied jobs.execute`, dropping the authorizer's reason (FeltKit's says "no active session or API key" or names the missing permission); a job refused with `FORBIDDEN` by its handler is retried until its attempts run out | Open (found 2026-11-03) | Test callers now hold sessions (`createTestApp().as`), and `runServices()` returns `failed: { jobs, deliveries }`; `packages/sdk/test/testing.test.ts` | Ask: carry the decision's `reason` into `lastError`; treat a handler's `FORBIDDEN` as terminal |

Not upstream gaps, recorded so they are not mistaken for workarounds: `RESERVED_COLLECTIONS` in `app.ts` names the services' storage collections so an application collection cannot collide with them on the shared instance, and the reactivity reads (`files`, `notifications`, `ConfigurationVariables`) name the collections a service call touches so live queries refresh. Both depend on storage names the package does not export (ask, low priority: export the collection names, or a change notification per service). Tests that read raw service collections do so to prove physical placement on the shared instance or to scan every record for a secret.

## Not upstream: FeltKit's own work

These can look like upstream gaps but need no change in another package. They stay on FeltKit's roadmap.

| Gap | Why it is FeltKit's |
| --- | --- |
| Production console, and production approval, retry and settling of agent actions | The services' management router and FeltKit's approval logic already exist. What's missing is an authenticated production host with real identity instead of dev users. |
| Durable work resolves its principal from the creator's most recent session (finding L7) | How a principal is resolved is FeltKit's choice; AppPort Services re-authorizes each attempt as designed. |
| Linking code changes to tasks (commit and CI evidence) | FeltDB evidence already supports `external` references; `feltkit_agent_note` doesn't accept them yet. |
| Untested mounted surfaces: schedules, intelligence, the secrets page, key rotation, delivery replay, Data edits | Missing tests only. |
| Monitoring, metrics, alerting; record-level admin in production | New work, either in FeltKit or in external infrastructure. |
| Whether `.flow` is a contract derived from TypeScript | A design decision to make with FeltDB, not a defect on either side. |
| The agent always invokes version 1 of a capability | Found during the AppPort 1.4 adoption (2026-10-28): for a capability with several versions the agent describes the latest but calls `version: 1`. A proposed action has to record the version it was proposed for; a FeltKit agent-lifecycle change, not an upstream gap. |
| Durable approval through FeltDB Durable Work | Since 0.16.0 the published client exposes FeltDB's approval lifecycle (`WorkloadClient.approve/reject`, `AWAITING_APPROVAL`), but only against a FeltDB server: `db.workloads` does not work on the embedded runtime (F10). FeltKit keeps its own approval in the action lifecycle, which works everywhere. Unverified: whether a Managed FeltDB runtime key may admit and approve workloads. |

## Sequencing

Close the three correctness gaps first, then the private reads, then exports. Each change can ship on its own. FeltKit removes its workaround once the release that carries the fix is pinned.

| Order | Gap | Owner | What FeltKit removes |
| --- | --- | --- | --- |
| 1 | F1 subscriptions miss transactional writes | FeltDB | Fixed in 0.14.0; journal polling kept until F7 (a database-level change listener) |
| 2 | A1 durable in-progress claim | AppPort | Done (1.4.0): FeltKit's store implements claims; nothing removed, the agent maps "outcome unknown" to `interrupted` |
| 3 | S2 evidence lookup and `runId` contract | AppPort Services | **Done (0.6.0):** the direct `service_effect_evidence` read in `runtime/activity.ts` |
| 4 | F2 and F3 task, handoff and execution lookups | FeltDB | **Done** (0.15.0): the three scans and their caps are gone; a once-per-process read remains for executions created before 0.14.0 |
| 5 | S1 public instance identity | AppPort Services | **Done (0.6.0):** the `_getDb` check in `runtime/services.ts` |
| 6 | S3 `health()` | AppPort Services | **Done (0.6.0):** status logic built from private collections in `runtime/services.ts` and `server/admin.ts`. Remaining: the `ConfigurationSecrets` read (S3b) |
| 7 | F4 Cancelled state, persisted `resume()` | FeltDB | **Done** (0.15.0): cancelled executions are `Cancelled`; no manual Waiting-then-Observing writes |
| 8 | A2, A3 key warning and type exports | AppPort | Done (1.4.0): the structural `IdempotencyRecord` and `SessionStore` copies are deleted |
| 9 | S4, S5 delivery capability, exported version | AppPort Services | **Done (0.6.0):** the `webhooks.read` wrapper; the `package.json` path lookup and version gating |
| 10 | F5, F6 file lock, local content store | FeltDB | **F5 done** (0.15.0): FeltDB's owner lock replaces the `runtime.json` ownership checks for local state. **F6 not adopted**: the content store has no deletion (F8) and no memory runtime (F9); `_feltkit_file_content` stays, now written before the metadata commit |
| 11 | S6 configuration export and import | AppPort Services | **Done (0.6.0):** `feltkit config export|import` moves development configuration to production |
| 12 | A4, S7 FeltDB-backed stores, `basePath` | AppPort, AppPort Services | A4 done (1.4.0/testing 1.2.0): the FeltDB stores stay in FeltKit, checked by AppPort's conformance suites. `basePath` is released but the separate console origin stays (S7) |

## Review 2026-11-02

Re-checked every open item against `@feltdb/core` 0.17.1 (and flow_db `main`), `@appport/services`
0.10.0 and AppPort 1.4.0 (no newer release), and FeltKit 0.3.7's sources.

**Changed by this review**

| id | Was | Now |
| --- | --- | --- |
| F12, F15, F16 | Fixed upstream, awaiting a release or the managed deploy | Closed: released, and the managed service runs 0.17.1 |
| F10 | Open | Partly closed (approval state and a bound client, server-only) |
| N1 | `overrides` forcing one `@feltdb/core` in the root and every example and starter (Services 0.9.1 pinned 0.15.0) | **Removed, and the cause fixed upstream**: `@appport/services` 0.11.0 takes `@feltdb/core` as a peer dependency (`>=0.16.1 <1.0.0`), so it always uses the app's copy. FeltKit floats both (`>=0.17.1 <1.0.0`, `>=0.11.0 <1.0.0`) and ships npm's latest of each; `scripts/release-check.mjs` refuses any override, a second copy, or a lockfile behind npm's latest |
| N2 | `RESERVED_COLLECTIONS` (`src/app.ts`), a hand-copied list, lacked Configuration's custody collections (`Secrets`, `SecretVersions`, `SecretAuditEvents`) | **Fixed**, and `services-released.test.ts` now fails when the list drifts from Services' exported `SERVICE_COLLECTIONS`. No collision was possible: application collection names must start with a lowercase letter |

**Still open upstream (asks unchanged):** F7 (change listener; sharpened above for FeltDB servers),
F8, F9, F11, A5, S3a, S8, S9a.

**Workarounds that could now be replaced (not done yet; each is a refactor with its own tests)**

| id | Where | Replacement |
| --- | --- | --- |
| S3b | `runtime/services.ts` (`credentialReferences`, a direct `ConfigurationSecrets` read) | `health().services.configuration.bindings` for presence and state; the reference is still missing upstream, which Studio needs to merge with webhook signing references. Narrowed ask: include the reference, or a host-only `bindings({ tenantId })` |
| N3 | `server/admin.ts` (`servicesCatalog`) reads `notifications`, `webhook_endpoints` and `webhook_deliveries` directly; the comment in `runtime/services.ts` saying `ConfigurationSecrets` is the only such read is wrong | `webhooks.listWebhookEndpoints(tenantId)` / `listWebhookDeliveries(...)` (trusted, no evidence). Notification types have no host read: ask upstream |
| N5 | Service collection names written out in `server/index.ts` and `runtime/services.ts` | Services' exported `SERVICE_COLLECTIONS` |
| F2/F3 residue | `runtime/agent.ts` filters tasks client-side and reads `_flow_agent_executions` once per process for executions created before FeltDB 0.14 | Can be deleted once no pre-0.14 state is supported; Managed, Vercel and Cloudflare deployments never had any. On an application-scoped authority `_flow_*` reads need `composition:read` (FeltDB 0.17.0), so that read may be refused there (unverified; reached only for a task with no linked execution) |

**Deliberate private reads (recorded, not asks):** Studio's data explorer over platform collections
(`server/admin.ts` `PLATFORM_COLLECTIONS`, development only; its counts should be bounded).

**Adopted:** `@feltdb/core` 0.17.1 (its core source is identical to 0.16.1), once `@appport/services`
0.11.0 stopped pinning its own copy. FeltDB `main`
has unreleased application state contracts and restrict-on-delete integrity that overlap `feltkit
contract` and `s` schemas: evaluate when released.

**Still unverified:** a real write against the live managed service; whether a Managed FeltDB runtime
key may use Durable Work or `/v1/events`; size limits on `_feltkit_file_content` rows on Managed
FeltDB; whether the published transaction types now cover the fields `runtime/data.ts` passes with
`as any`; that AppPort Services' job and delivery leases are safe with several instances (Vercel and
Cloudflare `--instances`).


## Review 2026-11-03

Re-checked against the releases published 2026-11-03: `@feltdb/core` **0.20.0** (npm's latest; there is
no 0.19.0), `@appport/core` **1.5.0**, `@appport/sdk` **1.4.1**, `@appport/server` 1.1.6,
`@appport/testing` 1.2.1 and `@appport/services` **0.14.0**. Each FeltDB item was measured with a
probe script against 0.18.0 and 0.20.0 (memory and file runtimes), not read off a changelog. AppPort
and Services were compared by diffing the published packages.

**What changed upstream, and what it means here**

| Release | Change | Effect on FeltKit |
| --- | --- | --- |
| `@feltdb/core` 0.20.0 | `collection.find()` matching more than 1,000 records without a `limit` is refused (`QUERY_LIMIT_EXCEEDED`). Version tokens (`fv1:<history>:<version>`) for record versions issued by a server, bounded-query plan summaries, `insert` stores a record under its `id` field | **Breaking for FeltKit 0.3.12 and earlier**, which read whole collections with `find()`: on 0.20.0 `ctx.db.find`/`count` failed with `INTERNAL`, backup threw, and activity pruning failed quietly past 1,000 records (measured). See F20. Version tokens are not adopted (FeltKit's local runtimes issue no tokens) |
| `@appport/core` 1.5.0, `@appport/sdk` 1.4.1 | Exports `assertBindingAuthoritative`; `server-internal` exports test hooks (`crashAt`, `barrierAt`). The SDK release is a dependency bump. No change to request handling or idempotency | None. **A5 and A6 stay open.** FeltKit stays on its exact pins (core 1.4.0, sdk 1.4.0) |
| `@appport/services` 0.14.0 | Exactly the S11 fix (contract declarations of the transaction context's audit fields) | S11 closed and adopted (above). The `credential.remove` operation in its manifest is `intelligence.credential.remove`, which predates it: **S9a stays open** |

**Measured and still open (no gap closed by assumption)**

| id | Measurement on 0.18.0 and 0.20.0 |
| --- | --- |
| F7 | No database-level change listener exported or on the instance |
| F8 | No content-deletion method (`releaseContent`/`deleteContent`/`removeContent` absent) |
| F9 | The memory runtime refuses `storeContent` (`CONTRACT_UNSUPPORTED`); `capabilities().content` is `false` |
| F10 | `capabilities().durableWork` is `requires-server` |
| F11 | Not changed (no `requireApproval` enforcement found) |
| F17 | A write with `expiresAt: undefined` is refused: `VALIDATION_FAILED keys:k1: invalid value for expiresAt` |
| F18 | Evolving to a contract without a non-empty collection is accepted; `compareStateContracts` reports it `{ kind: "removed", effect: "additive" }` |
| A5, A6 | No change in AppPort 1.5.0 |
| S3a, S3b, S8, S9a | No change in Services 0.14.0 |

**Found in this review and fixed in FeltKit (release-blocking correctness)**

- **Silent truncation at 100 records on the supported FeltDB 0.18.0** (F20). `ctx.db.find` without a
  `limit` returned at most 100 records and `ctx.db.count` at most 100, with no error. The same defect
  was in every internal reader that went through it, and other internal readers stopped at fixed caps
  (`integrations.calls()` took 500 records in id order and then sorted them newest first; saved
  models stopped at 200; deployment and change history at 1,000). Each now pages FeltDB's cursor.
- **Tasks lost actions past 100 memories** (F21).
- **Backup loaded whole collections and whole files.** It now streams (docs/BACKUP.md §4).
- **Activity retention could fail without trace.** A failed prune is retried on the next entry and
  reported by `feltkit readiness` (`operations.activity-retention`).

Evidence: `test/large-collections.test.ts` (101, 1,001 and 1,004 records returned and counted; 10,000
read completely through `find`, `count` and `query`'s cursor; a mutation's reads over 1,004 records
with its own pending writes; 1,001 activity entries pruned, with a failed prune reported and retried;
1,001 records backed up, verified and restored through files), `test/platform-large-state.test.ts`
(`change.verify` against 1,001 development records, then `change.apply` and `deploy.apply` with 1,001
production records, data intact after each cutover), and the 105-action test in
`test/agent-lifecycle.test.ts`. Run against the code before the fix on FeltDB 0.18.0, every one of these
fails: 100 returned where 101, 1,001, 1,004 or 10,000 were stored; 100 actions listed of 105; production
`count` 100 after deployment.

**Dependency boundary.** This review first held `@feltdb/core` below 0.20.0. `main` has since adopted
0.20.0 (`>=0.20.0 <1.0.0`, rkendel1/feltkit#45), which without this fix fails past 1,000 records; with it,
the regression tests above pass on 0.20.0, so no ceiling is set. `scripts/release-check.mjs` accepts a
ceiling below 1.0.0 should a later FeltDB release need one. Measured with the fix on `main` + #45
(FeltDB 0.20.0, one copy): SDK 321 of 321, conformance 50 of 50, create-feltkit 7 of 7, the examples,
the release check, and the first-run and outbox-lifecycle e2e (18 of 18). On 0.18.0 before #45: SDK 319
of 319 (two browser tests were intermittent on one of three full runs and pass alone).

**Workarounds that can be removed with released APIs (not done in this change)**

| id | Where | Replacement |
| --- | --- | --- |
| N3 (part) | `server/admin.ts` reads `webhook_endpoints` and `webhook_deliveries` directly for the services catalog | `webhooks.listWebhookEndpoints(tenantId)` and `listWebhookDeliveries(tenantId, endpointId?, limit?)`: trusted host reads that write no evidence (present in 0.14.0). Notification types still have no host read |
| N5 | Service collection names written out in `server/index.ts` and `runtime/services.ts` | Services' exported `SERVICE_COLLECTIONS` (0.9.0 and later) |
| F2/F3 residue | `runtime/agent.ts` reads `_flow_agent_executions` (now paged) for executions created before FeltDB 0.14 | Delete once pre-0.14 state is no longer supported (a product decision) |
| S3b | `credentialReferences()` reads `ConfigurationSecrets` (now paged) | Partly: `health().services.configuration.bindings` gives presence and state, not the reference |

**Still unverified:** everything listed under "Still unverified" in the 2026-11-02 review; the
paged reads against a FeltDB server or Managed FeltDB. There, FeltDB's own `find()` already answered
through the same bounded query `db.query` sends, so the requests have the same shape (now repeated per
page); not run here, because the deploy-target e2e tests need a FeltDB server binary. **And the real
AppBoundry host**: an artifact's `ctx.db.find`/`count` are answered by AppBoundry's own host
(`@appport/appboundry`, another repository), not by FeltKit's `Reader`. FeltKit's
`createArtifactTestApp` host is fixed here; whether AppBoundry's host reads FeltDB with `find()` (and so
truncates at 100 on 0.18 or refuses past 1,000 on 0.20) is not verified. Ask AppBoundry to run the
1,001-record scenarios of `test/large-collections.test.ts` against its host.

# Guarantees and known limitations

This page states what FeltKit guarantees, what it inherits from FeltDB, AppPort, and
AppPort Services, and what it does not do yet.

## State

| Guarantee | Scope |
|---|---|
| One FeltDB instance per environment per process | Enforced by `InstanceFactory`; verified by `shared-instance.test.ts` |
| Mutations are atomic | All writes through `ctx.db` in one mutation commit in one FeltDB transaction, or none do |
| Durability | The local runtime persists each commit before returning (FeltDB's file runtime). Verified across restarts. |
| Schema validation | Every write through `ctx.db` and the dashboard, with the full FeltKit schema. |
| Schema enforcement | On local and memory state, FeltDB enforces the state contract the collections compile to (types, required fields, no undeclared fields or collections, `s.ref` references with restrict on delete, unique constraints), on every write from any component. See "Schema lifecycle". |

### Schema lifecycle

`runtime/state-contract.ts`; tests `schema-lifecycle.test.ts` (local state, across restarts)
and `schema-lifecycle-artifact.test.ts` (artifacts).

**Guaranteed:**

- **The installed contract is the declared one, or calls are refused.** At start and reload,
  the store's active contract is compared with what `feltkit/` declares. When they differ
  and the change can't be installed, no function runs: stored records are never handed to
  code that declares a different schema.
- **A change is installed only over records that satisfy it.** FeltDB re-validates every
  governed record (fields, references, unique constraints) inside one transaction. That
  transaction holds the pending `app.migration()` writes, each conditioned on the version
  of the record it read, plus the history record. It is refused as a whole otherwise.
- **A refused change leaves everything as it was.** The previous contract stays active, the
  data is untouched, and code declaring the previous schema keeps working.
- **Removing a collection that still holds records is refused.** FeltDB itself would
  accept it and leave the records unreachable (UPSTREAM-GAPS F18). Moving records out of a
  collection being removed takes two evolutions:
  1. The new schema plus the collection, with every migration write.
  2. Drop the collection, now empty.

  A stop between them leaves a valid, enforced schema, and the next start finishes the job.
- **Each migration runs once per store.** It is recorded by name in `_feltkit_migrations`,
  in the same transaction as its writes.
- **Adoption.** A store written before schemas were enforced is adopted at the first start
  when its records satisfy the declared schema; nothing is rewritten.

**Not guaranteed:**

- **Large migrations.** An evolution is one transaction, so a migration over a large
  collection is bounded by what one transaction can hold. Split it: install an optional
  field, backfill in batches, then require it.
- **A store whose old records do not satisfy the declared schema keeps serving without
  enforcement.** It is flagged `unverified` in `feltkit dev`, readiness, `inspect` and
  `feltkit migrate`, rather than taking an upgraded app down.
- **The structural subset only.** Length, range and nested-shape rules are FeltKit's
  write-time validation, not the contract's.
- **FeltDB servers and Managed FeltDB** enforce the contract published to them; FeltKit
  does not install it there. The contract `feltkit contract` writes declares the same fields,
  required/nullable, enums, references, unique constraints and indexes as the local contract
  (`test/contract-parity.test.ts`). A contract written by a release before that parity fix
  lacks them, and the app refuses to start against it until the current one is published.

### Mutation isolation

A mutation commits only if everything it read is still as it read it. FeltDB checks
this inside its commit lock; a failed check rejects the whole transaction with
`CONFLICT` and nothing is written.

| Read inside a mutation | How it is checked at commit | Detects |
|---|---|---|
| `get(id)` | `ifVersion` / `requireAbsent` precondition on that record | The record changed, appeared, or was deleted |
| `find(filter)`, `count(filter)` with at least one field | FeltDB read basis on the equality predicate, captured before the read | Any matching record changed, appeared (phantom), disappeared, or stopped matching — by any writer |
| `query({ where })` with some `eq` clauses | Read basis on the `eq` clauses only (range clauses dropped) | Same as above, for a superset of the read: may report conflicts the range would have excluded, never misses one |
| `find()`/`count()` with no filter, or `query` with only range clauses | The collection's change marker (`_feltkit_collections`), touched by every commit made through `ctx.db` or the dashboard | Any commit to the collection through FeltKit. **Not** writes made through `ctx.unsafe.feltdb`. |
| Records the mutation wrote | `ifVersion` on updates and deletes, at the version the mutation **first read** (a `get` before the `patch`); `requireAbsent` on inserts | Lost updates, including a change committed between the handler's read and its write |

Records `ctx.db` returns (`get`, `find`, `query`, and the results of `patch`/`replace`) are
the handler's own copies, and so are the values it passes to `insert`, `patch` and
`replace`. Changing a returned record changes nothing stored and nothing another request
reads; only a write does. (Before this change `find` and `query` returned FeltDB's stored objects
on the local runtimes: changing one changed later reads in the process without a write and
failed the mutation's own read fence with a false `CONFLICT`.) Tests:
`packages/sdk/test/data-isolation.test.ts`.

Demonstrated in `packages/sdk/test/isolation.test.ts` with interleaved mutations:
lost update, phantom on a uniqueness check, write skew over a predicate, range and
unfiltered reads, a conflicting mutation writing nothing, and the corresponding cases
that must commit (disjoint predicates, concurrent blind inserts).

**What this is:** within FeltDB, a committed mutation's reads were all current at
commit time (optimistic concurrency with predicate fencing).

**What this is not:**

- A consistent snapshot across reads *while* the handler runs. Two reads in one
  handler can observe different committed states; if either changed, the commit fails.
- Checked for read-only mutations. A mutation that writes nothing commits nothing, so
  nothing is checked. Queries are never checked.
- Retried. A `CONFLICT` writes nothing; FeltKit leaves retries to the caller because
  handlers may have side effects. A read-set conflict says `retryable: true` and can be retried as is. One with
  `details.feltdbCode: REVISION_NOT_ACTIVE` means a FeltDB contract was promoted: the
  request was built for the previous contract, so decide whether it still makes sense first.
- Conflict-free under contention. Fences are conservative: whole-collection reads
  conflict with any concurrent commit to that collection.

### Sequences

`ctx.db.sequence(name)` reads the sequence's committed value (`_feltkit_sequences`) and
writes the new one in the mutation's transaction, conditioned on the version it read. So:

- Two commits never get the same number, on any runtime and across processes: the second
  of two mutations that read the same value fails with `CONFLICT` and writes nothing.
- Numbers follow commit order, and call order within one mutation, with no gaps; a
  mutation that throws, is refused, or writes nothing else consumes none.
- Order is per stream (the name); there is no order between streams, and different streams
  never contend.
- Not guaranteed: throughput under contention on one stream. Mutations drawing from one
  stream serialize: the later gets `CONFLICT`, or is re-run when it opted in
  (`retry: { sequenceConflicts }`) and used no `ctx.services`.
- The same on FeltKit's runtime and in AppBoundry artifacts (transactions@1, AppBoundry 1.5.0).

### After-commit effects

`ctx.afterCommit.{notifications.send, webhooks.emit, jobs.enqueue}` writes an outbox record
(`_feltkit_outbox`) in the mutation's transaction:

- No effect for a mutation that threw or whose commit was refused.
- An effect for every committed mutation. It is performed right after the commit as the
  caller, and otherwise by the services worker (as the caller's current principal) once a record
  has been pending for 30 s, or performing for 5 min. A record is claimed with a version-checked
  write, so two processes do not perform it together.
- A job or webhook delivery is created in the same FeltDB transaction that records the effect
  done, so it exists once per committed effect, whatever stops when. Notifications carry the
  outbox id as their idempotency key, so a repeat is not delivered twice.
- Creation is exactly once, not execution: a job's run and a webhook's delivery to its endpoint
  are AppPort Services' own retries (at least once).
- The effect's own failure (a refused permission, a disabled service) does not undo the
  commit: the record is `failed` with the error, and the log says so. A failed record is
  never retried on its own; an operator retries it (`feltkit outbox retry <id>`, AppBoundry
  `admin outbox retry <id>`), keeping its attempts.
- The same on FeltKit's runtime and in AppBoundry artifacts. Details: TRANSACTIONS.md.

### Not guaranteed

- Service effects (`ctx.services.*`) and activity entries are separate commits from
  the mutation's transaction. A mutation that uploads a file and then fails leaves the file.
  Use `ctx.afterCommit` for notifications, webhook events and jobs that must not outlive a
  failed mutation.
- Nothing is atomic across FeltDB and external systems.
- `ctx.unsafe.feltdb` writes are not validated, not transactional with the mutation,
  not attributed to it in the activity log, and invisible to whole-collection fences.
  It reaches only collections the application declares that do not belong to a workspace:
  platform collections (sessions, accounts, memberships, activity, the audit trail, API keys,
  configuration) and workspace collections are refused with `FORBIDDEN`. A transaction id it
  chooses must start with `app_` (other ids are FeltKit's own). Before 0.3.19 it
  reached the whole instance (docs/SECURITY-REMEDIATION.md).
- File bytes are stored in the same FeltDB instance (`_feltkit_file_content`, with
  their SHA-256, re-hashed on every read) before the file record is committed, so a
  record never points at bytes that were not stored; if the record cannot be committed
  the bytes are removed. Deleting a file removes its bytes. FeltDB 0.15's content store
  is not used: it cannot delete content, and the memory runtime has none (UPSTREAM-GAPS
  F6, F8, F9).
- Files are capped at 1 MiB by default (`services.files.maxBytes`).
- A mutation called with an idempotency key commits under a FeltDB transaction id
  derived from that key. If its commit is unconfirmed, a same-key retry is refused with
  `OUTCOME_UNKNOWN` (`committed: true` when FeltDB shows the first attempt committed)
  rather than written again; a retry with a new key is a new request.
- A FeltDB server that cannot issue read bases makes every mutation that uses
  `find`/`query`/`count` fail with `UNAVAILABLE` rather than commit unchecked.

## Errors

Every failure that reaches a caller has a stable `code`, the same HTTP status on FeltKit's
function API (`/api`) and on AppPort (`/appport`), and an explicit retry answer: `retryable:
true` in the error when sending the same request again can succeed without anything else
changing; absent (FeltKit) or `false` (AppPort) otherwise. MCP tool errors carry the AppPort
code in their text. `FeltKitClientError` exposes `code` and `retryable`.

| Failure | `/api` code | AppPort / MCP code | HTTP | Retryable |
| --- | --- | --- | --- | --- |
| Malformed input | `INVALID_ARGUMENT` | `INVALID_INPUT` | 400 | no |
| No or invalid session | `UNAUTHORIZED` | `UNAUTHORIZED` | 401 | no |
| The caller lacks the permission | `FORBIDDEN` | `FORBIDDEN` | 403 | no |
| A record or function of this app is missing | `NOT_FOUND` | `NOT_FOUND` | 404 | no |
| The current state does not allow it | `FAILED_PRECONDITION` | `feltkit.FAILED_PRECONDITION` | 409 | no |
| A record this mutation read changed before commit | `CONFLICT` | `CONFLICT` | 409 | **yes** |
| Any other state conflict (duplicate unique value, already applied) | `CONFLICT` | `CONFLICT` | 409 | no |
| An external API (`app.integration`) refused the request (4xx) | `UPSTREAM_REJECTED` | `UPSTREAM_REJECTED`, `details.status` = the API's status | 502 | no |
| The request was sent; the outcome is not known | `OUTCOME_UNKNOWN` | `OUTCOME_UNKNOWN` | 502 | no: verify it |
| A dependency is unreachable | `UNAVAILABLE` | `UNAVAILABLE` | 503 | **yes** |
| A credential or URL an operator must provide is missing | `CONFIGURATION` | `NOT_CONFIGURED` (`details.hint`) | 503 | no |
| Unexpected | `INTERNAL` | `INTERNAL_ERROR` | 500 | no |

An external API's 401 or 404 is `UPSTREAM_REJECTED`: it is about FeltKit's credential for that
API or the API's own records, never the caller's session or this application's data, so it is
never `UNAUTHORIZED`, `NOT_FOUND` or a retryable `CONFLICT`. It is the code the operation's
published contract declares (`appport.integration/1` `failures`). Tests:
`packages/sdk/test/error-contract.test.ts`.

## Topology

- The local FeltDB runtime is a single-host, single-process store. FeltDB takes an
  exclusive owner lock (`owner.lock` in the state directory) when FeltKit opens it; any
  other process — a second `feltkit dev`/`start`, a CLI command, a script — is refused
  with `DUPLICATE_INSTANCE` naming the owner, and nothing is read or written. FeltKit
  never opens state in FeltDB's shared mode. CLI commands find a running server through
  `.feltkit/<env>/runtime.json` and go through its admin API instead of opening the
  state. Verified in `feltdb-release.test.ts` (F5) with a second real process.
- Production with a FeltDB server (`FELTDB_URL`) uses FeltDB's remote runtime. FeltKit's
  change feed reads the instance's operation journal; whether a remote authority exposes
  it fully is FeltDB's contract, and live updates across multiple FeltKit processes are
  not provided.

## Live queries

- The change stream requires a session unless the application has a public query.
- Within one server process, every committed write produces a change notification
  naming its collection, at least once, typically within 150 ms, to every subscriber
  that could see it. Data is always re-read through the authorized query endpoint.
- After a reconnect, clients re-run every watched query.
- **Invalidation by predicate (local state).** A query's `reads` lists the collections it
  read, then `collection#key` for each equality predicate of a collection it read only
  through predicates (`get` by id; the equality clauses of `find`, `count`, `query`,
  `search`; of a conjunction, one clause stands for it: `id`, else another keyed field,
  else the tenant field). A change event for a write committed through FeltKit carries,
  per collection, the keys of every changed record's keyed values before and after the
  write. A watched query re-runs when a change's keys meet its predicates, when a
  collection it read wholly changed, or when a change has no keys for a collection it
  read. So inserts, updates (including a record moving out of a predicate) and deletes
  re-run exactly the predicates they touch, and never fewer.
- **Keyed fields** are `id`, the fields of declared indexes and unique constraints,
  references (`s.ref`) and the tenant field. A read filtering only on other fields counts
  as a whole-collection read. Values of other fields never leave the server in any form.
- **Keys, not values.** A key is `HMAC-SHA256(K, collection‖field‖value)` (128 bits) with
  K drawn at random per server process and never sent: a client cannot compute a key, only
  compare the ones it is given, so it cannot test guessed values against the stream
  offline. What a key it holds (from one of its own query results) can tell it is that a
  record with that keyed value changed: the timing of changes, which the collection-level
  stream already revealed per collection, now per keyed value.
- **Tenant isolation of the stream.** For a tenant-scoped collection the server sends a
  change only for records whose tenant (before or after) is the subscriber's session's
  tenant; another tenant's writes are not sent at all. If a change is withheld, the
  session is looked up again (at most every 2 s) and, when it switched tenant, the client
  is told to re-run everything.
- **When in doubt, re-run.** Writes FeltKit did not commit (`ctx.unsafe.feltdb`, AppPort
  Services' stores, agent state), a description that reached the change feed after its
  journal operation, an unreadable journal, every change on a FeltDB server (whose feed is
  collection markers), and a restart (new key; the client re-runs on reconnect) all fall
  back to per-collection invalidation. Clients that understand only collection names keep
  working unchanged.

## Queries

- Queries cannot write through `ctx.db`. FeltKit does not sandbox handlers, so a query
  can still make network calls or other side effects; FeltKit does not claim purity.
- `count` reads all matching records.
- `search` reads the records matching its equality `where` in pages, in the requested
  order, until `limit` (≤ 100) match: cost is linear in the records matching `where`, not
  in the result. It examines at most 50,000 records and then fails with
  `FAILED_PRECONDITION` rather than answering incompletely. FeltDB has no text index yet
  (docs/UPSTREAM-GAPS.md F23).

## Identity

- No built-in password or OAuth sign-in. Development sign-in exists only in
  `development`/`test`. Production uses `auth.authenticate` (your identity provider) or
  tokens from `feltkit session create`.
- Roles are fixed per session at issue time; permissions are resolved from the current
  policy on every call.
- Session tokens are bearer tokens: anyone holding one acts as its principal until it
  expires or is revoked.

### Secure tokens (`ctx.crypto.token`)

Tokens are drawn from Node's CSPRNG (`crypto.randomBytes`) in FeltKit's runtime and by the host in an
AppBoundry artifact (`crypto@1`); the guest never generates them. 16–256 bytes (default 32), base64url.
Tested: `test/crypto-token.test.ts` (uniqueness, per-bit variation, bounds, artifact, refusal without
the interface); on AppBoundry's side, the appboundry-host crypto tests in `rkendel1/appboundry`.

### Application authorization (`feltkit({ authorize })`)

| Guarantee | How | Test |
|---|---|---|
| Every interface, one decision | Evaluated in the one execution path every call takes (`/api`, AppPort, MCP, agent actions, jobs) and in the AppBoundry guest | `test/authorize.test.ts` (HTTP, AppPort, a real MCP client, the compiled artifact) |
| Order | Roles, then argument validation, then `authorize`, then the handler. A caller without the role, or with invalid arguments, never reaches it | same |
| Decision and effect agree | The hook reads through the call's own `ctx.db`: a mutation's commit is checked against those reads; a change in between is `CONFLICT` and nothing is written | same ("membership revoked mid-call") |
| Revocation is live | A query's live read set includes the hook's reads; a watching client gets `FORBIDDEN` on the next run | same ("live") |
| Fail closed | A hook that throws (other than a FeltKit `FORBIDDEN`/`UNAUTHORIZED`), returns something other than a boolean or an AppPort decision, or tries to write refuses the call (`INTERNAL`) | same |
| Evidence | Denials and allows are recorded in the activity entry's `authority.resource`, beside the role decision and its id | same |

Not covered: the hook does not run for AppPort Services effects made directly by services
(those are authorized by the role policy and the services' own ownership rules), and FeltKit
does not evaluate resources with AuthBoundry (UPSTREAM-GAPS).

## AppPort Services

Services run on the application's FeltDB instance (`createServices({ db })`,
`@appport/services` 0.9.1). FeltKit refuses to start unless `services.usesInstance()`
confirms that instance. Service state is the package's own `health()`; effect evidence is
looked up with `services.evidence.findByRunId()`, and an effect with a `started` record and
no completion is reported as outcome unknown, never as success or failure. Enable each in
`feltkit({ services })`.

| Service | What runs | Verified (packages/sdk/test) |
|---|---|---|
| Files | records with audit; bytes in the same instance | persistence, authorization, upload/read/delete, restart (`services`) |
| Notifications | in-app channel, delivered inline; recipient-only | persistence, delivery, recipient-only access, restart (`services`) |
| Configuration | variables and credential references for the running environment | persistence, environment separation; the console page edits the environment the application reads (`services`, `console`) |
| API keys | created, rotated, revoked on the package's page; accepted on `/appport` and `/mcp` with `services.apiKeys.roles` | secret shown once, never listed, revocation → 401, survives restart (`console`) |
| Webhooks | signed delivery to registered endpoints; history | signed with the environment's secret, delivered as the emitter, secret in no record or log (`console`) |
| Jobs | job type → FeltKit function, run as the enqueuer, retries | executed as the enqueuer, refused for a weaker role, failure recorded, retry, refused after the enqueuer signs out (`console`) |
| Schedules | recurring jobs (needs jobs) | constructed and reported; not exercised end to end |
| Intelligence | provider/model configuration only (the package never runs a model) | selection + key stored through `credential.store` + Test against a local OpenAI-compatible and Anthropic-compatible server that checks the key header (`credential-custody`) |

- **States.** Each service is reported `unavailable` (cannot run here), `available` (not
  enabled), `unconfigured`, `configured`, or `unhealthy` (its store failed a check, a
  required secret does not resolve, or recent work failed), from the services' own
  records. Nothing is shown as working because it is enabled.
- **Durable work.** Jobs, schedules, and deliveries re-authorize every attempt as the
  principal that created them: an API key that still exists and is not revoked, or the
  most recent active session. With neither, the work is refused (`DENIED`), never run
  with less checking. Durable work is driven by the runtime's worker (every second) or
  `runtime.runServices()`.
- **Secrets.** Services hold `credential-ref:<id>` only. Values are kept by FeltKit's
  credential custody (below), resolved inside the effect, and are never stored in FeltDB,
  logged, returned, or given to the agent.
- **The console** is development-only and loopback-only. It is the package's own
  `createManagementRouter`; FeltKit supplies authentication and nothing else.
- FeltKit is single-tenant per application: the Services tenant is the application
  name. Configuration environments map `development`/`test` → `development`,
  `production` → `production`.
- Files are application-shared: any principal with `files.read` reads every file through
  `ctx.services.files`. Per-resource access is the application's: a function checks the resource
  and issues a **file link** (`files.link`, `files.uploadLink`), and the link is the authority for
  that one transfer. Download links last 5 minutes by default (at most 1 hour) and may be reused
  until then. Upload links are single use, create the file as the issuing principal (the role
  snapshot taken at issue), with the metadata the function fixed, and within its `maxBytes`. Only
  the SHA-256 of a link token is stored (`_feltkit_file_links` on the `feltkit.files` handle).
  Links are not revoked when membership changes; they expire.

## Accounts, sessions and workspaces

Full contract: AUTH.md.
- **Account sessions are current.** On every request (HTTP, AppPort, MCP) an account session is resolved from the account as it is now, and its workspace from the live membership. A disabled account, a removed membership or a changed role applies on the next request.
- **Browser sessions** are an HttpOnly cookie. A cookie-authenticated unsafe request needs the session's CSRF token, and a foreign `Origin` is refused. Bearer clients are unchanged.
- **Account e-mail secrets** are durable challenges: digest-only, at most 15 minutes, single use, superseded, with 5 code attempts and 5 issues per address and purpose per hour. Their tokens are derived with `FELTKIT_AUTH_SECRET` when delivered, and never stored.
- **Workspace data** (`{ tenant }` collections) is scoped to the session's workspace for every read and write, in FeltKit's runtime and in AppBoundry artifacts. No workspace means closed. A request cannot name another workspace's data into existence.
- **Workspace roles** are declared `roles`, ranked. Managers assign only below their own rank, nobody raises their own, and a workspace keeps a holder of its top role. Invitations are single use, expire, and are accepted only by the invited, verified address.
- **Known limits.**
  - Throttling counters are per process, and in memory.
  - Jobs, schedules and agent actions run as their principal without a workspace, so they cannot reach `{ tenant }` collections yet.
  - AppBoundry hosts resolve no workspace (FK-GAP-013).

## Agents

The FeltKit agent is FeltDB's agent runtime and agent state on the shared instance
(`runtime/agent.ts`). Verified in `packages/sdk/test/agent.test.ts`,
`agent-lifecycle.test.ts` (refusal, rejection, duplicates, concurrency, failure and
retry, timeout, cancellation, crashes, restart recovery), and, in a browser,
`studio.test.ts`.

| Guarantee | How |
|---|---|
| Durable | Tasks, checkpoints, actions, and handoffs are FeltDB agent state; each task has a FeltDB execution record. Every action state change is persisted before the next step. |
| Acts only through AppPort | Application capabilities via the application's dispatch pipeline; service operations via AppPort Services' `invoke()` and gateway. No other access to state. |
| Same authority as every interface | Actions run as the task owner. Before an approval changes anything, the owner is resolved and both the approver and the owner must be permitted to perform the action; otherwise the approval is refused, the reason is recorded in the action's history, and the action stays proposed. If the owner cannot be resolved (no session, not a dev identity), approval fails closed; no identity is substituted. |
| Approval | Consequential actions (AppPort's and AppPort Services' effect classes) wait for a person (`type: "user"`) who may perform them; agents cannot approve; there is no approve tool. |
| Mandatory approval | A mutation declared `approval: "required"` cannot be run directly by an agent, service or API key on any interface: FeltKit's HTTP API, AppPort, MCP, a job or schedule it queued. The refusal is `FORBIDDEN` with `details.approval: "required"`, recorded as a denial, before arguments are checked. It runs only inside the execution of an approved action for exactly that capability (an in-process context that no header, envelope field or transport name can set), as the proposer, whose own `access` is still checked, after a person who may perform it approves. The run's activity entry carries `authority.approval` (task, action, approver). People (`type: "user"`) call it directly. The check is on the principal type the session carries: an agent that holds a person's session (for example over MCP, which also accepts user sessions) is that person to FeltKit and is not stopped. Discovery says so: the capability's description, and `feltkit_context` (`approval: "required"`, `invoke: "propose"`). An AppBoundry build refuses it. Tests: `packages/sdk/test/approval-required.test.ts`. |
| One run per approval | Each action state change is a compare-and-swap on the action's record (FeltDB `supersede` with the expected revision). Of concurrent or repeated approvals one wins; the others return the current state and run nothing. |
| Attribution | Each action records who proposed it, who approved or rejected it, the principal it ran as, the request id, timestamps, the outcome and how it was determined, and a history of every transition with its actor. Agent activity entries carry the owner as principal and the proposer and approver in their detail. |
| Evidence | Each action's activity record and its final action record are cited by a checkpoint and verified by FeltDB at commit. Pending work is rebuilt from the open actions at every checkpoint. |
| No secrets | Results are redacted before they are recorded or returned. |

**Action states.** `proposed → approved → executing → succeeded | failed | interrupted`;
`proposed → rejected | cancelled`; `approved → cancelled`; `interrupted → succeeded |
failed` (from evidence or a person); `failed → proposed` (retry, a new attempt).
`succeeded`, `rejected`, and `cancelled` are final. Other transitions are refused.

**Idempotency.** Every application mutation declares AppPort idempotency (an integration
operation does when it declares `idempotencyHeader`), and AppPort's idempotency entries
are kept in FeltDB (`_feltkit_idempotency`, 24 h). Before the handler runs, AppPort writes
a durable in-progress claim (key, request id, request digest, caller); FeltKit's store
makes it an atomic create-if-absent with a FeltDB transaction guard, so of concurrent
claimers exactly one runs. The completed record replaces the claim. A replay of the key
returns the stored response without running the handler; a replay that finds a claim
with no response (the original crashed, timed out, or is still running) is refused with
`CONFLICT` / `details.reason: "IDEMPOTENCY_OUTCOME_UNKNOWN"` and `details.requestId`, and
is not run again. The claim is released when the outcome is known (the handler threw or
never started) and otherwise kept until it expires or is resolved. A different request
under the same key is `IDEMPOTENCY_KEY_REUSED`. In development, a key sent to a capability
without idempotency support is refused (`INVALID_REQUEST` /
`IDEMPOTENCY_KEY_UNSUPPORTED`); production runs it and logs a warning. Each application
action attempt sends a stable key (`feltkit-agent:<task>:<action>:<attempt>`) to a
capability that supports it. AppPort Services' gateway records its effect evidence under
the action's request id. This is at-most-once per key, not exactly-once.

**Outcome unknown.** An action is `interrupted` when its outcome cannot be established:
it timed out (30 s by default) or was cancelled while running (FeltKit functions do not
observe the abort, so the call may still complete), or the process stopped after it
started. Interrupted actions are never replayed automatically. They keep the task
blocked until they are settled, from evidence or by a person (`resolve`, Studio "It
succeeded" / "It did not take effect"), who must be permitted to perform the action.

**Retry.** Only a `failed` action can be retried, by the owner or a person. A retry is a
new attempt with a new key and needs approval again. Nothing is retried automatically.

**Restart recovery.** When the runtime opens, it examines every open task once (FeltDB's
`listTasks`, paged)
(`agent.reconcile()`, also callable):
- `approved` with no execution started → back to `proposed`; the approval must be repeated.
- `executing` or `interrupted` → settled only from evidence of this exact request:
  AppPort's idempotency record, the function's activity entry, or AppPort Services'
  effect evidence (every effect completed). Without evidence: `interrupted`.

Recovery never runs an action. An AppPort claim without a response is not evidence
either way. **Not guaranteed:** an effect that committed but whose idempotency record,
activity entry, or service evidence was not written before a crash is reported as
interrupted, not as succeeded (a replay of its key is refused as outcome unknown). A
FeltKit mutation whose FeltDB commit fails reports an error, so AppPort releases its claim;
with a FeltDB server, a commit that failed in transit may still have applied. Cancelling a task cancels its queued
actions and aborts its running ones; while any action is interrupted, the cancellation is
refused until that action is settled. A cancelled task's FeltDB execution ends `Cancelled` with
the reason (`cancelReason`); a completed one `Completed`.

Not provided: a planner. Decisions are a playbook's (capabilities chosen by code), a
model's choice among options code built (below), or an external coding agent's, proposed
over MCP (`feltkit_agent_*` tools).

## Model decisions

A `decide` task asks the environment's model to choose among options the application
built (`ctx.agent.start({ decision })` from a mutation, or `createTask`). Implemented in
`runtime/decisions.ts` and `runtime/agent.ts`; verified in
`packages/sdk/test/decisions.test.ts` and `examples/invoices/tests`.

| Guarantee | How |
|---|---|
| One contract | Every model is a FeltDB `DecisionRuntime` (`@feltdb/core`). Built in: OpenAI chat completions (OpenAI and any compatible server: Ollama, vLLM, llama.cpp) and Anthropic messages. Any other `DecisionRuntime` (e.g. `@feltdb/webllm`) is passed as `feltkit({ agent: { decisions } })`. |
| One selection | The environment's model is AppPort Services Intelligence's selection (`{ provider, model, endpoint }` + a credential reference). FeltKit adds no registry of its own. `feltkit model show`, Studio → Models, and `GET /_feltkit/api/models` report the source, the runtime's capabilities, whether the credential resolves, and each problem with its fix. |
| Bounded by authority | Options whose capability the task owner may not perform are removed before the model sees them, and recorded as excluded. "Escalate to a person" is always offered. A choice outside the offered labels is refused (`malformed`), never mapped to the nearest option. |
| A proposal, not proof | The choice is stored as memory kind `decision` with its runtime, provider, and model, and becomes a proposal in the action lifecycle (Agents, above). It is never evidence that anything happened. A consequential option still waits for a person. |
| No silent fallback | Any failure (not configured, credential missing or refused, unknown protocol, timeout — 20 s by default, `agent.decisionTimeoutMs` — unavailable, provider error, malformed answer, unsupported decision) blocks the task with the reason and the fix; nothing is proposed, no other model is tried. `decide(taskId)` (Studio "Ask the model again") asks again once fixed. |
| Credentials | Entered once (Studio → Models' API key field, `feltkit model set --api-key-stdin`, `feltkit credential set`), kept by FeltKit's credential custody, resolved only for the request; never in the selection, responses, checkpoints, activity, or logs. |

Not provided: multi-turn agents, tool calling by the model, streaming, or probability
distributions from the built-in runtimes (`capabilities()` reports what each supports).

## Credential custody

AppPort Services (0.8.0) owns the collection contract for a credential value
(`credential.store`: authorized through its gateway as the caller, permission
`credential.store`; audited and versioned without the value; effect evidence records the
reference and version only; `credential.status` reports state without the value). It
contains no secret store: FeltKit is the host that keeps the material
(`runtime/credentials.ts`, a `SecretCustody`). Verified in
`packages/sdk/test/credentials.test.ts` and `credential-custody.test.ts`.

| Guarantee | How |
|---|---|
| One place to type a key | Studio → Models (Provider, Model, **API key**; the reference defaults to `credential-ref:<provider>` under "Advanced"), Studio → Integrations → **Set key**, Studio → Services → Credentials (set, replace, remove), `feltkit credential set <ref\|provider>` and `feltkit model set … --api-key-stdin` (hidden prompt or stdin; a value on the command line is refused). After saving, Studio shows "set (local encrypted vault, version N)", never the value. |
| Where it lives | `FELTKIT_CREDENTIAL_<ID>` wins when set (that reference is then read-only: `CUSTODY_READ_ONLY` names the variable). Otherwise, in development and test, `.feltkit/<env>/credentials.vault`: the whole document AES-256-GCM-encrypted (reference names too), bound to the application and environment, with one random 32-byte key in `.feltkit/<env>/credentials.key`; both 0600, written atomically (temporary file, fsync, rename) under a lock file shared by the server and the CLI. `.feltkit/` is gitignored and never part of `feltkit build`/`deploy` output. The test environment's vault sits beside its temporary state. |
| Production | Environment variables only: storing refuses with `CUSTODY_READ_ONLY` and says what to set. An operator may opt in to a vault with `FELTKIT_CREDENTIAL_VAULT=1` and `FELTKIT_CREDENTIAL_VAULT_KEY` (32 bytes, base64, from the host's secret manager; never written to disk; vault directory `FELTKIT_CREDENTIAL_VAULT_DIR`, else `.feltkit/production`). Then operators holding `feltkit.operations.write` and `credential.store` may store from Studio. |
| Never echoed | The value is not in FeltDB (any collection), activity, AppPort Services evidence or audit, the configuration export, server output, admin API responses, errors, or the dashboard bundle (scanned after storing through Studio and the CLI). Errors from the write path are scrubbed of the value before they are recorded or returned. A key pasted into a reference field is moved to the key field by Studio and refused by the server without being echoed. |
| Authorized | Studio stores as the chosen dev identity (`credential.store`, then `intelligence.write` for the selection); a viewer or agent role is refused. The CLI on the host stores as FeltKit's host custody principal (a system principal holding only `credential.store`/`credential.status`). Removing a stored value needs the same permission (AppPort Services 0.8.0 has no capability for it; FeltKit authorizes it with the application's policy and records it as activity). |
| Versions | Each store is a new version; earlier values are not kept (version numbers and times are). Remove erases the value and the reference reports `revoked`. |

## Integrations

`app.integration(name, { baseUrl, credential, operations })` connects an existing HTTP
API. Implemented in `runtime/integrations.ts`; verified in
`packages/sdk/test/integrations.test.ts` and `examples/invoices/tests`.

| Guarantee | How |
|---|---|
| One protocol | Each operation is the AppPort capability `<name>.<operation>`: schemas, effect class, the permission that may invoke it (required, never public), idempotency, and an `appport.integration/1` descriptor (effects, verification, failure modes with `retry` and `effect`). AppPort validates and authorizes around the call. Discovery over AppPort or MCP shows the contract, never a credential; it grants nothing. |
| Recorded before sent | A call record (`_feltkit_integration_calls`, keyed by request id) is written `started` before the request leaves, then `succeeded` / `failed` / `unknown` with the HTTP status, redacted input, output, and how the outcome was determined (`response`, `verification`, `person`). Activity kind `integration`. |
| Honest classification | Unreachable before sending, or a 4xx other than 408 → `failed`. A consequential request with no answer (10 s default `timeoutMs`), a dropped connection, a 408, a 5xx, or a 2xx without a JSON body → `unknown` (`OUTCOME_UNKNOWN`). An agent action whose call is unknown is `interrupted`. |
| No automatic repeat | An unknown call is never re-sent. An idempotent operation sends the caller's idempotency key in its declared header. A replay of that key is never sent again while the earlier call is `started` or `unknown`, or was settled only by verification: AppPort answers it from its claim after a crash, and FeltKit from the call record otherwise (AppPort releases its claim when the handler reports `OUTCOME_UNKNOWN`), both as `CONFLICT` / `IDEMPOTENCY_OUTCOME_UNKNOWN`. Verification that finds no effect releases a claim a crash left. |
| Settled from the API's records | `verify` runs the declared probe (an observation of the same API) as the caller, through AppPort; `@appport/integration` evaluates it. Verified → `succeeded`; NOT_FOUND → `failed`; anything else stays `unknown`. The agent's restart recovery and `resolve` consult this evidence first. |
| Credentials | A reference (`credential-ref:<id>`), resolved only for the request; never recorded, returned, or logged (an error mentioning it is redacted). |
| Configuration | `baseUrl` is a literal, an environment variable, or a development default. Production never uses the development default; readiness fails a missing, non-HTTPS, or loopback production URL. |

**`onOutcome`.** When a call's outcome becomes known (from the response or verification),
the declared mutation runs as the original caller with the call record. It is a
notification, not part of the call: it can run more than once for the same call (e.g. a
verify after a restart), so make it idempotent (the example sets the invoice's status from
the call's state). A failing hook is logged; the call record stays authoritative.

Not provided: non-HTTP transports, OAuth flows, pagination, webhooks into integrations, or
a marketplace of connectors.

## Production operations

Studio in production (`FELTKIT_DASHBOARD=1`) answers verified operators only
(docs/SECURITY.md, "Production operators"). Verified over HTTP and in a browser in
`packages/sdk/test/production-ops.test.ts`.

| Route (`/_feltkit/api`) | Needs | Notes |
|---|---|---|
| `GET /operator/session`, `POST /operator/signin`, `POST /operator/signout` | — / a grant / an operator | Sign-in is single-use per grant |
| `GET /overview`, `/capabilities`, `/services`, `/services/jobs`, `/services/deliveries`, `/agent`, `/agent/tasks/:id`, `/activity`, `/activity/:id`, `/events` | `feltkit.operations.read` | Credential references are shown with whether they resolve, never values |
| `POST /services/jobs`, `POST /services/webhooks` | `feltkit.operations.write` + `jobs.create` / `webhooks.register` | Queue a job of a declared type, or register a webhook endpoint, through AppPort Services' own invoke as the signed-in operator; the job runs as them. Recorded as activity. Webhook destinations on private networks need `FELTKIT_WEBHOOK_PRIVATE_NETWORKS=1` outside development |
| `POST /services/jobs/:id/retry` | `feltkit.operations.write` + `jobs.retry` | Failed jobs with a registered handler only; authorized and recorded as the operator; the job keeps its owner and runs as them, re-authorized. Concurrent retries: one wins, the other gets 409 |
| `POST /agent/tasks/:id/approve`, `/reject`, `/retry`, `/resolve` | `feltkit.operations.write` + the lifecycle's own checks | The action lifecycle (Agents, above) applies unchanged; additionally, in production the person who proposed an action cannot approve it |
| `GET /readiness`, `/models`, `/integrations` | `feltkit.operations.read` | Readiness checks, the model status (no credential value), integration contracts, configuration, and calls |
| `POST /models/test`, `/agent/tasks/:id/decide` | `feltkit.operations.write` (+ the agent's own checks for `decide`) | A test decision; asking the model again for a blocked review |
| `POST /integrations/:name/check`, `/integrations/calls/:id/verify` | `feltkit.operations.write` | The health path; verification runs the probe as the operator, who must hold its permission |

Intentionally **not available in production**:
- **Webhook replay.** AppPort Services makes the person replaying a delivery its new
  owner and replays deliveries that already succeeded, so the original owner's authority
  would not be preserved (docs/UPSTREAM-GAPS.md).
- **Selecting a model** (`POST /models`). Production's model is selected on the host
  (`feltkit model set --env production`).
- Data editing, function runs, capability invocation, session management,
  creating, completing, or cancelling agent tasks, "run due work now", and the AppPort
  Services console (its pages need their own origin; upstream gap S7). Data browsing
  is served read-only in production.

Settling an action whose outcome is unknown (`resolve`) always needs a note. Evidence
of that exact request (AppPort's idempotency record, the function's activity entry, the
services' effect evidence) is consulted first: if it exists, it decides the outcome and
a contradicting claim is refused (409). Without evidence, the outcome is recorded as the
person's decision (`determinedBy: "person"`, with their name and note), never as
execution evidence.

**Environment.** A production server opens only the production instance. Writes must
name the environment (`x-feltkit-environment`); a mismatch changes nothing. Ambiguous
configuration fails at startup: both `FELTDB_URL` and `FELTKIT_STATE_DIR`, or an
explicit environment that differs from `FELTKIT_ENV`. Operator sessions live in the
environment's own instance and operator keys are per environment, so neither carries
across environments. Nothing is copied from development.

## Audit trail

- One record per committed mutation (`_feltkit_audit`, `runtime.auditTrail()`), written in the
  mutation's own FeltDB transaction: the record and the writes it describes commit together or
  not at all. A mutation that writes nothing, fails, or replays an idempotency key adds none.
- Attributed: principal, workspace, authorization decision (and the approval for an approved agent
  action), function, interface, request id, FeltDB transaction id, and each write's collection,
  id and operation (never values).
- Append-only: inserted with `requireAbsent`, never updated or deleted by FeltKit, never trimmed.
  Application code cannot reach it (`ctx.db` and `ctx.unsafe.feltdb` refuse it).
- Part of the application's state: backups carry it and restore brings it back.
- Not tamper-evident against whoever operates the FeltDB instance, and refused or failed calls are
  not in it (they are in the activity log).

## Activity log

- An operational feed, not the audit trail. Recorded after the operation; a crash between commit and recording can lose an entry
  (FeltDB's commit is still durable). Recording failures are surfaced in `inspect` and
  the dashboard, never thrown at callers.
- Keeps the most recent 2000 entries. Records argument names, never values.
- In production, successful queries are not recorded by default (`activity.record`).

## Deployment

- `feltkit deploy` produces an artifact and verifies it boots; FeltKit does not host.

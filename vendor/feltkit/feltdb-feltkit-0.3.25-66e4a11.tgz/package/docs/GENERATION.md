# Model generation, tools and approvals in an application

An application can hold a conversation with the environment's model and let the model *propose*
work through the application's own AppPort capabilities. The model never changes state itself:
reading capabilities run when it asks, changing ones wait for the owner's approval, and every
generation, proposal, approval and execution is recorded in FeltDB.

```ts
// feltkit/chat.ts
export const turn = app.action({
  access: "assistant.turn",
  args: { key: s.string(), message: s.string() },
  handler: async (ctx, { key, message }) => {
    const { taskId, created } = await ctx.agent.openTask({ key, objective: message });   // one task per turn
    if (!created) return { replayed: true, actions: await ctx.agent.actions(taskId) };     // a retry is the same turn
    const tools = await ctx.agent.tools();                                                  // capabilities the caller may use
    const g = await ctx.model.generate({ taskId, messages: [{ role: "user", content: message }], tools });
    for (const call of g.toolCalls) {
      await ctx.agent.propose(taskId, { capability: call.name, input: call.input, reason: message, idempotencyKey: call.id,
        model: { provider: g.receipt.provider, model: g.receipt.model, generation: { memoryId: g.memoryId, toolCallId: call.id } } });
    }
    return { text: g.text };
  },
});
```

```tsx
// src/Chat.tsx
const turn = useAction(api.chat.turn);           // turn.run(args), turn.text (streamed), turn.cancel()
const mine = useOwnActions({ state: "proposed" }); // what waits for me; mine.approve(a), mine.reject(a)
```

## Actions (`app.action`)

A third function kind beside queries and mutations. It is **not a transaction** and has no `ctx.db`:
it reads with `ctx.runQuery` and writes with `ctx.runMutation` (each authorized as the caller, each its
own transaction) or through proposals. It may call the model, and it streams to its caller:

| | |
|---|---|
| `POST /api/action/<name>` with `Accept: text/event-stream` | events `event` (each `ctx.emit`, model `delta`s, `generation`, `proposal`), then `result` or `error` |
| `client.action(ref, args, { onDelta, onEvent, signal })` | aborting `signal` closes the request; the server aborts the action's model call |
| `useAction(ref)` | `run`, `cancel`, `running`, `text`, `events`, `error` |
| `t.as(who).action(ref, args, { onEvent, signal, context })` | in tests |

An action cannot be an AppPort capability or require approval (expose a mutation for that). It is
refused by `feltkit build --target appboundry`: it needs the FeltKit server.

## Generation (`ctx.model.generate`)

The model, provider, endpoint and credential come from where decisions get them: the environment's
AppPort Services Intelligence selection with FeltKit's credential custody, or a Resolver reference
(`feltkit({ agent: { model } })`) resolved **once per generation**, so changing the reference in
Resolver changes the next generation with no restart and no mixing of revisions. Protocols: OpenAI
chat completions (OpenAI and OpenAI-compatible servers, including gateways) and Anthropic Messages,
streamed. `ctx.model.status()` says what is configured. Timeout: `agent.generationTimeoutMs` (120 s).

### Every attempt has a durable outcome

Each generation is a chain of FeltDB agent-memory records on the turn's task, each step a
compare-and-swap like an action's:

```
requested ──▶ running ──▶ completed
    │            ├──────▶ failed        (timeout, unavailable, credential_refused, provider_error, malformed, …)
    │            ├──────▶ cancelled     (the caller cancelled; the text so far is kept)
    └────────────┴──────▶ interrupted   (the process stopped while it was open; set at the next start)
```

- **requested** is written before any provider is contacted, so an attempt never disappears.
- **running** records what it runs on: provider, model, protocol, endpoint, source (Resolver or
  Intelligence), the Resolver reference and revision, and the credential's *reference* (never its value).
- **The final record** holds:
  - the output (bounded; on failure or cancellation, what had streamed);
  - the tool calls;
  - finish, token usage, and cost when the provider reports one;
  - start and end times and the duration;
  - for a failure: its classification (`code`, `problem`, `retryable`) and a redacted message;
  - for a cancellation or interruption: the reason.
- **The input** is kept by reference: a digest of the messages and tool names, their count and roles.
  The application keeps the conversation itself.
- **Evidence:** a checkpoint FeltDB verifies at commit cites each final record.
  `GET /api/agent/tasks/<id>/generations` (and `AgentHost.generations`) returns each generation with
  the proposals and observations its tool calls led to.
- **A failure reaches the app as an error** whose `details.generationId` names the record.

## Tools and proposals

`ctx.agent.tools()` lists the application capabilities the caller may use, with the JSON Schema of
their input (the model's tool parameters) and their effect. `ctx.agent.propose(...)`:

- **observation** (a query capability): runs now, through AppPort, as the caller; its output comes back.
- **consequential** (a mutation capability): recorded as `proposed`. It runs only when its owner
  approves it, as the owner, through AppPort, once (compare-and-swap transitions; a duplicate or
  concurrent approval does not run it again).
- The same `idempotencyKey` on the same task returns the first proposal.
- With `model`, the proposer is recorded as `model:<provider>/<model>` acting for the owner
  (`onBehalfOf`), so the person approving is never the proposer.

## Approvals in the application

The signed-in person approves their own proposals from the application, with the same server-side
rules as Studio (a person, not an agent; may perform the capability; the owner may too), plus
ownership: another person's tasks do not exist for them.

| | |
|---|---|
| `GET /api/agent/actions?state=proposed` | the caller's own actions |
| `POST /api/agent/actions/approve` / `reject` `{ taskId, actionId }` | runs it (approve) and returns its outcome, with the activity record that is its receipt |
| `GET /api/agent/tasks/<id>/generations` | the turn's generation records |
| `GET /api/agent/actions/events` | live (server-sent events): the caller's actions now, and again whenever FeltDB's agent state changes them, from any client or process; re-read from FeltDB each time |
| `client.ownActions`, `client.watchOwnActions`, `client.approveAction`, `client.rejectAction`, `useOwnActions` (live) | the same from the client |

**Proposal timing and authority:**
- **Expiry:** a consequential proposal can be approved until its `expiresAt`. The default is 24 hours (`agent.proposalTtlMs`). After that, approving is refused (`FAILED_PRECONDITION`) and the proposal is cancelled as expired. The next start sweeps proposals nobody touched.
- **Authority at proposal time, for model tool calls:** a model's tool call for a capability its owner may not use (one it was never offered) is refused when proposed (`FORBIDDEN`, recorded as `agent.action.refused`). Other proposers (MCP agents, playbooks) keep the recoverable contract: such a proposal is recorded and refused at approval until the owner is granted the capability.

**On a FeltDB server**, agent state is not in FeltKit's change markers, so the live stream also re-reads every 2 seconds there (10 seconds locally).

## Caller context

The client sends the user's IANA time zone and locale with every request (`X-FeltKit-Time-Zone`,
`X-FeltKit-Locale`, from the browser by default; `createClient({ context })` overrides or turns it
off). The server validates them; functions read `ctx.auth.context.timeZone` and `.locale` (null when
not sent, e.g. jobs). A preference for interpreting and presenting dates, never authority.

## Proven by

`packages/sdk/test/agent-hardening.test.ts` (timeout and disconnect mid-stream, unreachable provider, restart
during a generation, cancellation racing tool execution, concurrent and duplicate approvals over HTTP,
expiry, unauthorized tool calls, concurrent conversations, live approval state, no credential leaks),
`packages/sdk/test/generation.test.ts` (loopback OpenAI and Anthropic streaming servers, plus one real
provider when `AI_GATEWAY_API_KEY` or `OPENAI_API_KEY` is set) and the Resolver test in
`test/resolver-model.test.ts` (generation follows a reference change with no restart; a change during a
running generation never mixes revisions). The application
acceptance is rkendel1/personalos (`tests/turn.test.ts`, `tests/real-provider.test.ts`, `e2e/acceptance.mjs`).

# Application backup and restore

Status: **implemented** for local FeltDB state (development, test, and production on a local
volume). The audit below comes first: it records what FeltDB already guarantees, measured on
FeltDB 0.18, before deciding what FeltKit adds.

## 1. Audit: what FeltDB provides

| Path | What it is | Application-level? | Covers FeltKit's local store? |
|---|---|---|---|
| `FeltDb::write_backup` / `restore_backup` (Rust engine) | Physical backup of one engine database. Staged to `<path>.partial` and renamed when complete; restore writes `<target>.restoring`, reopens it, checks its meaning digest, and renames it into place | No: a database, without the application it belongs to | **No.** FeltKit's local state is the JS file store (`createFeltDB({ mode: "local" })`, `packages/core/src/file-db.ts`), not the Rust engine |
| `feltdb-server backup create\|verify\|restore`, `POST /admin/backups` | Physical bundle of a whole server's state: files with SHA-256s, provenance, staged and fsynced, atomic publish. Restore refuses an existing target, and an interrupted restore leaves `*.restore.partial` | No: every application and tenant on the server, operator-level | No (server only) |
| `<state>.backup` in the JS file store | The previous snapshot, kept to recover from a torn write | No: crash recovery inside one store, not a user backup | Internal |
| `db.exportOperations()` (JS) | The local operation journal | No | A building block: it names every collection a local store has written |
| `db.stateContract.active()` / `evolve()` | The installed contract (document, version, hash). Measured: `evolve` installs any version on an empty store, and versions may jump (3, then 5) | — | Yes |

So FeltDB's physical backups are sound (staged, verified, atomic publish, refusal to overwrite),
but they don't cover the store FeltKit runs on locally. They also don't know what an application
is: which collections belong to it, which records are credentials, what schema and migrations its
data is at, or whether a store is safe to resume. **Local and managed or server FeltDB do not have
equivalent backup semantics.** A server bundle is a whole server; nothing in FeltDB backs up one
application.

**What a populated FeltKit store holds** (measured: FeltDB's operation log after a mutation with a
sequence, after-commit effects and a configuration write):

| Kind | Collections | In a backup |
|---|---|---|
| Application records | the app's collections (`invoices`, …) | yes |
| FeltKit platform | `_feltkit_migrations` (applied migrations: history and identity), `_feltkit_outbox` (after-commit effects, pending ones included), `_feltkit_sequences`, `_feltkit_collections`, `_feltkit_activity`, idempotency records | yes |
| AppPort Services | jobs, webhook endpoints and deliveries, notifications and deliveries, configuration, files, their audit records, `service_effect_evidence` | yes |
| Credentials | `_feltkit_sessions` | **no:** a restored application issues new sessions |
| FeltDB internals | `__indexes__`, `_feltdb.state_contract`, `_flow_*` agent state | **no:** the contract travels as a document and is reinstalled with `stateContract.evolve`; indexes are rebuilt by FeltDB; FeltDB's agent state is FeltDB's own |

## 2. The portable unit: application state

A backup is **one application's state**: its contract (document, version, hash), its migration
history, its records, its platform and Services records, and its operational state (outbox,
sequences). It carries enough context to decide whether it can safely resume somewhere else. It is
not a copy of database files. FeltDB stays responsible for durable storage and its guarantees:
transactions, `requireAbsent`, contract enforcement. FeltKit defines what a recoverable application
is, and reads and writes it through FeltDB's public API.

## 3. Format: `feltkit.backup/1`

Newline-delimited JSON, the same envelope as AppBoundry's `appboundry.backup/1`:

```
{"format":"feltkit.backup/1","createdAt":…,"application":{"name","version"},"environment":…,
 "feltkit":…,"feltdb":…,"contract":{"name","version","hash","document"},"migrations":[…],
 "collections":[{"name","records"}],"excluded":[…]}
{"c":"invoices","r":{…}}                  one line per record, by collection then id
{"end":true,"records":N,"sha256":"…"}      SHA-256 over every preceding line
```

Record contents and ids are kept. FeltDB assigns new record versions on restore, so version
guards (the outbox claim, sequences) start from the restored records' new versions.

## 4. Lifecycle

| Command | What it does |
|---|---|
| `feltkit backup create [--env] [--out]` | Writes the environment's backup (default `.feltkit/backups/<env>/<app>-<time>.ndjson`). A running development server is paused for the read: new calls wait and in-flight calls finish, so the backup holds each transaction entirely or not at all. A stopped environment is read directly through FeltDB, with no runtime (no worker changes state mid-read) |
| `feltkit backup verify <file>` | The whole file: format, digest, counts, the contract parses and its hash matches, and the migrations listed are in the records |
| `feltkit backup list [--dir]` | The backups in a directory, with application, environment, time, contract version and record count, and whether each verifies |
| `feltkit backup restore <file> --env <env>` | Into the environment's **empty** local state only |

**Size.** Every step reads and writes a line or a FeltDB page (1,000 records) at a time, never a whole
collection or file:

- `create` counts each collection, then streams its records in cursor-paged reads to
  `<out>.partial`. A running server streams the lines over its admin API as NDJSON; a failure after
  the first line ends the stream with an `{"error": …}` line, and a stream cut short has no end
  record, which verification refuses. The partial file is verified from disk, then renamed. A
  failure removes it.
- `verify`, `list` and `restore` read the file line by line. `restore` verifies the whole file
  first, then reads it again to write, and checks the digest again on the way, so a file changed in
  between is not marked complete.
- Not paged: collections are found from FeltDB's operation journal, which FeltDB returns whole (it
  has no collection listing; docs/UPSTREAM-GAPS.md F19).

Tested with 1,001 records in a collection (`test/large-collections.test.ts`), and through
`change.verify` and the deployment cutover (`test/platform-large-state.test.ts`).

**Restore, in order:**

1. Verify the whole file (read line by line).
2. Refuse a different application (the project's name) or a non-empty target, before anything is
   written.
3. Write the marker `_feltkit_restore` as `in-progress`.
4. Install the backup's exact contract (same version and hash).
5. Write the records in batches of 200 with `requireAbsent`, so FeltDB checks each against the
   contract, reading the file again a line at a time.
6. Check the file's digest again, each collection's count (counted in pages), and the contract hash.
7. Mark the restore `complete`.

**The runtime refuses to start on a state whose restore marker is not complete**, and a second
restore refuses the now non-empty target. So an interrupted restore can't be mistaken for a
restored application.

A restored application starts like the original: same contract and migration history, so no
schema change is pending unless the project changed since. Its pending outbox work is recovered by
its worker. Sessions are re-issued.

## 5. Not covered

- **Managed or server FeltDB** (`FELTDB_URL`). Backup and restore are refused explicitly. Through a
  remote authority FeltKit can't enumerate collections from a local journal, and an
  application-scoped key may not read FeltDB's internals; that path is not verified. For a whole
  server, use `feltdb-server backup` (a physical bundle).
- **A running production server.** Its admin API admits only verified operators. Stop it, or back up
  its local volume's environment directly.
- **Restoring a FeltKit backup into AppBoundry, or the reverse.** The envelope is the same, but the
  platform collections differ (`_feltkit_*` / `_appboundry_*`).
- Out of scope by design: a backup storage service, replication, point-in-time recovery.

# Accounts, sessions, workspaces and the sign-in screens

FeltKit gives an application its people and their workspaces:
- sign-in (password, e-mailed links, Google, GitHub, any OpenID Connect provider);
- the account (profile, address, password, connected providers, sessions);
- tenancy (workspaces, roles, invitations, switching);
- the React screens for all of it.

Everything is enforced on the server. The state lives in the application's own FeltDB instance, and
e-mail goes through AppPort Services' notifications and Mailerport. A complete app built only from these
pieces is the tasks starter (`examples/tasks`).

## Configure

```ts
import { feltkit, s } from "@feltdb/feltkit";

export const app = feltkit({
  name: "teams",
  // One authorization model: workspace roles are ordinary roles.
  roles: {
    person: [],                                   // every account, before it joins a workspace
    owner: ["notes.*", "tenant.*"],               // tenant.* = manage members and rename
    admin: ["notes.*", "tenant.members.manage"],
    member: ["notes.*"],
    guest: ["notes.read"],
  },
  auth: {
    accounts: {
      roles: ["person"],                          // what every account holds everywhere
      password: true,                             // default
      magicLink: true,                            // e-mailed sign-in link + 8-digit code
      email: { from: "auth@example.com", verify: "optional", templates: { /* optional */ } },
    },
    providers: { google: { clientId: "…" }, github: { clientId: "…" }, oidc: [{ id: "okta", issuer: "https://…", clientId: "…" }] },
    session: { cookie: "auto", trustProxy: 1 },
    tenant: {
      name: "workspace",                          // the word the screens and messages use
      roles: ["owner", "admin", "member", "guest"], // highest first; each a declared role
      claims: { plan: { type: "enum", values: ["free", "pro"] }, seats: { type: "integer", default: 1 } }, // claim specs (plain data) or schemas
      create: "anyone",                           // or "none"
      invitations: { ttlMs: 7 * 24 * 3_600_000 },  // default 7 days, at most 30
      switching: true,
    },
  },
});
```

`feltkit()` refuses a configuration that cannot work, and says what to change:
- a role that is not declared;
- `magicLink` without `email`;
- no way to sign in;
- a tenant with no role granting `tenant.members.manage`;
- `role` declared as a claim;
- an unknown e-mail template;
- an inline client secret.

Provider client secrets are credentials: `credential-ref:<id>-client-secret`, for example `FELTKIT_CREDENTIAL_GOOGLE_CLIENT_SECRET`.

### Mapping from `use auth`

If you know AuthBoundry's `use auth { … }` block, this is the same configuration in FeltKit's one
configuration language:

| `use auth` | `feltkit({ auth })` |
|---|---|
| `providers=[email]` | `accounts` (password) |
| `providers=[magic-link]` | `accounts.magicLink` |
| `providers=[google,github]` | `providers.google`, `providers.github` |
| `tenant=true` | `tenant` |
| `claims={role=enum[…]}` | `tenant.roles` |
| `claims={plan=enum[…]}` | `tenant.claims.plan` |
| `use mail { identities … }` | `accounts.email.from` and `identity` |
| `use mail { templates … }` | `accounts.email.templates` |

## Sign-in methods and account e-mail

| Method | How |
|---|---|
| Password | `POST /api/auth/signup`, `POST /api/auth/signin`. scrypt hashes. One answer for an unknown address and a wrong password, which take the same time. 10 failures per address and per client address in 15 minutes. |
| Magic link | `POST /api/auth/magic/request { email }` sends a link and an 8-digit code. `POST /api/auth/magic { token }` or `{ email, code }` redeems them. A new address gets a verified account when sign-up is open. |
| Google, GitHub, OIDC | Authorization code with PKCE (S256) and a `state` bound to the browser. Only a verified e-mail address is accepted. |
| Verify address | `POST /api/auth/verify/request { email }`, then `POST /api/auth/verify { token }`. |
| Reset password | `POST /api/auth/reset/request { email }`, then `POST /api/auth/reset { token, password }`. Signs the account out everywhere. |

**Sign-up and enumeration.** With `email.verify: "required"`, sign-up answers the same for a taken address
as for a new one: the address's owner gets a password-reset link instead. With optional verification, a new
account gets its session at once, so sign-up necessarily reveals a taken address (`CONFLICT`). Use
`verify: "required"`, or magic links alone, when that matters.

Every e-mailed secret (verify, reset, magic link, address change) is a **challenge**:
- **Lifetime:** durable in FeltDB, at most 15 minutes, single use, and superseded when another is requested for the same purpose.
- **Codes:** a code allows 5 wrong attempts, then the challenge is void.
- **Volume:** 5 challenges per address and purpose per hour.
- **Storage:** the record holds a nonce and digests only. The link token and the code are `HMAC(FELTKIT_AUTH_SECRET, nonce)`, computed when the e-mail is delivered, so neither the notification record nor the challenge record holds a usable secret.
- **Answers:** requests answer the same whether or not the address has an account, and whether or not it is over its limit.

E-mail goes through AppPort Services' notifications to Mailerport:
- **Development:** the message is printed by `feltkit dev`.
- **Production:** it goes to the Mailerport service at `MAILPORT_URL` with `MAILPORT_API_KEY`, as the identity you register there (default `auth`).

Your own text: `accounts.email.templates[purpose](input) → { subject, text, html? }`, where `purpose` is one of `verify`, `reset`, `magic-link`, `email-change` or `invitation`.

## Sessions

- **Browsers: an HttpOnly cookie.**
  - **Cookie:** `createClient()` in a browser uses cookie mode. The cookie is `__Host-fk_session` over HTTPS (Secure, Path=/, no Domain), or `fk_session` on plain-HTTP development, with `HttpOnly; SameSite=Lax`. Page script never sees the token, and nothing is kept in `localStorage`.
  - **Migration:** an older client's `localStorage` token is moved into the cookie once (`POST /api/auth/cookie`), then removed.
- **CSRF.**
  - A cookie-authenticated `POST`, `PUT` or `DELETE` must send `X-FeltKit-CSRF`, an HMAC of the session's digest that `GET /api/session` hands the page. The client does this for you.
  - A request with a foreign `Origin` is refused.
  - Cross-site pages cannot read the token, and cannot send the header without a CORS preflight, which FeltKit never grants.
- **CLI, services, API keys: bearer tokens, unchanged.** `Authorization: Bearer <token>`, with no CSRF token: a bearer token is not an ambient credential. `createClient({ session: "bearer" })` keeps the bearer behaviour in a browser.
- **Lifetime and revocation.**
  - Lifetime: 7 days by default (`auth.sessionTtlMs`).
  - Signing out deletes the session and clears the cookie.
  - `GET /api/auth/sessions` lists your sessions.
  - `POST /api/auth/sessions/revoke` takes `{ ref }` for one, or `{ all: true, keepCurrent }` for all of them.
  - **A session that ends, ends everywhere.** A refusal because the token no longer exists (signed out, revoked, expired) is `UNAUTHORIZED` with `hint: "SESSION"`. Open streams (`/api/events`, `/api/agent/actions/events`) re-check their session every `FELTKIT_SESSION_RECHECK_MS` (default 15 s); once it has ended, they send that error and close. The client applies one rule to every channel: on that answer to the token it sent, it clears the token (never a newer one) and fires `onSessionChange` once. An event subscription refused with 401 stops instead of retrying. See [EXTENSION-HOSTS.md](EXTENSION-HOSTS.md).
- **Rotation.** A password change, and switching, creating, leaving or joining a workspace, replace the session (a new token; the old one ends).
- **Always current.** An account session is resolved again on every request: the account as it is now, plus the live membership in its workspace. Changed roles, a disabled account, a removed membership or a changed role in a workspace take effect on the next request, not at expiry. Roles are never trusted as copied at sign-in. Dev, CLI and agent sessions carry the roles their issuer gave them.
- **Trusted proxies.** `auth.session.trustProxy` is the number of reverse proxies in front that append to `X-Forwarded-For` and set `X-Forwarded-Proto`. With the default (0) both headers are ignored, because a client could forge them; the client address used for throttling is then the socket's.

## Workspaces (tenancy)

A tenant ("workspace", or whatever `tenant.name` says) has members.
- **Membership.** Each member has one of `tenant.roles` and typed claims.
- **Where a role applies.** A session works in one tenant at a time. In it, the member holds their role's permissions: the same `roles`, `access` and `authorize` hook as everything else. There is no second policy.

| Operation | Route | Who |
|---|---|---|
| Your workspaces, the current one, what you may do | `GET /api/tenants` | signed in |
| Create (you hold the top role) and switch to it | `POST /api/tenants { name }` | `tenant.create: "anyone"` |
| Switch (`null`: none) | `POST /api/tenants/switch { tenantId }` | members of it only |
| Members | `GET /api/tenants/current/members` | members |
| Change a role | `POST …/members/role { principalId, role }` | `tenant.members.manage` |
| Set claims | `POST …/members/claims { principalId, claims }` | `tenant.members.manage` |
| Remove | `POST …/members/remove { principalId }` | `tenant.members.manage` |
| Add an agent or service | `POST …/members/add { principalId, role }` | `tenant.members.manage` |
| Leave | `POST /api/tenants/current/leave` | members |
| Rename | `POST /api/tenants/current/rename { name }` | `tenant.update` |
| Invite, list, withdraw | `POST`/`GET …/invitations`, `POST …/invitations/revoke` | `tenant.members.manage` |
| What an invitation is for | `POST /api/invitations/preview { token }` | its holder |
| Accept | `POST /api/invitations/accept { token }` | the invited, verified address |

Rules the server enforces:
- **The tenant is the session's.** A tenant id in a request is only ever a request to switch, checked against your memberships. A tenant you are not a member of does not exist for you (`NOT_FOUND`).
- **Rank.** `tenant.roles` is ordered, highest first. A manager assigns and changes only roles below their own, and only the top role assigns the top role. Nobody raises their own role. A workspace always keeps a holder of the top role. A role that is not declared cannot be assigned, so a workspace administrator cannot create a capability.
- **Invitations.**
  - **Token:** a random token derived with the auth secret, never stored.
  - **Use:** single use, and expiring.
  - **Who may accept:** only an account whose verified address is the invited one (development identities may accept in development).
  - **Withdrawn or expired:** refused.
  - **Delivery:** e-mailed when the app sends account e-mail, and the inviter also gets the link to share.
- **Agents and services** are added directly, with a role, only when they hold an operator-issued identity (`feltkit session create --type agent`) or are application agents the app declares (`app.agent`). People join only by invitation.
  An application agent (`app.agent`) works in the tenant of the call that triggered it only if it is an active member there itself, with its own membership role; otherwise it runs with no tenant (docs/TRANSACTIONS.md §8).
- **Claims** are typed by `tenant.claims`, validated on write, and set only by the server (a member manager through `POST …/members/claims`, or an invitation's `claims`, effective at acceptance). A request never supplies them, and `role` is the membership's role, not a claim you set. `null` removes a claim.
  - **Declaring.** A claim is a **claim spec**, plain data (`{ type: "enum", values: ["free", "pro"] }`, `{ type: "integer", default: 1 }`; types `enum`, `string`, `boolean`, `number`, `integer`; optional `default`), or a schema (`s.enum([...])`) in application code. Both compile to the same validation; a malformed spec is refused when the app is declared.
  - **At the boundary.** On every call, when the live membership is resolved, each declared claim is classified: `verified` (stored, set through the server, valid under the declaration now; with who set it, when and how: `invitation`, `manager`, `self`), `default` (the declaration's default; nothing stored), `unavailable` (nothing stored, no default), `invalid` (a stored value the current declaration refuses; withheld). Only `verified` and `default` values appear in `tenant.claims`; `tenant.provenance[name]` carries the status and origin. A stored claim the declaration no longer names is dropped. Nothing upgrades a status.
  - **In authorization.** `app.requireClaim(ctx, "plan", ["pro"])` (or a predicate) returns the value or fails `FORBIDDEN` with the reason named (`CLAIM_UNAVAILABLE`, `CLAIM_INVALID`, `CLAIM_NOT_ALLOWED`). It runs after the function's `access` permission, never instead of it. `feltkit create --require notes:plan=pro` makes every function of a workspace-scoped entity call it first.

### Data that belongs to a workspace

```ts
export const notes = app.collection("notes", { title: s.string() }, { tenant: true });   // field tenantId
export const channels = app.collection("channels", { … }, { tenant: { field: "workspaceId" } });
```

FeltKit treats each operation as follows:
- **insert:** sets the field to the session's tenant, and refuses a different value (`FORBIDDEN`, hint `TENANT_MISMATCH`).
- **get:** returns `null` for another tenant's record.
- **find, count, query:** return only the session's tenant's records.
- **patch, replace, delete:** another tenant's record is `NOT_FOUND`.
- **No tenant in the call:** these collections are closed (`FAILED_PRECONDITION`, hint `NO_TENANT`).

FeltKit adds an index on the field. Records written before a collection was scoped have no tenant, so they are visible to none.

### In your functions

```ts
handler: async (ctx) => {
  const tenant = app.requireTenant(ctx);   // { id, name, role, claims, provenance } — typed by auth.tenant
  if (tenant.claims.role === "owner") { … }
  const plan = app.requireClaim(ctx, "plan", ["pro"]); // FORBIDDEN unless the membership's plan is a verified (or default) "pro"
  if (tenant.provenance.seats?.status === "default") { … } // nobody set seats; the declaration's default applies
}
```

`ctx.auth.tenant` is the same value, untyped. The `authorize` hook sees it on `request.principal.tenant`.
In tests, `createTestApp()` provides:
- `t.tenancy`, the store, for setup;
- `t.as(who, { tenant })`, which works in a tenant exactly as a session does.

## React screens (`@feltdb/feltkit/react`)

```tsx
import { SignIn, AcceptInvitation, CreateTenant, TenantSwitcher, TenantSettings, AccountSettings,
  AuthNotices, VerifyEmailBanner, useAuth, useTenant, useAuthRedirect } from "@feltdb/feltkit/react";

function App() {
  const auth = useAuth();
  const tenant = useTenant();
  const { redirect } = useAuthRedirect();
  if (auth.loading) return null;
  if (redirect?.kind === "invitation") return <AcceptInvitation />;   // signs in first when needed
  if (!auth.user) return <SignIn brand={{ name: "Teams", logo: "/logo.png" }} />;
  if (!tenant.current) return <CreateTenant />;
  return (
    <>
      <TenantSwitcher />
      <AuthNotices /><VerifyEmailBanner />
      {/* your app; tenant.current is the workspace; switching re-runs every live query */}
    </>
  );
}
```

| Component | What it does |
|---|---|
| `SignIn` | Offers what the app enables: password, sign-up, magic link and code, providers, forgot and reset. Also handles the links that come back into the app: reset, verified, expired or used links. `returnTo` accepts only a path on this site. |
| `AcceptInvitation` | Shows what the invitation is for. Signs in first, with the invited address prefilled, when needed. Handles expired, withdrawn, used and wrong-account invitations. Keeps the invitation for the tab until it is accepted. |
| `TenantSwitcher` | The current workspace, with a keyboard-accessible menu to switch to another or create one. |
| `CreateTenant` | First-run screen: open one of your workspaces, or create one. |
| `TenantSettings` (`MembersPanel`, `InvitationsPanel`) | Name, members, roles, removal, leaving, invitations (copy link, withdraw). Shows only what the server says you may do. |
| `AccountSettings` | Profile, address and verification, address change, password, connected providers, sessions, sign out of other sessions, sign out. |
| `AuthNotices`, `VerifyEmailBanner` | What a link opened while signed in did; a reminder to verify. |

All of them include:
- loading, empty, error and expired states;
- labelled form controls and `aria-live` status;
- keyboard operation and visible focus;
- layouts that work from phones to desktops.

**Styling.**
- **Stylesheet:** the components add one small stylesheet (`fk-*` classes) to the page, before your own CSS, so your rules win.
- **Theming:** use CSS custom properties on any ancestor: `--fk-accent`, `--fk-accent-ink`, `--fk-surface`, `--fk-ink`, `--fk-muted`, `--fk-line`, `--fk-danger`, `--fk-radius`, `--fk-font`. They default to your app's `--accent`, `--surface`, `--ink`, `--muted`, `--line` and `--radius` when it defines them, and to the system's colours (light and dark) otherwise.
- **Overrides:** every component takes `className`. Render `<FeltKitAuthStyles disabled />` once to style everything yourself.

## AppBoundry

An artifact built with `feltkit build --target appboundry` behaves as follows:
- **Collections:** it carries the tenant-scoped collections, and the guest applies the same scope to the tenant its host resolves.
- **Closed by default:** a host that resolves no tenant leaves those collections closed.
- **Tenancy (`tenancy@1`):** an app with `auth.tenant` requires the `tenancy@1` host interface. The guest
  carries FeltKit's own tenancy (`runtime/tenancy.ts`: roles, rank rules, last-owner rule, claims) and runs
  it over the host's copy of `_feltkit_tenants`, `_feltkit_memberships` and `_feltkit_invitations`, so an
  organization's records have one shape on every runtime. The host owns sessions: it stores the session's
  selected tenant, asks the guest for the live membership (`context`) on every request, and passes it as
  `principal.tenant` with the tenant role among the principal's roles. A removed member or a changed role
  takes effect on the next request. Creating, switching, members, roles, leaving and renaming are served
  at the same `/api/tenants/*` paths as a FeltKit server; `ctx.tenancy.members()` works in functions.
  Operators provision members (`appboundry admin tenants provision`). Parity with a FeltKit server:
  `packages/sdk/test/tenancy-parity.test.ts`.
- **What AppBoundry still lacks:** built-in accounts (FK-GAP-013, `accounts@1` is a proposal), and so
  e-mailed invitations. People get sessions from an operator; the build declares `auth.accounts` as
  `identity.accounts`, and a host refuses the artifact unless its operator accepts operator-issued
  sessions (`appboundry run --accounts operator-sessions`). With `auth.tenant` invitations on, the build
  warns that on AppBoundry members are provisioned instead.
- **File links:** these, and the account routes, are Node-server routes.

## Deploying

| Setting | Why |
|---|---|
| `FELTKIT_AUTH_SECRET` (32+ bytes, the same on every process) | Derives challenge, invitation and CSRF tokens and signs provider state. In development, and with local production state, it is generated and kept beside the state. Changing it invalidates outstanding links and CSRF tokens, not sessions. |
| HTTPS in front | `__Host-` cookies need it, and production cookies are always `Secure`. |
| `auth.session.trustProxy` | The number of proxies that set `X-Forwarded-For` and `-Proto`. |
| `FELTKIT_PUBLIC_URL` (https in production) | The origin that e-mailed links and provider callbacks use, never the request's `Host`. |
| `MAILPORT_URL`, `MAILPORT_API_KEY` | Account e-mail and invitations in production. |
| One public origin for the app and its API | Cookie sessions are same-origin. A frontend on another origin uses `createClient({ url, session: "bearer" })`. |

## Migrating from the earlier auth API

- **Existing configuration:** `auth.accounts` and `auth.providers` work unchanged. Existing bearer sessions stay valid.
- **Browser client:** it now uses cookies. A token an older version left in `localStorage` is moved into the cookie on the first load. Pass `session: "bearer"` to keep the old behaviour.
- **Old links:** verification and reset links sent before this version stop working. They were stateless HMAC links (verification for 7 days); they are now durable 15-minute challenges. People ask for a new one.
- **Session response:** `GET /api/session` adds `transport`, `csrf` (cookie sessions), `tenant` and `tenancy`. `accounts` adds `password` and `magicLink`.
- **Workspaces you built yourself:** move them to `auth.tenant`.
  - Make the workspace data `{ tenant: { field: "<your field>" } }`, so your records keep their field.
  - Drop your membership and invitation collections.
  - Take the workspace and role from `ctx.auth.tenant`, not from an argument.

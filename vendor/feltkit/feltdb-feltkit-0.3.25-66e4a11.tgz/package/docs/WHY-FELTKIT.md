# FeltKit and Convex: design choices

Convex is an integrated application backend: a reactive document database, TypeScript
queries, mutations, and actions, automatic real-time subscriptions, hosting (or a
self-hosted open-source backend), and an ecosystem of components — including durable
workflows (`@convex-dev/workflow`) and an agent framework (`@convex-dev/agent`, with models
through its AI SDK provider). It is mature, well documented, and pleasant to use.

FeltKit makes different choices. It is for applications where **agents act on real
systems**, and where you need to know who allowed what, what actually happened, and what to
do when nobody can tell. Each claim below links to the code or test that shows it.

## What FeltKit does differently

| | FeltKit | Shown in |
|---|---|---|
| **Capabilities with explicit authority** | Every function you expose and every operation of a connected API is an AppPort capability: its input and output schemas, effect class (observation or consequential), the permission that may invoke it, idempotency, and how its outcome is verified. Agents and other applications discover it over AppPort or MCP; **discovery grants nothing**. | `packages/sdk/test/integrations.test.ts` (discovery), `auth.test.ts` |
| **Governed agent actions** | An agent's consequential action is a proposal until a person who may perform it approves; agents cannot approve; in production nobody approves their own proposal. Each action records proposer, approver, the principal it ran as, request id, and every transition. | `agent-lifecycle.test.ts`, `production-ops.test.ts` |
| **Uncertain outcomes are a state, not a retry** | When a payment API stores the payment and never answers, the action is `interrupted` (outcome unknown), not `failed`. It cannot be retried. It is settled from evidence — the API's own records, read through a declared probe — or by a person's attributed decision; a claim that contradicts the evidence is refused. Restart recovery does the same, and never re-executes. | `integrations.test.ts`, `examples/invoices/tests` (tests 9, restart) |
| **A model's output is a proposal** | A model chooses among options your code builds and the task owner may perform; the choice is recorded with its runtime and model as decision evidence and becomes a proposal in the lifecycle. A successful model response is never evidence that a business operation happened. | `decisions.test.ts`, `examples/invoices` |
| **Provider and agent flexibility** | Decisions use FeltDB's provider-neutral `DecisionRuntime` contract. Configured per environment: OpenAI, any OpenAI-compatible server (Ollama, vLLM, llama.cpp, a local fixture), Anthropic, or any `DecisionRuntime` you pass in (FeltDB's in-browser WebLLM runtime works unchanged). Open-ended agents (Claude Code, other MCP clients) work through `feltkit_agent_*` tools under the same lifecycle. | `decisions.test.ts`, `mcp` tests in `agent.test.ts` |
| **Existing services through explicit contracts** | `app.integration("payments", …)` connects an HTTP API you already run: operations, credential by reference (never stored), idempotency header, verification probe. Calls are recorded before they are sent. | `integrations.test.ts`, `examples/invoices/feltkit/payments.ts` |
| **Readiness from real checks** | `feltkit readiness` and Studio report what this environment has and lacks, with fixes, and list what FeltKit cannot verify (TLS, backups, monitoring, rate limiting). | `platform.test.ts` |

## Where Convex is ahead

Be clear-eyed about these before choosing FeltKit:

- **Reactive data at scale.** Convex's subscriptions are its core; FeltKit's live queries are
  single-process and re-run the query on change (docs/GUARANTEES.md).
- **Hosting and operations.** Convex runs your backend for you (or gives you its
  open-source backend to self-host). FeltKit builds and verifies a deployable artifact; TLS,
  hosting, backups, monitoring, and scaling are yours (docs/PATH-TO-PRODUCTION.md).
- **Ecosystem and ergonomics.** Convex has many components, auth integrations, a dashboard
  with years of polish, and a large community. FeltKit is young.
- **Durable workflows as code.** Convex's Workflow component runs multi-step functions with
  recorded step results, configurable retries, and resume after restart. FeltKit has no
  general workflow engine: its durable steps are application state, background jobs, and the
  agent action lifecycle.
- **Agent features.** Convex's Agent component has threads, message history, streaming, tool
  calling, and RAG. FeltKit's built-in model step makes a single choice among offered
  options; free-form tool-using agents connect over MCP.

## Choosing

**Prefer Convex** when the product is a real-time application (collaboration, chat, live
dashboards), you want hosting handled, agents mostly generate content or call tools whose
mistakes are cheap, and its ecosystem covers your integrations.

**Prefer FeltKit** when agents (or automation) take actions with real consequences —
payments, provisioning, records other systems trust — and you need explicit authority on
every action, human approval where it matters, an audit trail of who proposed, approved,
and executed, honest handling of outcomes nobody observed, and freedom to use any model,
including a local one.

**Use both** when a Convex application needs a governed back office: keep the product in
Convex and expose the consequential operations as a FeltKit application whose capabilities
the Convex side (or its agents) calls over AppPort/HTTP. The authority, approval, and
evidence stay where the side effects are.

Sources for Convex: [Agents](https://docs.convex.dev/agents),
[Agent workflows](https://docs.convex.dev/agents/workflows),
[Workflow component](https://www.convex.dev/components/workflow),
[Self-hosting](https://docs.convex.dev/self-hosting) (read 2026-10-28).

# Agent-native development and operations

Status: the design is from a read-only inventory of FeltKit, AppPort, AuthBoundry and Resolver
(all on `main` as of 2026-11-03). **PRs 1–3 are implemented** (§6, §7, §8); the rest is planned. §5
records the owner's decisions; §9 records where PRs 4–6 stand and what blocks them.

**Correction (2026-11-03).** PRs 1–3 were tested on small projects only. With more than 1,000 records
in a collection, `change.verify` (it backs up and restores the development state) and every deployment
cutover (it backs up the production volume) failed on FeltDB 0.20.0, and on 0.18.0 the application
itself returned at most 100 records from `find` and `count`. Fixed with the paged reads and streamed
backup described in docs/UPSTREAM-GAPS.md ("Review 2026-11-03"). `test/platform-large-state.test.ts`
runs `change.verify`, `change.apply` and `deploy.apply` against 1,001 development and production
records, and checks the production data after each cutover.

The rule this design keeps: **the agent is a consumer of FeltKit, not the owner of the
application.** FeltKit owns the application's state, capabilities, authority, deployment and
evidence. A model supplies reasoning and proposed changes. A proposal is not authorization; a tool
response is not proof; **a deployment receipt is proof.**

## 1. Inventory: what exists to reuse

### FeltKit

| Need | Exists | Where |
|---|---|---|
| Agent principals | `Principal { type: "user" \| "agent" \| "service" }`, agent sessions (`feltkit session create --type agent`), revocable by reference, checked on every request | `runtime/authority.ts`, `runtime/sessions.ts` |
| Per-call authority | `Authority.authorize()` returns a `Decision` (decisionId, policyVersion), recorded in activity. Roles resolve to permissions on every call | `runtime/authority.ts`, `runtime/activity.ts` |
| Application agents acting as themselves on the app's own triggers (`app.agent`, FK-GAP-008): a mutation's `ctx.afterCommit.agent` or an `app.event`, run by the services worker as the agent principal, at least once with a lease and retries | after-commit outbox + `Runtime#call` | `runtime/runtime.ts` (`#runAgent`), `runtime/transactions.ts`, docs/TRANSACTIONS.md §8 |
| Propose, approve (people only), execute, evidence | `AgentHost`: proposals, approval by a `user` only, execution as the task owner, checkpoints with FeltDB-verified evidence, handoffs | `runtime/agent.ts` |
| AppPort and MCP for **application** capabilities | Functions as AppPort capabilities (authority before input), `/appport`, `/mcp` (bearer token per request) | `runtime/capabilities.ts`, `server/mcp.ts` |
| Operator access to production | Signed one-time grants, then `operator` sessions; `feltkit.operations.read\|write` | `server/operators.ts` |
| Inspect, schema, build, migrate, backup | `inspect --json`, `doctor --json`, `schemaPlan/History`, `build()` (`BuildResult`, schema hash), `migrate --json`, `backup` | `cli/main.ts`, `server/project.ts`, `runtime/state-contract.ts` |
| Deploy | `deploy()` builds, boots, checks health and the manifest, writes `.feltkit/deploy`; `vercel` / `cloudflare` / `fly` push | `cli/deploy.ts`, `runtime/targets.ts` |

**Missing in FeltKit:**
- None of the development or operations steps (inspect, test, build, deploy, migrate) is an AppPort
  capability or MCP tool; they are CLI only. `test` and `deploy` have no `--json`. *(PR 1: inspect,
  schema, test and build are capabilities; `test --json` and `build --json` exist.)*
- **No deployment revision, change set, receipt or deploy actor.** `.feltkit/deployment.json` is one
  overwritten file with no artifact hash.
- `tools/list` shows every capability, not only the ones the caller may call. *(PR 1: the platform's
  `/mcp` lists only what the profile grants; an application's `/mcp` is unchanged.)*
- A session's roles are fixed when it is issued: a role change applies only after the session is
  revoked.
- No Resolver code.

### AppPort (`/home/user/appport`)

**Reuse:**
- Capability manifest (`appport/1`): typed `inputSchema`/`outputSchema`, `authorization` scopes,
  `effect` (observation or consequential), idempotency.
- The integration descriptor (`appport.integration/1`): `preconditions`, `failures` (retry
  semantics), `approval { required, approver }`, `effects`, `verify`.
- `capabilityDigest` and `contractDigest` (`sha256:`) for pinning, in AppPort's canonical-contract
  registry (`@appport/core`). The manifest an application serves does not carry them.
- `Authorizer` called **on every request**, which returns a `decisionId`.
- MCP projection with identity per call; idempotency claims.

**Missing in AppPort:**
- An `agent` principal type and an on-behalf-of chain (`delegationId` exists but is unused).
- `policyVersion` on decisions, receipts, and a CLI for discovering or invoking capabilities.
- An AuthBoundry adapter.

### AuthBoundry (`/home/user/authboundry`, a Rust service with an HTTP JS SDK)

**Reuse (implemented and tested):**
- Delegations `{delegator, delegate, capabilities, application scope, expiry}`. Revocation takes
  effect at the next decision, with no decision cache; a delegation carries no authority once its
  delegator has lost it.
- Agent principals (active, suspended, revoked) and agent credentials (scoped, renewable; replaying
  an old credential revokes the whole family).
- Agent runs under a delegation.
- Durable evidence for every decision, denials included; an audit-write failure is a deny.
- `createAuthBoundryAuthorizer` (an AppPort `Authorizer`) and `enforce({..., execute})`.

**Missing in AuthBoundry:**
- Per-environment scope (environments are metadata only).
- Resource attributes evaluated on the application path.
- A change-set or revision field (only a free-form `context` of up to 16 keys).
- A durable lookup of a decision by id (`explain` filters a list; the decisions endpoint sees only
  the latest 100).
- An adapter for the `ServiceAuthorizer` protocol.
- Approval of a pending action.
- **Its README marks it not production-ready.** FeltKit and AppPort Services do not call it today.

### Resolver (`/home/user/rkendel1/resolver`, an AppPort application)

**Reuse (implemented and tested):**
- `ref://` names of five kinds: model, secret, endpoint, value, agent.
- Revisions with actor and reason, pin, rollback, and revoke. A revoked reference answers
  `NOT_FOUND` with `resolver.revoked`, pinned or not.
- Watch (names only, then re-resolve with the caller's own authority), and per-key grants
  (`read`, `reveal`, `write`, `admin`), denied by default.
- `ResolverClient.model(ref)` returns the provider, model and endpoint, plus `apiKey` through a
  separate `reveal`, which is audited.
- An in-process runtime for tests (`createResolverRuntime({ state: { memory: true } })`).

**Missing in Resolver:**
- **Nothing is published to npm** (all three packages are 0.1.0, and `npm view` returns 404).
- **Resolver hands plaintext to whatever key may reveal**, so FeltKit must keep that key and the
  model call inside its trusted runtime.
- It pins `@appport/services` 0.9.1 and `@feltdb/core` 0.16.1, older than FeltKit's.

## 2. Architecture (no parallel systems)

```
agent (Claude Code, Codex, Stack-Agent…)
   │  CLI `feltkit op <capability>`   │  MCP /mcp           │  AppPort /appport
   └──────────────┬───────────────────┴─────────────────────┘
        FeltKit platform operations (one registry: typed input/output,
        preconditions, effect, authority, approval)  ── AppPort manifest `dev.feltkit.platform`
                  │ per-call authority: FeltKit Authority now, AuthBoundry adapter when configured
                  │ evidence: activity + receipts in the platform store (FeltDB)
        project workspace (isolated per change set) · build · test · deploy executors
                  │
        application runtime(s): FeltDB state · AppPort app capabilities · AppBoundry artifacts
                  │ references, not values
        Resolver (ref://…) for models, secrets, endpoints, values, agents
```

- **One operations registry.** Each operation is defined once: `s` schemas for input and output,
  an AppPort capability (effect, authorization scopes), and an integration descriptor
  (preconditions, failures, approval). CLI, MCP and AppPort are adapters over the same handler, so
  nothing is "agent-only".
- **Platform store.** One FeltDB store per workspace root holds change sets, deployment revisions
  and receipts. It is not another project database: application state stays in each environment's
  FeltDB.
- **Authority profiles** are permission sets on the existing authority. They are not a new system.

  | Profile | Permissions |
  |---|---|
  | `inspect` | `feltkit.platform.read` |
  | `develop` | inspect, plus `feltkit.changes.write` (its own change sets' workspaces only) |
  | `deploy` | develop, plus `feltkit.deploy:<application>/<environment>` |

  The decision is made **at execution** (sessions are checked on every request, and delegations
  in AuthBoundry at the next decision), so revocation stops an agent that is already connected.
- **Change set lifecycle** (durable records in the platform store):

  | State | What happens |
  |---|---|
  | `proposed` | Bound to an application and to the deployment revision it starts from |
  | `implementing` | An isolated workspace copy is created; the agent edits only there |
  | `verified` | Build, tests, contract and migration plan run by FeltKit, not the model. Records the workspace tree digest, artifact digest, test results and migration plan |
  | `authorized` | A per-environment decision recorded as AppPort/AuthBoundry evidence |
  | `applied` | Deployed only if the tree and artifact digests still equal the verified ones; refused if the target moved past the base revision |
  | `proven` | A receipt: artifact digest, revision, actor, delegating principal, decision ids, target and outcome. It is written only after the deployed health check and manifest check pass |

  A failed deploy produces a `failed` record with its evidence. It never produces a receipt.
- **Resolver.** FeltKit stores `ref://…` references; resolution happens inside FeltKit's process
  (reveal keys never reach an agent). Each use records the reference and the revision it resolved.
  Resolver keeps configuration and secrets; AuthBoundry/AppPort keep what an agent may do.

## 3. Capability catalog (`dev.feltkit.platform`, version 1)

| Capability | Effect | Authority | Preconditions and notes |
|---|---|---|---|
| `project.inspect` | observation | inspect | structure, functions, collections, contract hash, deployment revisions, readiness |
| `project.create` | consequential | develop | target directory new; returns workspace path |
| `schema.inspect` | observation | inspect | collections, fields, indexes, references; installed vs declared contract and plan |
| `schema.change` | consequential | develop | change set open; edits `feltkit/app.ts` in its workspace; returns plan (and migration needed) |
| `function.create` / `function.update` | consequential | develop | change set open; typed module edits in its workspace; build-checked |
| `test.run` | observation* | develop | in a workspace; structured results (each test, failure output) |
| `build.run` | observation* | develop | in a workspace; artifact digest |
| `change.propose` | consequential | develop | project, environment, files; base source revision (PR 2) |
| `change.inspect` | observation | inspect | the change set, its files, staleness, verification, receipt, history (PR 2) |
| `change.verify` | consequential | develop | FeltKit-run build, tests, contract and migration check; records digests (PR 2) |
| `deploy.plan` | observation | deploy | verified change set; impact: schema changes, migrations, target |
| `deploy.apply` / `change.apply` | consequential | deploy | verified, unchanged digests; target still at base revision; approval when required. Returns a receipt (`change.apply`: PR 2) |
| `runtime.inspect` | observation | inspect | deployed health, readiness, schema status, revision |
| `runtime.logs` | observation | inspect | activity and failures (no payloads), outbox |

\* No effect on the application. They write only verification evidence.

## 4. Delivery: a sequence of PRs, each independently useful and tested

| # | PR | Proves |
|---|---|---|
| 1 | Operations registry and catalog; `project.inspect`, `schema.inspect`, `test.run`, `build.run`; CLI `feltkit op`, MCP and AppPort adapters over one handler; profiles on the existing authority; activity evidence | An agent discovers the operations, sees the authority each needs, and runs them through all three adapters with the same results; a missing permission is refused per call; revocation applies mid-session |
| 2 | Change sets and isolated workspaces; `change.propose`, `schema.change`, `function.*`, `change.verify` (digests) | Edits only in the workspace; verification is independent of the model; a workspace edited after verification is detected |
| 3 | Deployment revisions and receipts; `deploy.plan`, `deploy.apply`, `change.apply` to a **local production environment** first, then the existing platform targets | Receipt only after deployed health; a failed deploy gives no receipt; a stale base revision is refused; no deploy permission means refused, and the change stays verified and awaits approval |
| 4 | AuthBoundry adapter (delegations, agent credentials) behind the same authority boundary; upstream asks: environment scope and decision lookup by id | Delegated authority per environment; revoking a delegation stops the next operation |
| 5 | Resolver references for models, credentials, endpoints and values; resolution and revisions recorded | A credential is never in the agent's context; revocation stops the next resolve; rebinding without a redeploy |
| 6 | The invoice acceptance scenario, end to end, through two agent clients (CLI and MCP) | Build, operate, evolve (second approval over $10,000), and the boundary checks |

## 5. Decisions (settled by the owner, 2026-11-03)

1. **Authority in PRs 1–3: FeltKit's existing authority.** Sessions are checked per call and
   revocable. The inspect, develop and deploy profiles are permission sets on it. The AuthBoundry
   adapter comes in PR 4, with the upstream asks (environment scope, decision lookup by id).
2. **Resolver: published first.** `@appport/resolver-client` (and the server package, for tests) is
   published before FeltKit's Resolver PR, which then takes a normal semver range.
3. **First deployment target: a local production environment** (`feltkit start` on a volume). The
   platform targets (Vercel, Cloudflare, Fly) follow, since they need real credentials.

## 6. PR 1: what exists, and its limits

**Implemented** (`packages/sdk/src/platform/`, tests in `test/platform-operations.test.ts`):

- **The operations**: `project.inspect`, `schema.inspect`, `test.run`, `build.run`, each defined
  once in `operations.ts`. Each has typed input and output, its effect, the permission it requires,
  and an integration descriptor (purpose, effects, approval, failures).
- **One AppPort application, `dev.feltkit.platform`.** The CLI (`feltkit op`), AppPort over HTTP
  (`/appport`) and MCP (`/mcp`, from `feltkit platform serve`) dispatch through its one
  `handleRequest`. The tests show the three answer `schema.inspect` identically.
- **Authority**:
  - FeltKit's `Authority`, with the profiles as roles: `inspect` holds `feltkit.platform.read`;
    `develop` adds `feltkit.platform.develop`; `owner` holds everything.
  - It is checked on every call, and before input validation.
  - A refusal carries a `dec_…` decision id.
  - Platform sessions are FeltKit's session store, so a revoked one is refused at its next request,
    however long the agent has been connected.
- **Evidence**: every invocation goes into the platform's activity log, allowed or refused. Each
  entry has the principal, capability, transport, required permission, decision id, policy
  version, outcome and duration. Input values are not recorded, only their keys.
- **State**: one FeltDB store, `<root>/.feltkit-platform/state`, holding sessions and activity. It
  is the platform's own; application state stays in each project's environments.
  - The store has one owning process. While `platform serve` runs, the CLI reaches it through
    `.feltkit-platform/server.json`: its URL and an owner session, mode 0600, revoked when the
    server stops.
- **Executors**: the work is FeltKit's own CLI (`inspect --json`, `migrate --dry-run --json`,
  `test --json`, `build --json`), run in a child process in the project's directory. The
  platform never imports a project's code.
  - `test --json` reports through a `node:test` reporter: each test's outcome, duration, and on
    failure its message, expected and actual values.
  - `build --json` reports the bundle's SHA-256 and the schema hash.

**Limits (known, not hidden):**

- **A child process is not a sandbox.** `test.run` and `build.run` execute the project's code with
  the operating-system user's permissions. A `develop` profile is therefore a grant to run code on
  this machine. Isolation (a container or a separate user) is the workspace's job and arrives with
  change-set workspaces (PR 2).
- **Projects are named relative to the root.** A name outside it, or one into
  `.feltkit-platform`, is refused. A symlink inside the root that points outside it is not
  resolved and checked.
- **`project.inspect` and `schema.inspect` open the project's development environment.** They read
  it directly when no server runs, or go through `feltkit dev`'s admin API when one does, as the
  CLI does for a person. So `project.inspect` reflects that environment at that moment
  (timestamps, recent activity), not only the source.
- **There is no `deploy` profile yet**, and no capability changes an application. Those arrive
  with change sets (PR 2) and deployment receipts (PR 3).
- **No capability digests in the served manifest.** AppPort computes `capabilityDigest` in its
  canonical-contract registry only; pinning a platform contract waits for that to reach served
  manifests.
- **The decision id of a refusal is FeltKit's own.** AppPort's authorizer issues the id of an
  allowed call. AuthBoundry's durable decisions replace both in PR 4.

## 7. PR 2: change sets, and their limits

**Implemented** (`packages/sdk/src/platform/changes.ts`, `source.ts`; tests in
`test/platform-changes.test.ts`):

- **A change set is the change itself**: the files it writes (UTF-8 content, or null to delete),
  for one project and one environment. It is stored in the platform's FeltDB store
  (`feltkit.platform.changes`) with:
  - **its base revision:** `rev_` and the SHA-256 of the project's source tree. Source means every
    regular file except dot-entries, `node_modules`, `dist` and `feltkit/_generated`.
  - **its content digest:** SHA-256 over its files in path order.

  The platform computes both; neither comes from the caller. The content is immutable: a revised
  change is a new proposal.
- **Paths:** project-relative source only, at most 200 files and 2 MB. Writes refuse a symbolic link
  and any parent that resolves outside the project. This closes, for writes, the symlink gap noted
  in §6.
- **Transitions:**

  | From | To |
  |---|---|
  | `proposed` | `verifying` |
  | `verifying` | `verified` or `verification_failed` |
  | `verified` or `apply_failed` | `applying` |
  | `applying` | `applied` or `apply_failed` |

  - Each transition is one FeltDB transaction: the change record moves from the version it was
    read at (`ifVersion`, so two concurrent transitions cannot both win), and an event is appended
    to `feltkit.platform.change-events` with `requireAbsent`. Events are never rewritten.
  - Refusals that change nothing (stale, unverified, wrong target, altered content) are events too.
  - Each event names the caller, the request and the authority decision.
- **Verification**:
  - It runs in `<root>/.feltkit-platform/workspaces/<id>`: a copy of the project's source with
    `node_modules` linked, and the change written.
  - It runs `feltkit build --json`, then `feltkit test --json`, then a schema plan:
    1. `feltkit backup create --env development` of the project (calls pause if its dev server
       runs);
    2. that backup restored into the workspace;
    3. `feltkit migrate --dry-run --json` there.

    With no development state, the plan is against an empty environment.
  - It passes only when the build succeeded, no test failed, and the plan is not `blocked`.
  - The record holds what each command returned (test counts, each failure's expected and actual
    values, the bundle and schema digests, the plan's status and changes). It is bound to the
    content digest, the base revision and the workspace's resulting revision.
- **Apply**:
  1. It requires `feltkit.platform.deploy` and `feltkit.platform.deploy:<project>/<environment>`,
     which only the `deploy:<project>/<environment>` profile (or `owner`) holds.
  2. It refuses when:
     - the request names another project or environment than the change set's;
     - the change set is not verified;
     - the stored content's recomputed digest is not what was verified;
     - the content is not the `expectedContentDigest` the caller reviewed;
     - the project is not at the base revision;
     - the project's existing artifact is for another deploy target.
  3. It records the previous content of every path it will write, then writes the files.
  4. It checks that the project is now at exactly the verified resulting revision.
  5. It runs `feltkit deploy --target container --json`, the existing lifecycle: build, boot the
     production build against isolated state, check health, the AppPort endpoint and the frontend,
     and only then replace `.feltkit/deploy`.
  6. The receipt is written only when deploy returned with its health check passed. It holds the
     change, base and resulting revisions, content digest, verification, the artifact's bundle
     SHA-256, the health result, who applied it, and the decision ids.
  7. Any failure restores the recorded files, records `apply_failed` with the reason and whether
     the source is back at the base revision, and writes no receipt.
- **Retries**:
  - A proposal with the same `idempotencyKey` returns the same change set; the same key with
    other content is refused.
  - A repeated apply of an applied change set returns its receipt without deploying again.
  - Concurrent verifications or applies: one wins, the other gets `CONFLICT`.
- **Interruption**: a platform that stopped mid-transition leaves `verifying` or `applying`. The
  next start recovers before any change operation runs:
  - a verification becomes `verification_failed` (`verification.interrupted`);
  - an apply is rolled back from its recorded previous content and becomes `apply_failed`
    (`apply.interrupted`, with whether the source was restored).

**Limits (known, not hidden):**

- **Child processes are not an OS security sandbox.** Verification runs the change's own build
  and test code, and apply runs `feltkit deploy`, which boots it. Both run as the operating-system
  user, with that user's files and network. `develop` can therefore run arbitrary code on this
  machine through `change.verify`. A container or a separate OS user is the deployment's job and
  is not provided here.
- *(Superseded by PR 3, §8:* apply now deploys through local production deployments. A release
  directory per deployment means nothing running is replaced under it, and the receipt proves
  the running process passed live verification.*)*
- **One environment:** `production` as the local `container` target. A project whose artifact is
  for another target is refused. Hosted targets need credentials (§5).
- **The schema plan uses development data, not production's.** Production applies its migrations
  when the artifact starts (FeltKit's activation refuses drift).
- **The platform store is the authority.** The platform recomputes the content digest from the
  stored files, so an inconsistent edit of the store is caught (tested). But anyone who can write
  `<root>/.feltkit-platform` as the OS user can forge a consistent record. File permissions are
  the boundary.
- **Base-revision staleness is checked against the source tree only.** State and configuration
  (`.env*`) are not part of the revision.
- **No approval step.** Apply is authorized by the deploy profile alone; `delegatedBy` in the
  receipt is null until AuthBoundry delegations (PR 4). A refusal's decision id, and an allowed
  call's when AppPort's reference is absent from a handler's error, are FeltKit's own `dec_…`.
- **History.** Every event of a change set is listed (read in FeltDB pages; until 2026-11-03 it
  stopped at 1,000).

## 8. PR 3: local production deployments and runtime operations

### Inventory: what existed, and what was reused

| Mechanism | What it does | In PR 3 |
|---|---|---|
| `feltkit start` (`startProduction`) | Loads `.feltkit/build/functions.mjs` and resolves the production environment (`FELTKIT_STATE_DIR` for local state). Opens its port early, starts the runtime, writes `runtime.json`, and closes cleanly on SIGTERM. Applies the declared schema at start (`migrate: auto`): a change FeltDB would refuse stops it before it serves. | **The production process**, unchanged, plus the bundle digest it loaded. Migrations are applied only by this existing mechanism. |
| `feltkit deploy` | Builds, boots the build against a temporary state directory, checks `/_feltkit/health`, the AppPort manifest and the frontend, then writes an artifact. The default `.feltkit/deploy` is replaced in place (even under a running server); `--out` never overwrites. | **The candidate build and artifact verification**, with `--out` into a new release directory per deployment. The in-place default is not used. |
| Container build | The artifact carries a Dockerfile and docker-compose with the state on a volume. The same artifact runs with plain Node. | Local production runs the artifact with Node. Docker is not used. |
| Persistent state | Local production state defaults to `<project>/.feltkit/production/state`. Its secrets (API-key verifier, auth secret) are kept beside it. | **The persistent volume**, the same place `feltkit start` and `feltkit backup --env production` use. |
| Health | `/_feltkit/health` is liveness only: status, application and environment. The deploy check boots against isolated state. Neither proves which artifact runs, on which state. | **Added `/_feltkit/deployment`** (below). The isolated boot check is recorded as *artifact* verification only. |
| Backup and restore | `backup create` reads a stopped environment directly. `restore` writes only into a new, empty environment, after verifying the file. | **The pre-deployment backup**, and the restore when rolling back. |
| Server lifecycle | Nothing supervises a production process. `runtime.json` records the pid. | Unchanged: no supervisor (see the limits). |
| PR 2's apply | Writes the files, deploys, and on failure restores the source. Idempotent, fenced, and recovered at start. | Kept. It now deploys through local production deployments, and the receipt includes the deployment's. |

### The lifecycle (`deployments.ts`)

`deploy.apply` deploys the project's current source after its tests pass. `change.apply` deploys
a verified change set, as in §7. Both go through one lifecycle:

1. **Plan.** One fenced transaction marks the environment `deploying` and creates the deployment
   record. A second deployment at the same time gets `CONFLICT`.
2. **Candidate.**
   - It is built into `<project>/.feltkit/releases/<deployment>` with `feltkit deploy --target
     container --out … --json`. This records the artifact verification: the isolated boot check
     and the bundle SHA-256.
   - The source must still be at the revision being deployed.
   - A failure here touches nothing that is running.
3. **Cutover.**
   - The running release stops (SIGTERM, then SIGKILL after 15 s), because only one process can
     own the volume.
   - The volume is backed up into the release directory (`feltkit backup create --env
     production`).
4. **Start.**
   - The candidate runs as a detached `feltkit start` on the volume, on the environment's port
     (127.0.0.1).
   - It gets `FELTKIT_DEPLOYMENT_ID`, `FELTKIT_DEPLOYMENT_REVISION` and a random
     `FELTKIT_DEPLOYMENT_TOKEN`.
   - Its output goes to the release's `server.log`.
5. **Live verification.** The candidate is polled at `/_feltkit/deployment` (token required)
   until it is ready, it exits, or the readiness timeout passes (60 s by default). Then nine
   checks against what the process itself reports:
   - **ready:** it reports `ready`;
   - **application:** the application the artifact was built for;
   - **environment:** production;
   - **deployment:** the deployment id;
   - **revision:** the source revision;
   - **artifact:** the SHA-256 of the bundle the process loaded equals the release's;
   - **state.location:** its state is local, at the volume;
   - **state.access:** it read back the start record it wrote to that state;
   - **schema:** its schema is current.
6. **Commit** in one transaction:
   - the deployment becomes `live`, with its receipt;
   - the environment's active deployment becomes this one;
   - the previous deployment becomes `superseded`.
7. **Otherwise roll back.** The candidate is stopped and no receipt is written.
   - The previous release is started again on the volume and verified (its deployment id,
     revision and bundle).
   - If it cannot run there, for example because the candidate migrated the state first, the
     volume is moved aside (never deleted). The pre-deployment backup is restored into a fresh
     volume, and the previous release is started and verified again.
   - If that fails too, the environment is **`degraded`**: no active deployment, with the
     reason, every attempt, and `rollback.failed` in the history.
   - A failed *first* deployment moves the state it created aside, so production has no state,
     as before.

Interrupted deployments are handled by the next platform start. A deployment still `deploying`
is failed with `feltkit.INTERRUPTED`: its candidate is stopped and the rollback above runs. PR
2's recovery rolls back the change set's files.

**Idempotency.** `deploy.apply` of the revision that is running and still verifies returns that
deployment's receipt and deploys nothing. A repeated `change.apply` returns the change's receipt.

### Receipts and evidence

A receipt (`kind: local-production-deployment`) holds:
- the project, environment, deployment id, change-set id, and source revision and content
  digest;
- **`artifact`**: the release, the bundle SHA-256, the schema hash, and the *isolated-boot*
  verification;
- **`live`**: the *live* verification (time and the nine checks), the pid, URL, start time,
  application, and state location;
- `health`: the status and time;
- **`migration`**: the schema before and after, and whether a migration was applied;
- `previous`: the deployment it replaced;
- `authorizedBy`: the principal and decision id.

What a receipt means, in its own words: *"The expected artifact was running and passed these
checks at verifiedAt. It is not a guarantee of future availability."*

Failed, rolled-back and degraded deployments are durable records with their stage, error,
checks, rollback outcome and every step in `feltkit.platform.deployment-events`. They have no
receipt.

### Runtime operations

| Operation | Permission | Returns |
|---|---|---|
| `runtime.inspect` | read (inspect profile) | The active deployment, checked now: what the process reports, whether it matches the record, health, schema, state location, and the last result |
| `deploy.status` | read | The environment's status, any deployment in progress, the latest deployment with its whole history, and the last 20 deployments (the newest 20 by start time, ordered by FeltDB; until 2026-11-03 the newest of the first 1,000 read) |
| `runtime.logs` | `feltkit.platform.logs` (develop and deploy profiles; not inspect) | At most 500 lines from the last 64 KB of a deployment's `server.log` |
| `deploy.apply` | the `deploy:<project>/<environment>` scope | Runs the project's tests, then the lifecycle above |

Every call goes through PR 1's authority: inspection never implies deployment authority, and a
revoked session is refused at its next call.

### Tests (`test/platform-deployments.test.ts`, against real processes)

- **First deployment:** the receipt's artifact and live verification, the process answering, the
  token-guarded report, `runtime.inspect` matching, the history, and bounded logs.
- **Persistence:** data persists across a platform restart (the process keeps running), a
  process stop (redeployed, data intact), and a change applied to the running deployment.
- **Migration:** a migration applied at start against production records, recorded in the
  receipt.
- **Failed start:** a candidate that fails to start leaves the previous one running, its data
  intact and the source restored. The candidate's output is in `runtime.logs`.
- **Readiness timeout:** the hung candidate is stopped and rolled back.
- **Wrong artifact:** a release altered after its digest was taken is refused. It had migrated
  the volume, so the pre-deployment backup was restored and the migrated volume kept aside.
- **Blocked migration:** a migration production data blocks fails the candidate, and the state
  is unchanged.
- **Degraded:** an inaccessible volume, with rollback impossible, leaves production degraded with
  no receipt. Repairing the volume and deploying again recovers it.
- **Interrupted:** an interrupted deployment and change are rolled back at the next start.
- **Retries and races:** a replayed apply deploys nothing; of two concurrent deployments, one
  wins.
- **Authority:** inspection versus logs versus deploy, the deploy scope, and revocation.

### Limits and operational risks (known, not hidden)

- **No supervisor.** A production process that crashes, or a machine that restarts, is not
  restarted. The state survives on the volume, and `runtime.inspect` shows `stopped`;
  `deploy.apply` starts the same revision again as a new, verified deployment. A service manager
  (systemd, launchd, a container restart policy) is not provided.
- **Downtime during cutover.** One process can own a local volume, so the old process stops
  before the candidate starts (seconds), and again during a rollback.
- **Restoring the backup can discard writes.** If the candidate accepted writes before failing
  and the previous release could not run on that volume, those writes are in the moved-aside
  volume, not in the restored one. The receipt and the record say which happened.
- **The operator key is per release.** It lives in the release's runtime directory, so a grant
  signed for one release is not accepted after the next deployment unless `FELTKIT_OPERATOR_KEY`
  is set. The verifier and auth secrets are beside the volume and persist.
- **Local only:** 127.0.0.1, one port per environment, `production` only. No cloud targets; the
  deployment record is target-shaped (`kind`, release, checks) so that others can be added.
- **Not cleaned up:** release directories, pre-deployment backups and moved-aside volumes are
  kept, and nothing removes them yet.
- **Probe tokens:** they are kept in the platform store, never shown by any operation, and a new
  one is used for each start.
- **`deploy.apply` runs the project's tests in place, not in a workspace.** A refusal because
  tests fail is in the activity log, not a deployment record. `change.apply` relies on the change
  set's own verification (§7).
- **Child processes are not an OS security sandbox.** Builds, tests and the production process
  run as the OS user.

## 9. PRs 4–6: where they stand (2026-11-03)

Checked against npm on 2026-11-03. Nothing here is implemented.

| PR | Precondition | State | Blocks it |
|---|---|---|---|
| 4: AuthBoundry adapter | A published AuthBoundry with delegations and agent credentials; the upstream asks (environment scope, decision lookup by id) | `@authboundry/core` **1.15.3**, published 2026-09-21, license `UNLICENSED`. The §1 inventory read AuthBoundry's `main`, six weeks newer; whether delegations, agent credentials and runs under a delegation are in 1.15.3 is **unverified**. Neither upstream ask is addressed. AppPort 1.5.0 adds no `agent` principal type, on-behalf-of chain or `policyVersion` | (1) a published AuthBoundry release containing what §1 lists, verified against FeltKit; (2) a license FeltKit can depend on; (3) the two asks, or an explicit decision to ship without them |
| 5: Resolver references | §5.2: Resolver published first | **Met in part.** `@appport/resolver-client`, `@appport/resolver` and `@appport/resolver-core` 0.1.0 were published 2026-11-03. None declares a license. `@appport/resolver` (the server, needed for FeltKit's tests) pins `@appport/services` **0.9.1** and `@feltdb/core` **0.18.0** exactly: Services 0.9.1 predates the peer dependency (0.11.0), so it installs its own FeltDB, the two-copy problem FeltKit's release gate refuses. `resolver-client` depends on `@appport/sdk` 1.4.0 and `resolver-core` only | (1) a Resolver server release that takes `@feltdb/core` and `@appport/services` as peer or floating dependencies; (2) a declared license; (3) §5's other conditions (multi-instance sync verified on a FeltDB server) |
| 6: invoice acceptance scenario | PRs 4 and 5 | Not started | PRs 4 and 5 |

Before any of these: keep the PR 1–3 suite green at scale (`test/platform-large-state.test.ts`), and
adopt a new FeltDB release only once `npm run test:all` passes on it.

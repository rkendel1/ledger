# From a local app to production

The path, what FeltKit does at each step, and what remains yours. `npx feltkit readiness`
(and Studio → Readiness) checks every step that can be checked; nothing here is reported as
done because a build passed.

## 1. Create

```bash
npm create feltkit@latest my-app && cd my-app && npm install && npm run dev
```

## 2. Configure a model

Decisions use the environment's model, selected in AppPort Services Intelligence (enable it
with `services: { intelligence: true }`):

```bash
npx feltkit model set --provider ollama --model llama3.2 --endpoint http://localhost:11434/v1
npx feltkit model set --provider openai --model gpt-4o-mini --credential credential-ref:openai
npx feltkit model show
```

Providers: `openai`, `anthropic`, `opencode`, `ollama`, `custom` (any OpenAI-compatible
endpoint). A credential is a reference; its value goes in `FELTKIT_CREDENTIAL_<ID>` in that
environment's process. Studio → Models shows what the runtime can decide (FeltDB
`DecisionRuntime` capabilities) and **Test** calls it. Or pass any `DecisionRuntime` as
`feltkit({ agent: { decisions } })`.

## 3. Connect a tool

```ts
export const payments = app.integration("payments", {
  baseUrl: { env: "PAYMENTS_URL", development: "http://127.0.0.1:4010" },
  credential: "credential-ref:payments",
  operations: {
    create: { method: "POST", path: "/payments", input: { … }, output: …, effect: "consequential",
              access: "payments.write", idempotencyHeader: "Idempotency-Key",
              verify: { operation: "lookup", input: { invoiceId: { $input: "/invoiceId" } }, expect: [ … ] } },
    lookup: { method: "GET", path: "/payments/by-invoice/{invoiceId}", output: …, effect: "observation", access: "payments.read" },
  },
});
```

Studio → Integrations shows the published contract, configuration, **Check** (the health
path), and every call. Readiness warns about consequential operations that declare neither
idempotency nor verification.

## 4. Build a workflow

Durable steps are application state, `ctx.services.jobs`, and agent tasks. From a mutation,
`ctx.agent.start({ objective, decision: { question, options, context } })` opens a review
task after commit; the model's choice becomes a proposal that waits for approval. See
`examples/invoices`.

## 5. Test

```bash
npx feltkit test         # each test app gets its own FeltDB instance
```

Use deterministic fixtures for models and APIs (`examples/invoices/fixtures`). No test
needs a paid account.

## 6. Review readiness

```bash
npx feltkit readiness --env production   # on the production host, server stopped; exit 1 on failures
```

It checks storage, every credential reference, end-user sign-in, wildcard roles, Studio
operators, the model selection, each integration's configuration (production never uses a
development default, HTTPS, no loopback), uncertain-outcome handling, open unknown
outcomes, background work, and the build. Failures say how to fix them.

## 7. Deploy (supported path)

```bash
npx feltkit deploy --out ./artifact       # builds, boots the build against a temporary state, verifies health
cd artifact && npm ci --omit=dev
```

Run it with the production environment:

| Variable | Purpose |
|---|---|
| `PORT` | listen port |
| `FELTDB_URL` + `FELTDB_TOKEN` | a FeltDB server, **or** `FELTKIT_STATE_DIR` for local state (setting both fails) |
| `FELTDB_APPLICATION_ID` (+ `FELTDB_ENVIRONMENT`) | Managed FeltDB: the application and environment, under the contract `feltkit contract` writes and `feltdb publish --contract` promotes. See the managed starter ([`examples/managed`](../examples/managed/README.md)) |
| `FELTKIT_API_KEY_VERIFIER_KEY` | required when API keys are enabled |
| `FELTKIT_CREDENTIAL_<ID>` | every credential reference (readiness lists them) |
| integration base URLs (e.g. `PAYMENTS_URL`) | production endpoints (HTTPS) |
| `FELTKIT_DASHBOARD=1` + `FELTKIT_OPERATOR_KEY` | production Studio for operators (`feltkit operator grant`) |

Select the production model on the host: `npx feltkit model set --env production …`.

## 8. Operate

Production Studio (operators only): inspect jobs, deliveries, agent tasks, integrations,
readiness; approve, reject, retry, settle; verify unknown integration calls; ask a model
again. Development tools are not served in production (docs/GUARANTEES.md).

## What FeltKit does not provide

These are listed by readiness as "outside FeltKit" and are yours:

- **TLS and a reverse proxy.** FeltKit serves HTTP. Production Studio's cookie is `Secure`,
  so it needs HTTPS. Set `Host` / `X-Forwarded-Host` to the public host.
- **Rate limiting.** In the proxy or platform.
- **Backups and restore.** Of the state directory or the FeltDB server. Test restores.
- **Monitoring and alerting.** FeltKit offers `/_feltkit/health`, stdout logs, and the
  activity log; no metrics endpoint or alerts.
- **Secret provisioning.** From a secret manager into the process environment.
- **Network access to `/_feltkit/`.** Allow-list or proxy rules, in addition to operator
  sign-in.
- **Hosting, scaling, and high availability.** One process per environment; the local
  runtime is single-host.

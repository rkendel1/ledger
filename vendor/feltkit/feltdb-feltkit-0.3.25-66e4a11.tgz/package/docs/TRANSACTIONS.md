# Transactional sequences and after-commit effects: the contract

Status: **settled and implemented** (FeltKit 0.3.12, AppBoundry 1.5.0). This document was
written before the code: it records what `ctx.db.sequence` and `ctx.afterCommit` did on
FeltKit's runtime, measured rather than assumed, the contract both runtimes (FeltKit's Node
runtime and AppBoundry artifacts) now meet, the decisions the owner made (§5), and the evidence
(§7).

## 1. What existed (FeltKit 0.3.11, Node runtime)

### `ctx.db.sequence(name)` (`src/runtime/data.ts`)

- **Storage.** There is one record per name in `_feltkit_sequences` (`{ id: name, value, transactionId }`).
- **Allocation.** The mutation reads the record and hands out `value + 1, + 2, ...` in call order.
- **Commit.** The new value is written in the mutation's own FeltDB transaction, guarded by the
  version it read (`ifVersion`, or `requireAbsent` for a new name).
- **Concurrency.** Two mutations that drew from the same name: the second commit fails with
  `PRECONDITION_FAILED`, which reaches the caller as `CONFLICT` with nothing written. There is
  no retry.
- **Failure.** A handler that throws, or a refused commit, writes nothing, so it consumes
  no numbers.

The documented API (`DatabaseWriter.sequence`) promises the following:

- values increase in commit order, across processes, and in call order within a mutation;
- there are no gaps;
- concurrent use of one sequence serializes and the later commit gets `CONFLICT`;
- "name a sequence per stream (e.g. `audit:<invoiceId>`)" so unrelated writers don't contend.

### `ctx.afterCommit` (`src/runtime/outbox.ts`)

- **Staging.** `notifications.send`, `webhooks.emit` and `jobs.enqueue` stage an
  `_feltkit_outbox` record (`pending`) in the mutation's transaction (`Writer.stageSystem`).
- **After commit.** The runtime claims the record (`pending → performing`, version-checked),
  performs the effect as the caller, and records `done` or `failed` with the error.
- **Recovery.** The services worker recovers records left `pending` for more than 30 s, or
  `performing` for more than 300 s, as the caller's current principal.
- **Inspection.** The records are listed in the admin collection registry, and Studio shows them.

## 2. What was measured

`node --test` probe, 10 concurrent mutations on one runtime, each inserting one `events` record
(`stream`, `seq`, `what`):

| Mutation | Result |
|---|---|
| insert, no sequence | 10 ok |
| one shared stream, `sequence("audit")` | **1 ok, 9 `CONFLICT`** (SupplyDesk's result) |
| a stream per mutation, `sequence("inv-<n>")` | 10 ok |
| per stream, plus an equality read of its own stream (`find(events, { stream })`) | 10 ok |
| per stream, plus an unfiltered read of the collection (`find(events, {})`) | 1 ok, 9 `CONFLICT` |
| a stream per mutation, named as documented: `sequence("inv:<n>")` | **10 `INTERNAL`** |

Findings:

1. **Independent streams already don't contend.** The sequence record is per name, and the
   collection markers are written unguarded. SupplyDesk's audit trail used one global stream,
   so its mutations serialized as documented.
2. **An unfiltered read conflicts for the right reason.** The 1/9 result for a full read is the
   read fence (serializability of what the handler read), not the sequence.
3. **Bug: the documented per-stream naming fails.** FeltDB record ids must match
   `[A-Za-z0-9._-]{1,128}`. FeltKit accepts `:` in sequence names and uses the name as the
   record id, so FeltDB refuses the transaction (`INVALID_REQUEST`) and callers see `INTERNAL`.
   Every name containing `:` has always failed, so no stored record uses one, and encoding
   such names is backward compatible.
4. **`failed` effects are terminal.** You can inspect them, but nothing can retry them.
5. **Recovered jobs and webhook events can be duplicated.** Notifications are deduplicated by
   the outbox id. `@appport/services` `jobs.enqueue` and `emitWebhookEvent` take no
   idempotency key, so a crash between performing an effect and recording `done` can enqueue
   or emit twice.

## 3. FeltDB review

- **Atomicity.** `db.transaction({ operations, preconditions, fences })` commits application
  writes, sequence records and outbox records together, or none of them. AppBoundry's
  `CollectionTransaction.commit(transactionId, extra)` already commits `extra` operations in
  the application's transaction. **No second transaction system is needed, and nothing is
  missing upstream for atomicity.**
- **Durability and restart.** Outbox records are ordinary FeltDB records in the state
  directory or managed environment, so they survive restarts.
- **`db.allocateSequence({ scope, scopeId })` is not usable here.** It allocates outside the
  transaction (a failed mutation would consume a number), and only the file backend has it.
- **No in-transaction increment.** FeltDB has no operation whose value is assigned at commit
  and visible to other operations in the same transaction. With one, a single stream could be
  allocated without conflicts. It is an optional upstream enhancement, recorded in
  `UPSTREAM-GAPS.md`; this contract doesn't need it.
- **Transactional services exist upstream, but can't be used yet.** `@appport/services` has a
  transaction context (`queueJob`, `queueWebhookDeliveries`) that creates jobs and webhook
  deliveries inside a FeltDB transaction, and it accepts FeltKit's outbox `done` write in the
  same transaction. Implemented and tried (decision C): 0.13.0's transaction context writes audit
  fields its own `servicesContract` doesn't declare (`job_audit_events.jobType`,
  `webhook_audit_events.eventType`), so FeltDB refuses the transaction under an enforced
  contract. Recorded as UPSTREAM-GAPS S11; the fallback applies (§5 C).

## 4. The contract (both runtimes)

| Guarantee | Behavior |
|---|---|
| Sequence allocation | Atomic with the mutation and durable. A number is consumed only by a committed mutation. |
| Ordering | Per stream (the sequence name): strictly increasing, gapless, in commit order. Within one mutation, in call order. **No ordering between different streams.** |
| Independent streams | Mutations on different streams never conflict on the sequence. |
| Same stream, concurrent | Serializable: at most one of two concurrent writers commits from the same value (see Decision A for what the other one gets). |
| Transaction failure | No sequence advance, no outbox record, no effect. |
| Outbox creation | The record commits in the mutation's transaction, or not at all. |
| Rollback | No after-commit effect. |
| Restart | `pending` and stale `performing` records are recovered by the runtime's worker. |
| Duplicate processing | Claiming is version-checked, so two workers never perform one record concurrently. A job or webhook delivery is created in the transaction that records the effect done: once per committed effect (Decision C). Notifications are idempotent (key = outbox id). |
| Failed delivery | Recorded with its error, inspectable, and retryable (Decision B). |
| Delivery | Creation is exactly once. A job's run and a webhook's delivery to its endpoint are AppPort Services' own: at least once. **No exactly-once claim for external systems.** |

**Sequence names.** A name is 1–128 characters from `[A-Za-z0-9_.:-]`, starting with a letter
or digit (unchanged). A name that is a valid FeltDB id stays the record id, so existing data
is untouched. Any other name (one containing `:`) is stored under a derived id: `_` plus a hash
of the name, which no valid name can produce. The record keeps the name.

**One implementation in FeltKit.** The guest-side `afterCommit` API and its record shape, the
sequence name rule and encoding, and the outbox state machine and recovery policy move to a
shared module with no Node imports. FeltKit's runtime and the artifact guest (through the
host) both use it.

**Anonymous callers.** An effect runs as the caller. A function called without a signed-in caller
(`access: "public"`, such as a contact form) has no one to run it as, so staging a notification,
webhook or job refuses with `UNAUTHORIZED`, and the mutation doesn't commit. The refusal names the
function and the supported path: declare an agent (`app.agent`, §8) and stage
`ctx.afterCommit.agent(name, input)`. The agent runs after the commit as its own declared principal and
can send the notification. In an AppBoundry artifact, where application agents can't run, the refusal
says so instead. Giving effects a declared identity of their own is an open design question (TA-1 in
docs/platform/GAP-REGISTER.md).

**AppBoundry: host interface `transactions@1`.** It is required only by artifacts that use
these features:

- `db.sequence { name }` → the next number, tracked in the host's transaction and committed
  with it (the same guard as FeltKit's runtime);
- `effect.stage { effect }` → `{ outboxId }`, an outbox record committed with the mutation;
- after commit, the host performs staged effects through its services as the caller and
  records `done` or `failed`. Its job worker recovers stale records, so they survive restarts;
- the records go in host-owned collections (`_appboundry_sequences`, `_appboundry_outbox`)
  with the record shapes above, so the host stays producer-neutral;
- `appboundry admin outbox list | retry <id>` lets an operator inspect and retry;
- a host without `transactions@1` refuses such an artifact when it loads, and FeltKit's
  compatibility check names the release that provides it.

## 5. Decisions (settled by the owner, 2026-11-03)

**A. Same-stream contention: default unchanged, opt-in retry.** The later writer still gets
`CONFLICT`. A mutation may declare `retry: { sequenceConflicts: n }` (1–10). The runtime then
re-runs its handler, at most `n` more times, when the commit was refused on a sequence record
(FeltDB's conflict detail names the first failing precondition) and the attempt used no
`ctx.services`. `ctx.afterCommit` is part of the transaction, so it doesn't count. Opting in
states that the handler is safe to run again, which FeltKit can't check for effects outside
FeltKit. The policy travels in the artifact's manifest (`functions[].retry`), so AppBoundry
applies it the same way. Re-runs are recorded: activity `detail.sequenceRetries` on FeltKit,
`retries` on AppBoundry's call result.

**B. Retrying a failed effect: operator action only.** `feltkit outbox list | retry <id>`
(through a running server's admin API, else the environment directly) and
`appboundry admin outbox list | retry <id>` (a running runtime performs it at once; a stopped
state moves it to `pending` for the runtime's worker) move `failed → pending`. They keep the
attempts and last error and record who retried. There is no automatic retry schedule.

**C. Jobs and webhook deliveries: created exactly once per committed effect.** The performer
claims the record (`pending → performing`, version-checked). It then creates the job, or the
deliveries to the endpoints subscribed to the event, through AppPort Services' transaction
context (`tx.queueJob`, `tx.queueWebhookDeliveries`). The record's done write, guarded on the
claim's version, goes in that same FeltDB transaction:
- both commit, or neither does;
- a refused creation leaves no job and no done mark, and the record is `failed` with the error;
- a process that stops before the transaction committed nothing, so recovery creates the effect
  once.

This needs `@appport/services` 0.13.1. Its 0.13.0 wrote audit fields its own contract didn't
declare (UPSTREAM-GAPS S11, fixed by rkendel1/appport-services#42); until then this was
at-least-once. Notifications don't repeat either, because the outbox id is their idempotency key.
Creation, not execution: a job's run and a webhook's delivery to its endpoint stay at least once.

## 6. Acceptance tests (real persisted state, real concurrency)

- Two independent streams advance concurrently (N concurrent mutations, N streams, all ok).
- One stream: strictly increasing, gapless numbers across concurrent and sequential mutations.
- Failed mutations (a throw, or a refused commit) consume no numbers.
- Application writes and outbox records commit together. A failed transaction leaves no
  outbox record and no effect.
- A restart preserves pending outbox records, and the worker performs them once.
- Reprocessing a claimed or done record doesn't repeat its outcome.
- A failed delivery is inspectable and retryable.
- A name containing `:` works, and existing names keep their records.
- The same artifact gives identical outcomes and records on FeltKit's runtime, AppBoundry's
  source build and the packed package (extending `tests/e2e/state-contract-parity.test.mjs`).
- Existing applications keep their ordering: `test/sequence.test.ts` passes unchanged.

## 7. Evidence (sequences and after-commit effects)

- `packages/sdk/test/transactions.test.ts` (FeltKit runtime, local state directory) covers:
  - 10 concurrent streams, 3 rounds, all committed and each `[1, 2, 3]`;
  - one stream without opt-in: losers get `CONFLICT`, committed numbers gapless;
  - with opt-in: all 10 commit, numbers gapless, re-runs recorded;
  - with a service used: not re-run;
  - a failed mutation consumes nothing;
  - `:` names work, and existing names keep their record ids;
  - outbox records commit with the mutation, and none exist for a failed one;
  - a restart preserves pending records, and two concurrent recoveries perform each once;
  - a failed effect is inspectable, never retried on its own, and retried by an operator
    after the cause is fixed;
  - `feltkit outbox list` / `retry` from the CLI.
- `packages/sdk/test/appboundry.test.ts`:
  - an artifact using these features requires `transactions@1`, and its manifest carries
    the retry policy;
  - sequences and after-commit effects give the same results in an artifact as on a FeltKit
    server (createArtifactTestApp).
- AppBoundry `packages/appboundry-host/test/transactions.test.ts` covers the same contract on
  the host:
  - concurrent streams, the opt-in retry, failed mutations and `:` names;
  - outbox commit and performance after it, restart recovery, and operator retry on a stopped
    state and on a running one (after a fixed artifact is deployed);
  - an artifact that doesn't require the interface is refused the operations, and an
    unsupported interface version is refused when the artifact loads.
- `tests/e2e/outbox-lifecycle.test.mjs` runs the outbox lifecycle on FeltKit's runtime, AppBoundry's
  source build and its package, each on persisted state with the contract enforced, and compares
  what FeltDB holds after each phase. The phases: a mutation's job, webhook delivery and
  notification; a job FeltDB refuses (no job, no done mark); a stop with an effect claimed but not
  created; recovery creating it once; another restart creating nothing.
- `tests/e2e/transactions-parity.test.mjs` runs one FeltKit application on FeltKit's runtime,
  AppBoundry's source build and the packed 1.5.0, each on persisted state, with concurrent calls
  and a restart. All three must give the same results.

## 8. Application agents (`app.agent`)

Added for FK-GAP-008 ("@assistant mention → the agent reads the conversation and acts, as itself,
through the app's capabilities"). It is one more after-commit effect, not a second agent runtime and
not a new worker: the outbox above is the queue, the services worker is the executor, and the
handler is ordinary application code run through the runtime's call path.

```ts
export const assistant = app.agent("assistant", {
  principal: { id: "assistant", displayName: "Assistant" }, // type "agent"
  roles: ["assistant"],                // declared in feltkit({ roles }): its whole authority
  access: "messages.write",            // checked against those roles; required (no default)
  on: mentioned,                       // optional: app.event(s) that trigger it
  retry: { maxAttempts: 5, backoffMs: 1000 }, // defaults
  leaseMs: 300_000,                    // default
  handler: async (ctx, input) => {
    // ctx is a mutation's context, as the agent; ctx.trigger = { agent, idempotencyKey, attempt, by, event?, requestedTenantId? }
    const recent = await ctx.db.find(messages, { roomId: input.roomId });
    await ctx.db.insert(messages, { roomId: input.roomId, author: ctx.auth.principal!.id, text: summarize(recent) });
    // a model decision among options: ctx.agent.start({ objective, decision }) (FeltKit's agent, as this principal)
  },
});

// In a mutation: the app decides when (deterministic, testable).
if (text.includes("@assistant")) ctx.afterCommit.agent("assistant", { roomId });
```

### Triggers, and why these two

- **`ctx.afterCommit.agent(name, input)`** is the general one. The application decides, in the
  mutation that made the change, whether an agent should act (a mention, a status change), with
  exactly the input it needs. It is staged like every other after-commit effect, so it inherits the
  outbox's guarantee: recorded if and only if the mutation commits.
- **`on: event`** is sugar over an existing primitive: when a mutation publishes an `app.event` named
  in an agent's `on`, the run is staged at that moment, in the same transaction. The handler's input
  is `{ event, payload, scope? }` and `ctx.trigger.event` names the event. The event itself stays
  ephemeral (at most once, to current subscribers); the agent's run is durable.

Data-change triggers ("whenever a record matches X") are not offered: they would need a durable
change feed with its own cursor and ordering, which is the control plane this design avoids. A
mutation that writes the record can call `ctx.afterCommit.agent` itself.

### Execution

| Step | Behavior |
|---|---|
| Staging | An `_feltkit_outbox` record (`effect: { service: "agent", method: "run", agent, input, tenantId?, event? }`), `principalId` = the caller (or `anonymous`), in the mutation's transaction. An unknown agent name is INVALID_ARGUMENT in the mutation. |
| Rollback | A handler that throws, or a refused commit: no record, no run. |
| After commit | The runtime starts the run at once, detached: the caller's response does not wait for it, and the caller's services binding is not used. |
| Claim (lease) | `pending → performing`, version-checked (one performer at a time). A claim older than the agent's `leaseMs` is taken over by the services worker. |
| Identity | `{ id: principal.id, type: "agent", roles }`, plus a tenant only by its own membership (below). The triggering caller's roles, session and tenant role are never used. |
| Authority | `Runtime#call("agent/<name>", input, { principal, via: "agent" })`: roles → `access` → `feltkit({ authorize })` (it sees `function: "agent/<name>"`), then the handler with a mutation's `ctx` (`db`, `services`, `afterCommit`, `events`, `agent`) plus `ctx.trigger`. Nobody can call `agent/<name>` by name from outside. |
| Writes | Commit under a FeltDB transaction id derived from the record (`agent:<outboxId>`). An attempt repeated after an earlier one committed (the done mark was lost) is refused by FeltDB's transaction-id binding and recorded done with `result.committedEarlier`: **the run's writes commit at most once per trigger.** |
| Success | `done`, `result: { requestId, tenantId? }`; the activity entry carries `detail.agentRun` (agent, idempotency key, attempt, who triggered it, from which function, event). |
| Failure | `UNAUTHORIZED`, `FORBIDDEN`, `NOT_FOUND`, `INVALID_ARGUMENT`, `FUNCTION_NOT_FOUND`: `failed` at once (retrying cannot change an authority decision). Anything else: back to `pending` with `error` and `notBefore = now + backoffMs·2^(attempt−1)` (at most 10 min), until `maxAttempts`, then `failed`. A run whose claim expired more than `maxAttempts` times is failed as abandoned. |
| Recovery | The services worker (`runServices`, every second by default) performs due agent records: `pending` past `notBefore` (or 30 s after creation if never started), and `performing` past the lease. Records are FeltDB records: they survive restarts. |
| Operator | `feltkit outbox list` shows them (`agent <name>`); `feltkit outbox retry <id>` runs a failed one again at once. |

**Delivery is at least once.** The handler can run more than once for one trigger (a retry, a
lease taken over from a slow or stopped process). FeltKit makes the run's own FeltDB writes
commit at most once; anything else the handler does (a model call, `ctx.services.*`, an
integration) should be keyed by `ctx.trigger.idempotencyKey`, which is the same on every attempt.
`ctx.afterCommit.*` inside the handler is part of its transaction, so it follows the writes.

### Tenancy

The record keeps the tenant the triggering call worked in (`effect.tenantId`;
`ctx.trigger.requestedTenantId`). When the run starts, the agent works in that tenant **only if
the agent's own principal is an active member there** (`TenancyStore.context`, the same check as
any session, via `runtime.withTenant`): it then holds its membership's role in addition to its
declared roles. Otherwise it runs with **no tenant**: `ctx.auth.tenant` is null and tenant-scoped
collections are closed to it. Add an agent to a workspace like any agent
(`TenancyStore.addPrincipal`, a manager's action). The trigger never carries the caller's tenant
role to the agent.

### Limits

- **AppBoundry artifacts cannot run application agents.** The guest/host protocol runs guest code
  only inside a call, as that call's principal; running a handler later as another principal needs a
  host interface AppBoundry does not have. `feltkit build --target appboundry` refuses `app.agent`
  (naming the agents), the guest's `ctx.afterCommit.agent` answers CONFIGURATION, and FeltKit's
  reference host refuses an `agent` effect. Run such an application on FeltKit's runtime.
- An agent that triggers itself (directly or through an event it publishes) loops; FeltKit does not
  detect it.
- Order between runs is not guaranteed (as for every after-commit effect).
- The lease bounds how long one attempt may run before another process may start it again; set
  `leaseMs` above the handler's longest run (model calls included).

Evidence: `packages/sdk/test/agents.test.ts`: a mention runs the agent once, as the agent, writing with
its own authority (principal id, type and roles, activity entry, record done, no re-run, not callable
by name); refused without the permission and by the authorize hook (failed, nothing written); a failed
attempt is retried with the same key and succeeds, `maxAttempts` failures are recorded and an operator
retry runs it; a run repeated after its writes committed writes nothing again; a failed mutation
triggers nothing; an `app.event` in `on` triggers it; tenancy (non-member → no tenant; member → its
tenant with its own role); a pending run survives a restart and the next process performs it;
declarations are checked; an AppBoundry build refuses `app.agent`.

## 9. Business audit trail (`app.auditTrail`)

SupplyDesk and TableOS each wrote the same thing: a collection of events about their own subjects,
written in the same transaction as each change, with the actor and the request id. FeltKit provides it:

```ts
export const events = app.auditTrail("events", { subjects: ["invoice", "vendor"] as const });

// in a mutation, next to the change it describes:
await events.record(ctx, { subject: "invoice", id, type: "invoice.approved", data: { amount } });

// anywhere (a query, a mutation):
const history = await events.history(ctx, "invoice", id); // in order
```

| Field | |
|---|---|
| `subjectType`, `subjectId` | What the event is about (`subjects` is the closed list). |
| `type`, `data` | The app's event name and details. |
| `actor`, `actorType` | The caller, or `anonymous` for a public call: an event never refuses a public form. |
| `at` | Wall-clock time, for display. |
| `seq` | **The order**: a FeltDB sequence per subject, allocated in the writing transaction (1, 2, 3…, no repeats or gaps among committed events), never a clock. |
| `requestId` | The request that caused it: the link to FeltKit's activity log (capability, authorization decision, writes). |

- **Atomicity.** If the mutation fails or its commit is refused, the event isn't written either.
- **Reading it.** The trail is an ordinary declared collection (with `tenant` if the app is
  multi-tenant), so queries can read it with `ctx.db`. Who may read it is decided by the functions that
  read it.
- **Append-only** is the helper's contract, not enforced storage: the app shouldn't patch or delete
  events.
- **Adopting it for an existing collection.** The fields match the shape SupplyDesk and TableOS wrote by hand,
  but the trail allocates `seq` from its own sequences (`audit:<trail>:<subject>:<id>`). A subject that already
  has events numbered by the app's own sequence starts again at 1, so with existing data either keep reading
  history by `at` as well, or move it before switching. An anonymous caller is recorded as actor `anonymous`.
- **Where it runs.** It works in FeltKit and in AppBoundry artifacts. An artifact with a trail requires
  `transactions@1`, because of the sequence.

# Security model

## Boundaries

| Boundary | Enforcement |
|---|---|
| HTTP functions (`/api/query`, `/api/mutation`) | Arguments validated, then AppPort's authorizer evaluates the caller's roles against the function's `access`, before the handler runs |
| AppPort (`/appport`) and MCP (`/mcp`) | AppPort's dispatch pipeline: input validation → the same authorizer → handler (which re-checks) → output validation |
| AppPort Services | `ServiceGateway` asks FeltKit's policy (`ServiceAuthorizer`) before every effect. A live effect needs a bound FeltKit invocation of the same principal; durable work (jobs, deliveries) is re-authorized each attempt as its creator's current principal. Refusals are recorded as evidence |
| Studio's Services screens | AppPort Services' own management routes (`createManagementRouter`, `includeUi: false`) inside the admin API at `/_feltkit/api/services/manage`, development only. Identity: the admin token, then a declared dev identity named in `x-feltkit-as`. Authorization: the services' gateway. Successful reads are not recorded as activity (Studio refreshes on activity) |
| Services console | AppPort Services' own pages and routes on a separate loopback origin, development only. Identity: a FeltKit session in an HttpOnly, SameSite=Strict cookie, minted from a one-time 60-second ticket for a declared dev identity. Authorization: the services' gateway. Cross-origin and non-JSON writes refused; non-loopback `Host` refused |
| Agent | Every agent operation needs `feltkit.agent.read` / `feltkit.agent.write`; every action runs as the task owner through AppPort; consequential actions need a person who may perform them; results redacted |
| Data | `ctx.db` reaches only collections the application declared; platform collections are unreachable from application code |
| Dashboard / admin API (development) | Separate admin token (`.feltkit/<env>/admin-token`, 0600), constant-time comparison; application sessions do not grant it |
| Studio / admin API (production) | A verified operator only: an operator session (from a one-time signed grant) or the application's `auth.authenticate` hook. The admin token, `as`, dev users, and non-operator sessions grant nothing. Every route checks a permission server-side (`feltkit.operations.read` / `.write`, plus the action's own permission); writes need JSON, a same-origin `Origin`, a session-bound CSRF value, and `x-feltkit-environment` naming this environment |

## Identity

- Identity comes from a FeltKit session token (opaque, 256-bit, stored as a SHA-256
  digest) or from the application's `auth.authenticate` hook. Request bodies and
  headers never name the caller; a forged or expired token is rejected, not downgraded
  to anonymous.
- Development sign-in (`/api/auth/dev`) exists only in `development` and `test`, and
  only for identities declared in `feltkit({ dev: { users } })`.
- The dashboard can act only as declared dev users, through the normal authorization
  path. It cannot invent principals.

## Development server

- Binds `127.0.0.1` and refuses requests whose `Host` is not loopback (DNS rebinding).
- The dashboard is served with `X-Frame-Options: DENY` and a restrictive CSP.
- The admin token travels in a header (or the URL fragment once, removed on load), never
  in query strings or the frontend bundle.

## Production

- No Studio unless `FELTKIT_DASHBOARD=1`. With it, Studio answers only verified operators
  (below) and offers only the operations listed in docs/GUARANTEES.md ("Production
  operations"). Data browsing is served read-only; data edits, function runs, capability
  invocation, sessions, task creation, the services console, and webhook replay are not served.
- No development sign-in.
- Errors from application code are sanitized to `Internal error (request …)`; details
  go to the server log.
- `FELTDB_TOKEN` is read from the environment and never written to disk or logs.
  `inspect` and the dashboard show storage locations, never credentials.
- `feltkit build` scans the frontend bundle and fails if it contains session or admin
  tokens, `FELTDB_TOKEN`, or FeltDB/AppPort Services server code.

## Production operators

- **Grant.** `feltkit operator grant --id <id> --role <role>` on the host signs
  { application, environment, subject, roles, expiry ≤ 24 h (default 10 min), nonce } with
  HMAC-SHA256 under the environment's operator key: `FELTKIT_OPERATOR_KEY` (≥ 32 bytes,
  base64url) or `.feltkit/<env>/operator-key` (0600). The root of trust is whoever can
  read that key: the host operator. Roles must be declared by the application.
- **Exchange.** Studio posts the grant once; FeltKit verifies the signature, application,
  environment, and expiry, records the nonce (a reused grant is refused), and issues a
  FeltKit session of kind `operator` (8 h) in a `feltkit_operator_<env>` cookie:
  HttpOnly, Secure, SameSite=Strict, Path=/_feltkit. The token is never in a response body.
- **Identity hook.** If the application defines `auth.authenticate`, a `user` principal it
  returns for a Studio request is also an operator; its writes still need the Origin,
  CSRF, and environment checks.
- **Authority.** An operator's permissions come from their roles. Reads need
  `feltkit.operations.read`; actions need `feltkit.operations.write` and then whatever
  the operation itself needs (the action's capability permission and `feltkit.agent.write`
  for agent actions; the services' `jobs.retry` for job retry).
- **Not supported for Studio operators:** OIDC/SAML sign-in to Studio (an application's own
  users can sign in with Google, GitHub or any OpenID Connect provider: docs/AUTH.md; for Studio use
  the `auth.authenticate` hook with your own verification), operator session listing or
  revocation from Studio (sessions expire; rotating the operator key invalidates unused
  grants, not existing sessions — revoke with `feltkit session revoke` while the server is
  stopped), and MFA.
- TLS is assumed to terminate in front of FeltKit (reverse proxy or platform). The cookie
  is `Secure`, so production Studio must be served over HTTPS (browsers also accept it
  on `localhost`). Behind a proxy, `Host` (or `X-Forwarded-Host`) must be the public
  host so the Origin check matches.

## Request hygiene

- Every executing POST (`/api/*`, `/appport`, `/mcp`) must be `Content-Type:
  application/json`. Browsers cannot send JSON cross-site without a CORS preflight,
  which FeltKit never answers, so no other site can drive these endpoints — including
  for apps whose `auth.authenticate` hook reads a cookie.
- A credential that does not verify (unknown, expired, revoked, signed out) is a 401
  on every interface. It is never treated as anonymous, even for public functions.
- The change stream (`/api/events`) requires a session unless the application has a
  public query.

## Audit (2026-10-27)

Every entry point was exercised by `packages/sdk/test/auth.test.ts`.

| Entry point | Finding | Status |
|---|---|---|
| `/appport` | A forged or expired token fell back to anonymous, so a public capability ran without the caller's identity | Fixed: 401 |
| `/appport` | AppPort accepts `text/plain` and form bodies: cross-site request forgery for cookie-authenticated apps | Fixed: JSON required |
| `/mcp` | Same body-type exposure (bearer-only, so not exploitable) | Fixed: JSON required |
| `/api/events` | Change notifications streamed to anonymous callers | Fixed: session required unless a public query exists |
| AppPort Services notifications | Any principal with `notifications.read` could list or open another principal's notifications | Fixed: FeltKit's Services authorizer allows read/update/delete only to the recipient; no override permission |
| `/api/*` | Missing, forged, expired, revoked, and signed-out tokens; client-asserted identity; role enforcement | Verified |
| AppPort / MCP | Role enforcement for agents; revocation takes effect immediately | Verified |
| AppPort Services | Effects require a live invocation of the same principal in the application's tenant; refusals evidenced | Verified |
| CLI sessions | Unknown roles rejected; tokens shown once and never listed | Verified |
| Admin API (development) | Token required; app sessions do not grant it | Verified |
| Admin API (production) | Unauthenticated → 401 on every route; admin token, `as`, dev users, non-operator sessions, forged/expired/reused/other-environment grants refused; read-only operators refused on every write; cross-origin, non-JSON, wrong-CSRF, wrong-environment writes refused with nothing changed; secrets, session tokens, and the admin token absent from responses, activity, and process output | Verified (`production-ops.test.ts`) |
| `auth.authenticate` | Used only without a token; a bad token is not rescued by it; its principals pass through the same roles | Verified |
| Services console | Unauthenticated and under-privileged requests refused by the package's routes; cross-origin, non-JSON, and DNS-rebinding requests refused; tickets single-use | Verified (`console.test.ts`) |
| Durable service work | Runs as its creator; refused after the creator's sessions are revoked | Verified (`console.test.ts`) |
| API keys | Accepted only while active; revoked key → 401; secret never in lists, logs, or explorer | Verified (`console.test.ts`) |
| Agent | Agents cannot approve; approvers must be authorized; owner's authority bounds every action; secrets redacted (mutation-tested) | Verified (`agent.test.ts`) |
| Credential custody | Stored key absent from every FeltDB collection (raw), activity, evidence, configuration export, server output, admin responses, and the dashboard bundle; vault not plaintext and 0600; viewer and agent roles refused; production without opt-in → `CUSTODY_READ_ONLY`; environment variable overrides the vault; Models Test sends the stored key to a local fake provider that checks it | Verified (`credentials.test.ts`, `credential-custody.test.ts`) |

### Credentials and API keys

- Service credentials are references (`credential-ref:<id>`) resolved only inside the
  effect that needs them, from `FELTKIT_CREDENTIAL_<ID>` when it is set, else (development
  and test) from the environment's encrypted vault. Studio shows whether each reference is
  set, where, and its version, never a value.
- **Credential vault** (`.feltkit/<env>/credentials.vault`, key in `credentials.key`): the
  whole document is AES-256-GCM-encrypted with a random 32-byte key and bound (associated
  data) to the application and environment; a modified file or another environment's
  vault fails to decrypt and is refused, not partly read. Both files are 0600 in a 0700
  directory, written atomically under a lock file. Anyone who can read both files can
  read the values: it protects against values leaking into FeltDB, git, builds, logs, and
  screenshots, not against a compromised developer account. Earlier values are not kept.
- **Production** keeps credentials in the host's environment only; `credential.store`
  refuses with `CUSTODY_READ_ONLY`. The vault is opt-in (`FELTKIT_CREDENTIAL_VAULT=1`) and
  then needs `FELTKIT_CREDENTIAL_VAULT_KEY` from the host's secret manager (never written
  to disk by FeltKit); without a valid key the runtime does not start.
- **Entering a value**: Studio (Models, Integrations, Services → Credentials) sends it once
  in a password field over the admin API, clears the field, and never renders it back; the
  server stores it through AppPort Services' `credential.store` as the chosen dev identity
  (development) or the signed-in operator (production, opt-in vault only). The CLI reads it
  from a hidden prompt or stdin; `--value`, `--api-key`, and a key-shaped argument are
  refused, so it never lands in shell history or process listings. A reference field
  holding a key is refused without echoing it.
- API keys are HMACs under a server-held key: `FELTKIT_API_KEY_VERIFIER_KEY` in
  production (≥ 32 bytes; required), `.feltkit/<env>/api-key-verifier` (0600) in
  development. The plaintext is returned once. The data explorer does not expose
  `api_keys`.

### Models and integrations

- Model and integration credentials are the same references, resolved inside the request
  that needs them (`credentials.withSecret`). They are never in the model selection, an
  integration's published contract, call records, checkpoints, activity, responses, or
  logs; an upstream error that echoes one is redacted. `--credential` and Studio's
  reference field accept only a `credential-ref:` reference; the key goes in the API key
  field or `--api-key-stdin`.
- The browser never talks to a model or an integration: decisions and calls run on the
  server, and `feltkit build` fails a bundle containing server code.
- Discovery is not authority. Every integration operation requires a declared permission
  (`public` is refused at definition time); AppPort and MCP list the contract and still
  authorize each invocation. A model can only choose among options the task owner may
  perform, and its choice is a proposal that consequential effects wait on.
- FeltKit reads and writes the Intelligence selection as a **system principal**: an object
  held in a module-private `WeakMap`, allowed only the Intelligence operations it needs
  (read for decisions, write for `feltkit model set` and development Studio). It cannot be
  constructed from a request, a token, or a role.
- Production does not serve `POST /_feltkit/api/models` (model selection); it is selected
  on the host. Verification probes run as the caller, who must hold the probe's
  permission. Tests: `decisions.test.ts` (no key in status, tasks, decision records, activity),
  `integrations.test.ts` (discovery without authority, no credential in records),
  `platform.test.ts` (production routes).

## Known gaps

- No rate limiting on FeltKit's own endpoints. Put a reverse proxy in front of
  production deployments.
- Session tokens in the browser are kept in `localStorage`; an XSS in your frontend can
  read them.
- CORS is not enabled: the API is same-origin. Cross-origin clients need a proxy.
- Request bodies are limited to 2 MiB.
- The services console has no CSRF token: it relies on SameSite=Strict cookies, an
  Origin check, and JSON-only writes on a loopback origin.
- Studio acts as declared dev identities without their sessions (development only):
  anyone with the admin token can act as any of them, as before. None of this applies in
  production.
- Production operator sessions cannot be listed or revoked from Studio; there is no MFA
  and no external identity-provider integration beyond the `auth.authenticate` hook.
- Production Studio has no rate limiting of its own, like every FeltKit endpoint.

Report vulnerabilities privately to the repository owner.

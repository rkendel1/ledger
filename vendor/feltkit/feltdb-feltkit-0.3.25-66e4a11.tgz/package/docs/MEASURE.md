# Measuring an application: `feltkit measure`

`feltkit measure` reports what an application's repository is made of: which code expresses the
application, which code is plumbing it wrote for itself, what tools wrote, what the platform provides,
and how much of FeltKit it actually uses. It measures the repository. It doesn't load or run the app,
use the network, or estimate.

```bash
npx feltkit measure                 # a Markdown summary
npx feltkit measure --json          # the feltkit.measure/1 report
npx feltkit measure --write         # keep the report in a file (see "report" below)
npx feltkit measure --check         # for CI: fails on stale generated code, stale declarations,
                                    # unclassified code, or a kept report that no longer matches
npx feltkit measure --compare a.json b.json c.json   # several applications side by side
```

Add it to `package.json` as `"measure": "feltkit measure"`, and `feltkit measure --check` to CI.

## Classes

Every file gets exactly one class, and the **basis** for it, so every number traces back to files.

| Class | What it is |
|---|---|
| `domain` | Server code that expresses the application: collections, rules, queries, mutations, actions (`feltkit/`). |
| `experience` | What people see and use: UI, styles, HTML, a browser extension. |
| `infrastructure` | Plumbing the application wrote for itself: scripts, servers, adapters, an app-built audit trail or queue. |
| `generated` | Written by a tool and unchanged: codegen output, or scaffolded files still identical to the template. |
| `configuration` | Build, package, deployment and tool configuration. |
| `tests` | Tests, fixtures and acceptance scripts. |
| `third-party` | Code vendored from another project (`vendor/`). |
| `platform` | Files the platform installs and keeps current (FeltKit Agent Skills in `.claude/skills/`). |
| `excluded` | Not code: documentation, images, fonts, lockfiles, licences. Counted, with 0 lines. |
| `unclassified` | No rule applies. A code file here fails `--check` until it is declared. |

**Authored** = domain + experience + infrastructure + configuration: what the application's team writes
and maintains. Tests are reported beside it.

A line of code is a line that isn't blank and isn't only a comment. JSON, YAML and TOML count
non-blank lines. The files are `git ls-files` (tracked files, plus untracked files that aren't
ignored). `node_modules`, `dist`, `.feltkit` and `.git` are never counted.

## How a file is classified

The strongest evidence wins:

1. **A declaration** in `feltkit.measure.json`, which must give a reason.
2. **Provenance:**
   - `feltkit/_generated/api.ts` is compared with what `feltkit codegen` would write now, so a
     hand edit or a stale file shows up.
   - `feltkit.scaffold.json`, which `create-feltkit` writes, holds a SHA-256 of every file it
     scaffolded. A file still identical to it is `generated`. A changed one keeps its normal class
     and is marked `scaffold: "modified"`.
   - Agent Skills installed by `feltkit skills` are `platform` and are compared with the skills in
     the installed FeltKit.
3. **Path conventions** of a FeltKit project: `feltkit/` is domain, `src/` and `public/` are
   experience, `scripts/` is infrastructure, `tests/` and `e2e/` are tests, `vendor/` is third-party.

An application created before `create-feltkit` wrote `feltkit.scaffold.json` can reconstruct one. Run
the same create-feltkit version's scaffold with the app's name into an empty directory, and commit the
manifest it records with a note saying so. Without a manifest, scaffolded files are counted by path,
and the report says so.

## `feltkit.measure.json`

```json
{
  "report": "measure.json",
  "classify": [
    { "path": "feltkit/_audit.ts", "class": "infrastructure", "reason": "business audit trail, until FeltKit has one" },
    { "path": "scripts/**", "class": "tests", "reason": "acceptance scripts" }
  ],
  "acknowledged": {
    "audit-trail:feltkit/app.ts": "the events collection is the app's audit trail"
  }
}
```

- `report`: where `--write` keeps the report and `--check` compares it. The file isn't measured itself.
- `classify`: a path or glob (`*` within a segment, `**` across segments; a directory covers
  everything under it), a class, and a reason. A declaration that matches no file fails `--check`.
- `acknowledged`: findings (`<id>:<file>`) the team has reviewed and keeps, with why. An entry whose
  finding no longer exists fails `--check`.
- `scaffold`: the manifest's path, if not `feltkit.scaffold.json`.

## Platform consumption

These are static call sites, in authored code and tests:

- `ctx.<area>` (`ctx.db`, `ctx.auth`, `ctx.model`, `ctx.agent`, …), counted only in `feltkit/`,
  where `ctx` is FeltKit's function context.
- `ctx.afterCommit.<effect>` and `ctx.services.<service>`.
- Every name imported from `@feltdb/feltkit`, `/react`, `/client` or `/testing`, counted where it's
  used.

`definitions` counts `app.<method>(` calls in `feltkit/` (collections, queries, mutations, actions,
agents) and lists collection names.

## Infrastructure findings

These are static patterns in authored code that suggest the application built something the platform
provides, or something the platform does not provide yet. Each finding names its file and line, the
evidence, and the platform alternative. `platform: null` means FeltKit has none yet: **a platform gap
candidate**. A finding is a candidate for review, not a verdict, and findings don't fail `--check`.

| id | Looks for |
|---|---|
| `http-server` | express, fastify, koa, hono, `createServer(` |
| `realtime-server` | a WebSocket server or a `text/event-stream` response in app code |
| `queue-or-scheduler` | queue or cron libraries, or `setInterval(` in server code |
| `model-sdk` | a model provider's SDK imported directly |
| `auth-library` | password hashing, JWT or session libraries |
| `hand-rolled-api-client` | `fetch("/api/…")` in the UI instead of the generated api |
| `sql` | `CREATE TABLE` / `ALTER TABLE` |
| `audit-trail` | a collection named audit, events, activity, actions or history (`app.auditTrail` does this) |
| `counter-collection` | a collection named counters or sequences (`ctx.db.sequence` does this) |

## The report (`feltkit.measure/1`)

The report is deterministic, with no timestamps, so it can be committed. Its git history is the trend.
The TypeScript type is `MeasureReport` in the SDK (`src/measure/index.ts`).

| Field | Contents |
|---|---|
| `schema` | `"feltkit.measure/1"`. A breaking change gets a new version. |
| `app` | `name`, the declared `feltkit` dependency, and the `installed` version (null when not installed). |
| `method` | How files, lines, consumption and findings were measured, in words. |
| `provenance` | `scaffold` (generator, version, template, files, unmodified, modified, missing), `generated` (file, current), `skills` (name, installedBy, current). |
| `totals` | For each class, `{ files, lines }`. |
| `authored` | `{ files, lines }` for domain + experience + infrastructure + configuration. |
| `definitions` | `app` (method → count) and `collections` (names). |
| `consumption` | `[{ api, callSites, files }]`, the most-used first. |
| `findings` | `[{ id, title, file, line, evidence, platform, acknowledged? }]` |
| `checks` | `[{ name, ok, detail, fix? }]`. `--check` fails when any is false, or when the kept report differs. |
| `files` | `[{ path, class, basis, lines, scaffold? }]`: every file, so every total can be verified. |

## What it doesn't do

- **It doesn't judge quality, and doesn't compare against a "without FeltKit" estimate.** Lines
  written are measured; lines not written are not.
- **Its consumption figures are static.** They show where the app calls the platform, not how often
  those calls run.
- **The boundary between domain and infrastructure inside `feltkit/` comes from declarations and
  findings.** Path conventions alone can't draw it.

# Browser extensions as a FeltKit host

A FeltKit application can run inside a browser extension, such as a Chrome MV3 side panel. It is the same application: the same React app, the same client, the same functions, authorization and data. It is not a second app architecture. The extension is a **host** for the app's existing client, pointed at a deployed instance with a bearer session.

The reference implementation is PersonalOS (`extension/`; acceptance in `e2e/extension.mjs`).

## Who owns what

| Concern | Owner | How |
|---|---|---|
| Functions, authorization, data, model, approvals | **The app's server** (unchanged) | The extension calls the same `/api/*` endpoints as the web app. Nothing is trusted from the extension. |
| Sessions: issue, lifetime, revocation, end-of-session signalling | **FeltKit** | Bearer sessions (`fks_…`, `auth.sessionTtlMs`). A session that ends is answered with `UNAUTHORIZED` + `hint: "SESSION"` on every channel, and open streams close ([AUTH.md](AUTH.md)). |
| Client transport | **FeltKit** | `createClient({ url, session: "bearer", tokens })`. Every channel sends `Authorization: Bearer`: requests, streamed actions, `/api/events`, `/api/agent/actions/events`, `/appport/events`. There is no `EventSource`, and no token in any URL. File links use `fkf_` capability paths. |
| Where the token is kept | **The host adapter** (the app's `extension/`) | A synchronous `TokenStore` (`get`, `set`) backed by memory and written through to `chrome.storage.local`, with storage locked to trusted contexts (see Security). |
| Which instance; the host permission | **The host adapter** | The person enters the instance URL. The adapter requests `optional_host_permissions` for that one origin and checks `/api/session` names the expected `application`. |
| Extension-only UI (page bar, context menu) | **The app** | Product features that call the app's own functions. |
| Visual system | **stack-ui** | The app's UI layer. A narrow-host navigation pattern (a menu) belongs in stack-ui's Shell, not in each app. |

FeltKit adds **no extension-specific API**. The contract is the bearer client, plus the session-end rule that any long-lived client needs.

## Security

- **CORS.** An extension page with a host permission for the instance origin is exempt from CORS in Chrome; this was verified against FeltKit, which serves no CORS headers. A web page on another origin is not exempt, and FeltKit still grants no CORS.
- **CSRF.** Bearer requests carry no ambient credential, so they are CSRF-exempt by design.
- **Token storage.** `chrome.storage.local` is readable by the extension's content scripts, which run inside web pages, unless `chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" })` is set. The adapter sets it in the service worker on every start, and in the panel before it reads the session. This was verified in Chromium: a content script gets "Access to storage is not allowed from this context".
- **No credentials in URLs, logs or the console.** Checked across all requests in the acceptance run.
- **Least privilege.** Host access is requested for the one instance origin at connect time (`optional_host_permissions`). The service worker holds no session and never calls the instance.
- **Revocation and expiry.** Either one, on any session, is noticed by an open panel with no user action: the stream re-check closes the stream, and the client clears the token. Measured: 0.7 s after revocation with `FELTKIT_SESSION_RECHECK_MS=1000`. With FeltKit 0.3.23 an open panel kept a revoked or expired token indefinitely.

## Lifecycle (verified)

| Event | Behaviour |
|---|---|
| Panel closed mid-stream, then reopened | Still signed in (token from storage). The interrupted turn's message is in the conversation history, and existing data is intact. |
| Stop during a stream | The reply stops; the next message streams normally. |
| Browser restart | Still signed in, with the same session. |
| Extension update | The new version keeps the session, and storage stays locked. |
| Session revoked or expired | Streams close and the token is cleared. The app shows its signed-out state. |

## Gap register

| # | Gap | Owner | Status |
|---|---|---|---|
| X1 | Open streams outlived their session (revocation, sign-out, expiry) | FeltKit server | **Fixed.** Re-check on an interval; `error` + close. Test-verified (`session-end.test.ts`) and browser-verified. |
| X2 | Client cleared the token on only one channel, matched by message text | FeltKit client | **Fixed.** One rule keyed on `hint: "SESSION"`; the legacy message is still accepted from older servers. Test-verified and browser-verified. |
| X3 | `subscribe()` retried forever on 401 | FeltKit client | **Fixed.** Stops. Test-verified. |
| X4 | `/appport/events` kept an open stream after its session ended | AppPort (`@appport/server`) | **Security follow-up, fix in review** (rkendel1/appport#290): the binding re-identifies open streams (`reidentifyMs`, default 15 s) and ends them with `UNAUTHORIZED`. Test-verified in AppPort (fails before the fix), and end-to-end through FeltKit with a local build (closed 14.8 s after revocation; published 1.3.1 still open at 20 s). Until AppPort is released and FeltKit's dependency bumped, FeltKit refuses a dead token on connect and the client stops, but an already-open AppPort stream lasts until it drops. |
| X5 | No session refresh; 7-day absolute lifetime | FeltKit | By design for now. The person signs in again; documented. |
| X6 | OAuth providers and e-mail links return to the web origin, not into the extension | FeltKit / app | Open. Use password or dev sign-in in the panel, or sign in on the web and use an operator-issued session. A `chrome.identity.launchWebAuthFlow` handoff would be an adapter feature built on the existing session API. |
| X7 | A streamed action is not resumed after the panel reconnects | FeltKit | Open (P2). The generation record persists, and the conversation shows it as interrupted. |
| X8 | No CORS | — | Not needed for extensions (verified). Unchanged. |
| X9 | Narrow-host navigation (a hamburger menu) is not in stack-ui's Shell | stack-ui | **In review** (rkendel1/stack-ui#21): opt-in `narrowNavigation: 'menu'`, strip stays the default; PersonalOS adopts it (rkendel1/personalos#4). |

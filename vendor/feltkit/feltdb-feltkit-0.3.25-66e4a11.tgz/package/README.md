<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://cdn.jsdelivr.net/npm/@feltdb/feltkit/docs/assets/feltkit-logo-dark.png">
    <img src="https://cdn.jsdelivr.net/npm/@feltdb/feltkit/docs/assets/feltkit-logo.png" alt="FeltKit" width="160">
  </picture>
</p>

# @feltdb/feltkit

The FeltKit SDK, runtime, server, CLI, React bindings, and dashboard.

```bash
npm create feltkit@latest my-app && cd my-app && npm install && npm run dev
```

| Import | Use |
|---|---|
| `@feltdb/feltkit` | `feltkit()`, `s`, collections, `app.query`, `app.mutation`, `fail`, types |
| `@feltdb/feltkit/client` | `createClient`, `createApi`, `ref` — call functions from a browser or Node |
| `@feltdb/feltkit/react` | `FeltKitProvider`, `useQuery`, `useQueryState`, `useMutation`, `useSession`, `useConnectionState` |
| `@feltdb/feltkit/testing` | `createTestApp()` — run the app in-process against an isolated FeltDB instance |
| `@feltdb/feltkit/server` | `startServer` and friends, for embedding |
| bin `feltkit` | `create`, `dev`, `build`, `start`, `test`, `inspect`, `deploy`, `session`, `doctor`, `codegen` |

Built on [`@feltdb/core`](https://www.npmjs.com/package/@feltdb/core),
[`@appport/sdk`](https://www.npmjs.com/package/@appport/sdk), and
[`@appport/services`](https://www.npmjs.com/package/@appport/services). Every component
of a FeltKit application shares one FeltDB instance per environment.

Documentation: shipped with the package. In a project, run `npx feltkit docs` (or read
`node_modules/@feltdb/feltkit/docs/`); online: <https://cdn.jsdelivr.net/npm/@feltdb/feltkit/docs/README.md>.

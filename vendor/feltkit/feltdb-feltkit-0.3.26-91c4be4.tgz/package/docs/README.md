# FeltKit 0.3.26 documentation

Shipped with `@feltdb/feltkit`. In a project: `node_modules/@feltdb/feltkit/docs/`, or run `npx feltkit docs`.
Public copy: https://cdn.jsdelivr.net/npm/@feltdb/feltkit@0.3.26/docs/README.md

- [ARCHITECTURE.md](ARCHITECTURE.md): How FeltKit is put together: one FeltDB instance, AppPort, AppPort Services
- [GUARANTEES.md](GUARANTEES.md): What FeltKit guarantees, and its known limitations
- [TRANSACTIONS.md](TRANSACTIONS.md): Mutations, ctx.db.sequence and ctx.afterCommit: the transaction contract
- [SECURITY.md](SECURITY.md): Authorization, sessions, credentials, and production Studio
- [AUTH.md](AUTH.md): Accounts, sessions, workspaces (tenancy), invitations, and the React sign-in and workspace screens
- [EXTENSION-HOSTS.md](EXTENSION-HOSTS.md): Running the app in a browser extension: ownership, token storage, session end, lifecycle, gaps
- [AGENT-OPERATIONS.md](AGENT-OPERATIONS.md): Agents: MCP, tasks, proposals, approvals, and evidence
- [GENERATION.md](GENERATION.md): Model generation in an application: actions, streaming, tools as proposals, in-app approvals, caller context
- [RESOLVER.md](RESOLVER.md): Model references: change the model a deployed app uses through Resolver, without a redeploy
- [PATH-TO-PRODUCTION.md](PATH-TO-PRODUCTION.md): From a local app to production: deploy targets and what you must provide
- [BACKUP.md](BACKUP.md): Backing up and restoring an environment's state
- [COMPONENTS.md](COMPONENTS.md): Runtime components: a gateway or worker that runs with the application, as a declared principal
- [APPBOUNDRY.md](APPBOUNDRY.md): The AppBoundry artifact, deploying through AppBoundry, and the self-hosted runtime
- [APPBOUNDRY-DEPLOY-CONTRACT.md](APPBOUNDRY-DEPLOY-CONTRACT.md): The deployment contract FeltKit expects from AppBoundry (proposed)
- [WHY-FELTKIT.md](WHY-FELTKIT.md): Design choices, compared with Convex
- [UPSTREAM-GAPS.md](UPSTREAM-GAPS.md): Known gaps in FeltDB, AppPort and AppPort Services, and their status
- [MEASURE.md](MEASURE.md): feltkit measure: what an application is made of, its provenance, platform use and app-built infrastructure
